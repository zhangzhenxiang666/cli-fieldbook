# 概念、状态、枚举与快捷键

> 基准：Herdr v0.9.3，调研日期 2026-10-01。这里解释命令的操作模型，不把未检查的内部实现当作公开承诺。

## 1. 先分清这六层

```text
machine（本机或保存的 SSH 机器）
└── session / server（一个命名运行会话）
    └── workspace（项目或任务工作区）
        └── tab（标签页）
            └── pane（布局中的窗格）
                └── terminal / PTY（真实终端及其进程）
                    └── Agent（被检测到的交互式编程助手）
```

这是理解 CLI 对象关系的示意，不是数据库结构图。工作区、标签页、窗格、底层终端和 Agent 的 ID 不可随意互换。API 返回的 ID 应视为**不透明字符串**，保留原值；不要自行拼接 `w1:p1`，也不要把 UI 的第一个标签页当作 `tab_id=1`。

显示名称用于可读性，ID 用于稳定定位。Agent 命令中允许的 TARGET 解析与严格的 workspace/tab ID 参数不同。机器配置中的 `PROFILE_ID`、`LABEL_OR_ID`、`SSH_TARGET` 也有不同含义。自动化应创建/列举对象、保存返回的 ID，再对这些 ID 操作。

默认会话名称是 `default`。`HERDR_SESSION` 和根级 `--session NAME` 用于会话选择。`--machine` 则使用保存的机器配置中绑定的远程会话，不能再混入其他启动选项。[S02][S03][S10]

## 2. detach、停止、关闭、恢复不是同一件事

| 操作 | 实际意图 | 需要警惕 |
|---|---|---|
| TUI 的 detach | 离开客户端，server 继续托管终端 | 不会自动“完成”后台任务 |
| `server stop` / `session stop` | 停止托管会话 | 会影响该 server 下的真实进程 |
| `pane close` / `tab close` / `workspace close` | 关闭对应运行对象 | 会影响其中的终端任务 |
| `session delete` | 删除已停止会话的保存状态 | 不是普通清理屏幕操作 |
| `worktree remove` | 删除 Git checkout | 比关闭 Herdr 工作区风险更高 |

Server 重启后恢复工作区结构，并不意味着原进程及其内存原样存活。配置允许恢复支持的 Agent 会话，也依赖 Agent 提供可恢复的会话身份/启动参数；不要据此推断任意 shell 命令都能续跑。

实验性的 live handoff 是另一条运行中交接路径，不应与普通持久会话恢复混为一谈。默认工作流使用常规更新和显式重启；只有理解版本/协议兼容风险时才考虑 handoff。[S02][S04][S06][S07][S13]

## 3. Agent 状态的两套集合

| 值 | 阅读状态时的含义 | `agent wait` / `prompt --until` | `pane report-agent --state` |
|---|---|---|---|
| `idle` | 当前不在工作、可等待下一步输入 | 接受 | 接受 |
| `working` | 正在工作 | 接受 | 接受 |
| `blocked` | 等待人工输入、确认或其他介入 | 接受 | 接受 |
| `done` | 对外呈现的完成状态 | 接受 | **不接受** |
| `unknown` | 无法可靠识别当前状态 | 接受，但须显式指定才进入默认等待以外的匹配 | 接受 |

`unknown` 不是 `idle`，`blocked` 也不是业务成功。`agent wait` 默认的匹配集合是 **idle / done / blocked**。`--until` 可重复，关系是**或**，不是先后顺序。

`agent wait` 等待的是状态条件，不是新任务。调用瞬间已匹配便可能立即返回。`agent prompt --wait` 加入了提交后的启动观察，但仍不追踪请求对应的 turn：原本正在工作的 Agent 可能以旧任务完成状态满足等待。因此，业务自动化必须核验 Agent 输出，不能把命令退出 0 直接等同于“这次需求已完成”。

当 prompt 被接受且开始于非 working 状态，5000ms 内没有观察到 working 或 blocked，会报 `agent_prompt_stalled`；更早到期的调用方 timeout 则先返回 timeout。两者都不构成安全重复提交的依据。[S01][S05]

## 4. 输出快照来源与行数

| `--source` | 选择什么 | 主要用途 |
|---|---|---|
| `visible` | 当前渲染的可见屏幕 | 查看菜单、确认框、当前 TUI |
| `recent` | 终端近期输出/滚动历史，保留读取视图中的软换行 | 常规日志检查；默认来源 |
| `recent-unwrapped` | 近期输出合并软换行 | 阅读长命令、较长回答、长日志 |
| `detection` | 状态检测使用的底部快照 | 排查识别问题，不代表全部日志 |

近期快照默认取最后 **80 个渲染行**；显式 `--lines N` 限制行数。合并软换行发生在选择渲染行之后，所以 80 个渲染行不一定等于 80 条完整日志。`visible` / `detection` 使用各自完整视图，显式行数再截取；不要把所有来源都理解成同一个 80 行缓存。

`pane read` / `agent read` 的 `--format text|ansi` 和 `--ansi` 控制输出格式。`pane read` 另有 `--raw`，`agent read` 没有。`detection` 是检测用纯文本视图，不是重放原始控制序列的途径。

`pane wait-output` 的公开来源集合只有 visible、recent、recent-unwrapped。匹配先检查已有快照；recent 两种来源的匹配会合并软换行。`--regex` 使用 Rust 正则且逐行匹配，不能把它当成任意 PCRE 或跨多行全文正则。`--raw` 保留 ANSI 会使颜色/控制码参与匹配，可能导致表面相同的字符串不命中。

运行时还接受 `recent_unwrapped` 兼容拼写；文档和脚本统一使用 `recent-unwrapped`。[S01][S03][S04]

## 5. `--kind` 的 24 个规范 Agent 名称

这些是该版本源码中的 Agent 类型枚举，不是“所有类型具有完全相同集成能力”的承诺。程序仍需自行安装并完成登录配置。以下名称可以作为 `agent start --kind` 的规范值。[S01][S18]

| 规范 KIND | 规范启动程序 | 备注 |
|---|---|---|
| `pi` | `pi` |  |
| `claude` | `claude` | 识别别名含 `claude-code` |
| `codex` | `codex` |  |
| `gemini` | `gemini` |  |
| `cursor` | `cursor-agent` | Windows 对应启动程序可能使用 `.cmd` |
| `devin` | `devin` | 别名含 `devin-cli`、`devin cli` |
| `agy` | `agy` | 识别别名含 `antigravity`、`antigravity-cli` |
| `cline` | `cline` | 识别别名含 `.cline` |
| `omp` | `omp` |  |
| `mastracode` | `mastracode` | 别名含 `mastra-code`、`mastra code` |
| `opencode` | `opencode` | 别名含 `opencode2`、`open-code` |
| `copilot` | `copilot` | 别名含 `github-copilot`、`ghcs` |
| `kimi` | `kimi` | 别名含 `kimi-code`、`kimi code` |
| `kiro` | `kiro-cli` |  |
| `droid` | `droid` |  |
| `amp` | `amp` | 识别别名含 `amp-local` |
| `grok` | `grok` | 识别别名含 `grok-build` |
| `hermes` | `hermes` | 识别别名含 `hermes-agent` |
| `kilo` | `kilo` | 别名含 `kilo-code`、`kilo code` |
| `qodercli` | `qodercli` | 别名含 `qoderclicn`、`qoder`、`qodercn` |
| `qwen` | `qwen` | 别名含 `qwen-code`、`qwen code` |
| `letta` | `letta` | 内置集成目标仍列为实验性 |
| `maki` | `maki` |  |
| `muse` | `muse` | 别名含 `muse-code`、`muse-cli`，识别版本化 `muse-bin-*` |

别名表描述检测/名称归一化路径，不代表每一种别名都在 `--help` 的枚举里显示。调用示例优先使用左侧规范 KIND。

## 6. 可安装的集成目标不等于 Agent KIND

17 个常规集成目标：

```text
pi  omp  claude  codex  copilot  devin  droid  kimi  opencode
kilo  hermes  qodercli  qwen  cursor  mastracode  antigravity-cli  grok
```

另有实验性 `letta`。尤其注意：

```bash
herdr agent start my-agy --kind agy --pane "$pane_id"
herdr integration install antigravity-cli
```

这是两个命名体系，不能为了“统一”把第二个参数改为 agy。集成安装写入 Agent 的 hook/config，通常用于提升状态与会话识别可靠性；不同目标提供的生命周期、会话恢复能力不完全一致。先查看 `integration status`，按具体目标安装/更新。[S17][S19][S20]

## 7. 三种输入方式及其完成边界

| 命令 | 发送什么 | 返回成功能证明什么 |
|---|---|---|
| `pane send-text` | 字面文本，无 Enter | 输入请求被接受 |
| `pane send-keys` / `agent send-keys` | 键盘事件序列 | 按键请求被接受 |
| `pane run` | 文本 + Enter 的一次提交 | 命令被提交，不是进程退出成功 |
| `agent prompt` | 面向 Agent 的 prompt 提交 | 以该命令返回语义为准；不等于任务已完成 |
| `agent prompt --wait` | 提交并等待状态 | 某个状态条件被满足，仍需核验任务结果 |

`pane run` 不是 `exec` 返回退出码的远程调用接口。要可靠判断自己控制的 shell 任务，输出本次运行唯一的结束标记并带退出码，再用 `wait-output` 匹配。匹配应锚定完整一行，避免 shell 回显中的标记误命中。

按键名中 `esc` 是规范 Escape 名称，`escape` 仍被接受。组合键如 `ctrl+c`；支持的常见修饰符包含 ctrl/control、alt、shift、cmd、super，实际效果仍取决于终端/平台。不要把 `ctrl+c` 当作三个可见字符输入。[S03][S04][S05]

## 8. CLI 输出分类与错误处理

| 类别 | 代表命令 | 脚本处理方式 |
|---|---|---|
| API JSON 响应 | workspace/tab/pane 查询与创建、agent 查询等 | 按具体 schema 读取 `result` |
| 默认人类文本，可选 JSON | status、machine list/status、session list/stop/delete、plugin list | 需要结构化读取时显式 `--json` |
| 直接文本 / ANSI | pane read、agent read | 保存或按文本处理，不直接假设 JSON |
| 成功通常无正文 | pane send-text/send-keys/run/report-*、release-agent、workspace report-metadata | 首先检查退出码 |
| 持续 NDJSON 流 | terminal session control/observe | 逐行解码，处理持续流与关闭事件 |
| 本地文件/脚本文本 | completion、--default-config、--skill、config-dir | 按对应文件格式保存 |

通用 API 响应常见形式为 `{ "id": ..., "result": ... }`，API 错误写入 stderr，常见形态为 `{ "id": ..., "error": { "code": ..., "message": ... } }`。但参数错误、本地工具错误等也可能是普通文本 stderr；**不是所有 stderr 都能直接交给 JSON parser**。

常用退出约定：成功 0；运行/API 失败通常 1；使用方式错误通常 2。`config check` 发现问题也返回 1。不要把所有非零都解释成“目标对象不存在”。

`api schema --json` 输出 schema；`api schema --output PATH` 写文件；两者互斥。`agent explain --json` 输出解释对象，不是固定的 API 响应外层。自动化应为正在调用的命令确定契约，而不是给整个 CLI 写一个盲目的 `.result` 解包器。[S03][S04][S05][S14][S15][S16]

## 9. SSH 的两条路径与允许路由的命令

`herdr --remote SSH_TARGET` 是远程 **TUI 附着**。`herdr --machine LABEL_OR_ID ...` 是对已保存机器的 **API 路由**。在 TUI 里选中远程机器，不会让另一个本地 shell 发出的 `herdr pane ...` 自动变成远程命令。

`--machine` 解析 ID 优先；名称必须唯一且大小写精确匹配，配置必须处于启用状态。SSH 别名不自动等同于 Herdr label。它使用保存配置的会话，不能与 `--session`、`--remote` 等启动选项组合。不存在“远程失败后自动落到本机继续执行”的安全承诺；写请求也不应在连接错误后盲目重放。[S10]

v0.9.3 的路由白名单：

| 分类 | 可路由命令 |
|---|---|
| 对象 API | workspace、worktree、tab、pane、notification |
| Agent | 除 `attach` 和 `explain --file` 外的 Agent API 命令 |
| 快照/状态 | `api snapshot`、`status server` |
| 插件 API | link、unlink、enable、disable、list、action、log/logs、pane |
| Server API | stop、reload-config、agent-manifests、reload-agent-manifests |

本地 update、config、machine 管理、session 管理、integration 安装、plugin install/uninstall/config-dir、api schema，以及 terminal 附着/流，不在这个白名单。`server update-agent-manifests` 也不在其中。所有路径参数均应以**实际执行机器**的文件系统为准。[S10，特别是 `validate_machine_command`]

## 10. 配置、环境变量与展示模板

默认配置可由当前版本二进制直接导出：

```bash
herdr --default-config > herdr-default.toml
herdr config check
```

常见 Unix 配置路径为 `~/.config/herdr/config.toml`；`HERDR_CONFIG_PATH` 可显式覆盖。跨平台路径以该二进制的 `herdr --help` 与实际平台解析为准。本节是与 CLI 操作直接相关的配置摘要，不冒充整个应用配置 schema。

| 配置项 | v0.9.3 内置默认/用途 |
|---|---|
| `terminal.new_cwd` | `follow`，跟随当前目录策略 |
| `server.headless_cols` / `headless_rows` | `120` / `40` |
| `worktrees.directory` | `~/.herdr/worktrees` |
| `session.resume_agents_on_restore` | `true`，尝试恢复支持的 Agent 会话 |
| `session.startup_per_agent_delay_ms` | `100` |
| `experimental.pane_history` | `false` |
| `ui.window_title` | `{hostname}: {workspace}` |
| `ui.toast.delivery` | `off`；其他投递方式有 herdr、terminal、system |
| `ui.toast.herdr.position` | `bottom-right` |

相关环境变量摘要：

| 变量 | 用途 |
|---|---|
| `HERDR_CONFIG_PATH` | 显式指定配置路径 |
| `HERDR_SESSION` | 命名会话选择 |
| `HERDR_SOCKET_PATH` | API socket 路径覆盖，通常用于高级连接场景 |
| `HERDR_ENV` | Herdr 管理的环境标记 |
| `HERDR_PANE_ID` | 当前进程所属窗格 |
| `HERDR_TAB_ID` | 当前进程所属标签页 |
| `HERDR_WORKSPACE_ID` | 当前进程所属工作区 |
| `HERDR_LOG` | 日志过滤配置，例如 `herdr=debug` |
| `HERDR_DISABLE_SOUND` | 禁用声音的环境开关 |

`ui.window_title` 的占位符包含 `{hostname}`、`{workspace}`、`{tab}`、`{pane}`、`{terminal_title}`，用 `{{` / `}}` 表示字面花括号。自定义展示元数据的 token 可以在支持的侧栏配置位置以 `$name` 形式引用。

注意双重解释：shell 会先展开 `$name`，Herdr 配置才处理自己的 token。需要把字面 `$build` 写到配置/参数时使用单引号或正确转义。展示 token 不是 jj revset，Herdr 也没有 jj 那种 revision 集合表达式系统。[S02][S03][S04][S06]

## 11. 常用默认快捷键

默认前缀是 **Ctrl+B**。表中的 `前缀 → x` 表示先按 Ctrl+B，再按 x，不是一直按住所有键。自定义配置可能覆盖这些默认值。[S02]

| 动作 | 默认键 |
|---|---|
| 显示帮助 | 前缀 → `?` |
| 打开设置 | 前缀 → `s` |
| 脱离客户端 | 前缀 → `q` |
| 重载配置 | 前缀 → `Shift+R` |
| 打开通知目标 | 前缀 → `o` |
| 工作区选择器 | 前缀 → `w` |
| 跳转 | 前缀 → `g` |
| 新建工作区 | 前缀 → `Shift+N` |
| 新建 Git worktree | 前缀 → `Shift+G` |
| 重命名工作区 | 前缀 → `Shift+W` |
| 关闭工作区 | 前缀 → `Shift+D` |
| 新建标签页 | 前缀 → `c` |
| 重命名标签页 | 前缀 → `Shift+T` |
| 上/下一个标签页 | 前缀 → `p` / `n` |
| 标签页 1..9 | 前缀 → `1`..`9` |
| 关闭标签页 | 前缀 → `Shift+X` |
| 重命名窗格 | 前缀 → `Shift+P` |
| 编辑滚动历史 | 前缀 → `e` |
| 左/下/上/右窗格 | 前缀 → `h` / `j` / `k` / `l` |
| 下/上一个窗格 | 前缀 → `Tab` / `Shift+Tab` |
| 向右分割 | 前缀 → `v` |
| 向下分割 | 前缀 → `-` |
| 关闭窗格 | 前缀 → `x` |
| 放大/恢复窗格 | 前缀 → `z` |
| 调整尺寸模式 | 前缀 → `r` |
| 切换侧栏 | 前缀 → `b` |

在直接 attach 中，Ctrl+B 连按两次可向程序发送字面 Ctrl+B。需要精确的本机配置时，以 `--default-config` 和当前 `config.toml` 为准，不能假定默认键一定未被终端或操作系统截获。


[S01]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec.rs#L6-L966
[S02]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/main.rs
[S03]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli.rs
[S04]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/pane.rs
[S05]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/agent.rs
[S06]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/workspace.rs
[S07]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/worktree.rs
[S08]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/tab.rs
[S09]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/plugin.rs
[S10]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/target.rs#L174-L301
[S11]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/machine.rs
[S12]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/completion.rs
[S13]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/server.rs
[S14]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/api.rs
[S15]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/runtime.rs
[S16]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/status.rs
[S17]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/integration.rs
[S18]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/detect/mod.rs
[S19]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/registry.rs
[S20]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/mod.rs
