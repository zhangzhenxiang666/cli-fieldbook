# Herdr v0.9.3 中文帮助与源码使用手册

**非官方 · 版本固定 v0.9.3 · 调研日期 2026-10-01 · release 短提交 7b116c0**

本套文档参照此前 jj 手册的方式组织：完整公开命令树、逐参数中文释义、帮助式结构、行为约束、使用场景，以及单独的概念/枚举与差异附录。

## 阅读边界

这是一份**源码核对版**，不是在本环境运行 Herdr 后逐字节导出的中文化输出。已检查该 tag 的统一 help spec、根帮助和关键实际解析器；当前环境未成功取得并运行发布二进制，因此所有操作示例均未做本地/远程实际冒烟验证。

命令名、参数名、枚举值保留英文；解释翻译为中文。保留 `Usage / Commands / Arguments / Options` 的帮助式层次，但会补足源帮助里空缺的参数含义，不承诺与某台终端的排版逐字一致。运行时额外接受的参数单独标注，避免冒充原帮助内容。

**覆盖范围：125 个公开帮助节点（包含根命令）、18 个顶层入口、103 个叶子命令节点、24 个工作流。** `status`、`server` 等部分分组自身也可执行，不能将“叶子数”简单当作全部可执行形式的数量。另列 `server live-handoff` 及内部桥接入口，不混入公开节点统计。

## 文件导航

| 文件 | 用途 |
|---|---|
| `herdr-v0.9.3-zh.html` | 离线单页总手册，搜索、目录、展开/折叠与代码复制 |
| `herdr-v0.9.3-zh.md` | Markdown 总手册 |
| `commands-zh.md` / `.txt` | 逐节点中文帮助与源码补注 |
| `concepts-zh.md` | ID、状态、快照、枚举、输出格式、SSH、配置与快捷键 |
| `workflows-zh.md` | 24 个工作流 |
| `help-differences-zh.md` | help spec 与运行时差异、隐藏入口和验证边界 |
| `sources.md` | 固定 tag 的源码链接与对应模块 |
| `commands.json` | 可程序读取的命令、参数、说明与来源清单 |
| `command-tree.txt` | 精简命令树 |
| `audit-help.py` | 在已安装 0.9.3 的机器上采集原始英文帮助 |
| `NOTICE.txt` | 上游归属与许可说明 |

## 建议阅读顺序

初次使用先看“概念”前四节，再看工作流 01、05、10、11。写脚本前必须看“CLI 输出分类”“SSH 路由白名单”和等待命令的边界。查某个参数时直接搜索完整命令，例如 `pane wait-output`。

## 在自己的机器上采集原始帮助

解压后，在 `audit-help.py` 所在目录执行：

```bash
uv run --no-project python audit-help.py \
  --binary herdr --output ./help-capture-v0.9.3
```

脚本只执行版本查询及 125 条精确命令路径的 `--help`，不启动会话、不运行内部入口、不安装插件；遇到版本不符会停止。输出目录需尚不存在，以免覆盖以前的采集。它生成英文原文与采集报告，不会自动完成新版本中文翻译。

## 版本与归属

v0.9.3 的 release 发布于 2026-09-29，短提交 `7b116c0`。发布信息和实时网站可能在之后更新，本手册源码链接固定在 tag。

这是独立中文整理，不是 Herdr 官方承诺、官方翻译或运行结果认证。上游项目许可证为 Apache-2.0；本包不包含 Herdr 二进制、完整源码仓库、用户配置、令牌或字体文件。


[S01]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec.rs#L6-L966
[S02]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/main.rs
[S03]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli.rs
[S04]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/pane.rs
[S05]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/agent.rs
[S06]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/workspace.rs
[S07]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/worktree.rs
[S08]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/tab.rs
[S09]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/plugin.rs
[S10]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/target.rs#L174-L301
[S11]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/machine.rs
[S12]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/completion.rs
[S13]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/server.rs
[S14]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/api.rs
[S15]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/runtime.rs
[S16]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/status.rs
[S17]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/integration.rs
[S18]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/detect/mod.rs
[S19]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/registry.rs
[S20]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/mod.rs
