# 源码、帮助定义与运行时差异

> 本表针对 **v0.9.3**。它记录调研中确认的差异，不代表上游已承认的 bug 列表，也不保证未来版本不变。

## 1. 帮助文档的两个来源

根帮助来自 `src/main.rs` 的手工输出；子命令 `--help` 主要来自 `src/cli/spec.rs` 的 clap 命令树。业务执行又经过各子模块的手写解析器。因而，“帮助显示什么”“补全提供什么”“运行时接受什么”可能不同。

本套文档保留 `Usage / Commands / Arguments / Options` 帮助式结构，以及命令名、选项和枚举的英文原值；中文含义由源码解释补齐。**没有在此环境运行 v0.9.3 二进制，故不是逐字节导出的翻译版，不承诺与某个终端的换行、缩进完全一致。**

## 2. 已确认差异

| 项目 | 帮助/spec | 运行时或实际约束 | 写脚本的建议 |
|---|---|---|---|
| 根命令目录 | 手写根帮助没有列全 `terminal`、`plugin` | 统一 spec 和分发器支持 | 使用完整命令索引 |
| `workspace close --group` | spec 未列 | workspace 解析器接受 | 放在 workspace ID 后，确认关闭范围 |
| `plugin pane open --placement popup` | spec 枚举未列 popup | 插件解析器支持 | 版本固定后使用，见工作流 |
| `plugin pane open --width/--height` | spec 未列 | 解析器接受尺寸/百分比 | 与适用的 popup 布局配合 |
| `--placement fullscreen` | 不是 spec 规范值 | 运行时作 `zoomed` 兼容别名 | 新脚本用 zoomed |
| `plugin pane open --plugin/--entrypoint` | 未标记 required | 运行时要求提供 | 两项总是显式传入 |
| `pane split --direction` | 未标记 required | 运行时要求提供 | 显式 right 或 down |
| `worktree ... --json` | spec 未列 | 四个子命令接受，无效果 | 默认已经 JSON，无需添加 |
| `pane report-metadata --state-label` | spec 使用单值设置 | 运行时可重复 | 每个状态独立一次选项 |
| `api schema --json --output` | spec 没声明互斥 | 解析器拒绝同时使用 | 二选一 |
| `pane input` 的目标 | spec 选择项看似全可选 | 运行时需要有效目标选择 | 用 ID 或 --current |
| `worktree remove --workspace` | spec 未标记 required | 运行时要求 workspace | 总是传 ID |
| `worktree open` 选择条件 | 单项看似可选 | 实际需 path 或 branch | 明确二选一 |
| `recent_unwrapped` | 帮助只列带连字符的值 | 读取解析器保留下划线别名 | 新脚本用 recent-unwrapped |
| `--flag=value` | clap 风格容易使人以为均支持 | 并非所有手写解析器统一展开 | 优先 `--flag VALUE` |
| `herdr help ...` | 自动 help 子命令被关闭 | 某些组有手写 `help` 处理，但不是通用入口 | 用完整路径紧接 `--help` |
| 子命令帮助定位 | 按命令路径寻找帮助节点 | 中间夹入业务位置参数/`--` 可能走别的解析路径 | 使用 `herdr pane read --help` |
| `done` | wait 状态枚举包括 | report-agent 的 state 枚举不包括 | 不要跨命令复用状态枚举 |

来源：[S01][S03][S04][S06][S07][S09][S14]。这些补充项独立标注在命令章节中，未伪装成原帮助已有内容。

## 3. 非公开命令树中的入口

### `herdr server live-handoff`

```text
Usage: herdr server live-handoff [OPTIONS]

Options:
  --import-exe <PATH>           交接导入方可执行文件
  --expected-protocol <N>       期望协议版本
  --expected-version <VERSION>  期望程序版本
```

该入口在 server 手写运行分发/帮助中可见，但不在统一公开 spec 树中。用于实验性 live handoff 和特定恢复路径，可能绕过普通命令前置的版本/协议检查。这里单独列出，不计入 125 个公开节点，也不放进默认帮助采集脚本。**不是常规升级必跑命令。** [S13]

### 内部启动与桥接入口

`client`、`remote-client-bridge`、`remote-api-bridge` 是主分发里的内部启动/传输入口。`server --handoff-import` 是交接导入路径。这些不是普通操作手册应承诺稳定性的 API；不建议从名称推断参数，更不要把它们加入批量“试运行”脚本。

本手册记录其存在，但不臆造未展开检查的内部协议、文件描述符、环境约定及完整参数表。[S02][S03][S13]

## 4. 不要混用旧文档的拼写

v0.9.3 的公开命令树中没有顶层 `wait output`、`agent send` 或根级 `--no-session`。与当前功能对应的规范命令是：

```text
herdr pane wait-output ...
herdr agent prompt ...
herdr pane send-text ...
herdr pane send-keys ...
```

看到其他版本、分叉仓库或旧教程出现不同拼写时，先用 `herdr --version` 与精确子命令 `--help` 核对；不要把所有网上出现过的命令合并成一份“超集手册”。[S01][S03]

## 5. 验证边界

已完成：固定 release/tag、检查公开命令树、逐项解释该树的参数、核对关键运行时解析器、阅读源码测试/帮助中的行为约束、记录差异、核对清单与生成物结构。

未完成：在本环境下载并执行 v0.9.3 二进制；实际启动 TUI/server；验证本地/SSH/Windows/macOS 的运行行为；真实执行插件安装、Agent 登录及任务；对不同终端尺寸截图比对原始帮助。

环境的 GitHub 下载访问未成功，因此未把“源码推导”冒充“跑过的结果”。包中的 `audit-help.py` 可在你已安装该版本的机器上采集原始英文帮助；它只执行版本查询与精确命令路径的 `--help`。


[S01]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec.rs#L6-L966
[S02]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/main.rs
[S03]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli.rs
[S04]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/pane.rs
[S05]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/agent.rs
[S06]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/workspace.rs
[S07]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/worktree.rs
[S08]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/tab.rs
[S09]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/plugin.rs
[S10]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/target.rs#L174-L301
[S11]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/machine.rs
[S12]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/completion.rs
[S13]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/server.rs
[S14]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/api.rs
[S15]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/runtime.rs
[S16]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/status.rs
[S17]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/integration.rs
[S18]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/detect/mod.rs
[S19]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/registry.rs
[S20]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/mod.rs
