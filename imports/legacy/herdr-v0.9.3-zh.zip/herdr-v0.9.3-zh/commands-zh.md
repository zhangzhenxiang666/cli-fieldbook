# 全部公开命令的中文帮助

> 125 个节点（含根），按 v0.9.3 的公开 spec 树组织。说明基于源码重建，不是二进制输出转储。命令顺序保留源树的分组顺序；完整参数互斥关系与执行限制还需看每节补注。

## `herdr`

```text
面向 AI 编程 Agent 的终端工作区管理器。

Usage: herdr [OPTIONS]
       herdr [--session <NAME>] <COMMAND>
       herdr --machine <LABEL-OR-ID> <COMMAND>

Commands:
  completion                 生成 shell 补全脚本。
  update                     下载并安装更新。
  status                     查看客户端与运行中 server 的状态。
  config                     管理本地配置。
  channel                    管理 stable / preview 更新通道。
  machine                    管理保存的 SSH machine 配置。
  server                     运行或控制无界面后台 server。
  api                        检查 socket API 元数据和会话状态。
  workspace                  通过 API 管理工作区。
  worktree                   管理基于 Git worktree 的工作区。
  tab                        通过 API 管理工作区内的标签页。
  notification               显示 Herdr 通知。
  agent                      控制和检查已识别的 Agent 窗格。
  pane                       管理终端窗格、输出、输入及 Agent 报告。
  terminal                   附着或观察底层终端流。
  session                    管理命名持久会话。
  integration                安装和检查内置 Agent 集成。
  plugin                     安装、关联及运行工作流插件。

Options:
  --session <NAME>             使用或创建命名持久会话；可用于本地启动和会话范围的命令。
  --machine <LABEL-OR-ID>      将受支持的 API 命令路由到已保存且启用的 SSH machine。不能与其他启动选项混用。
  --remote <TARGET>            通过 SSH 连接远程 Herdr TUI；不是任意 CLI 子命令的远程执行开关。
  --remote-keybindings <MODE>  远程 TUI 使用 local 或 server 快捷键；默认 local。
  --handoff                    为更新或远程连接显式启用实验性 live handoff。
  --default-config             输出此二进制内置的默认 TOML 配置并退出。
  --skill                      输出内置的 Agent 操作说明文件并退出。
  -V, --version                打印版本并退出。
  -h, --help                   打印该命令的帮助。
```

### 行为与限制

不带子命令时进入交互式 TUI。后台 server 管理终端，detach 不等于停止 server。

这是按统一 spec 补齐的完整命令索引。实际根帮助由 main.rs 手写，未列全 terminal、plugin 等命令；不是根帮助的逐字终端转储。

优先使用 herdr pane read --help 这种“完整命令路径紧接 --help”的形式。没有通用的 herdr help <COMMAND>。

全局选项放在子命令之前；不要假定每个手写解析器都支持 --option=value。示例统一使用 --option VALUE。

源码：[S01] [S02] [S03]


## `herdr completion`

```text
生成 shell 补全脚本。

Usage: herdr completion <SHELL>

Aliases: completions

Arguments:
  <SHELL>  bash、zsh、fish、powershell、elvish。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

脚本写到标准输出；生成脚本本身不修改 shell 配置。

源码：[S12]


## `herdr update`

```text
下载并安装更新。

Usage: herdr update [OPTIONS]

Options:
  --handoff   安装后尝试实验性的运行中 server 交接。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

更新通道由 channel 管理。包管理器安装的构建可能要求通过原包管理器更新。

升级客户端文件不等于所有已运行 server 都已换成新版本；用 status 比较。

源码：[S01] [S02]


## `herdr status`

```text
查看客户端与运行中 server 的状态。

Usage: herdr status [OPTIONS] [COMMAND]

Commands:
  server                     查看运行中 server 状态。
  client                     查看本地客户端状态。

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

本命令自身可执行；server/client 子命令可只查看一侧。

源码：[S01] [S16]


## `herdr status server`

```text
查看运行中 server 状态。

Usage: herdr status server [OPTIONS]

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S16]


## `herdr status client`

```text
查看本地客户端状态。

Usage: herdr status client [OPTIONS]

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S16]


## `herdr config`

```text
管理本地配置。

Usage: herdr config <COMMAND>

Commands:
  check                      校验 config.toml 并输出诊断。
  reset-keys                 移除自定义快捷键配置以回到内置默认。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S03]


## `herdr config check`

```text
校验 config.toml 并输出诊断。

Usage: herdr config check

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

没有问题退出 0；发现问题退出 1。它不是对全部 Agent、插件、SSH 环境的健康检查。

源码：[S01] [S03]


## `herdr config reset-keys`

```text
移除自定义快捷键配置以回到内置默认。

Usage: herdr config reset-keys

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会修改配置文件并生成 config.toml.bak-keybind-v2-<timestamp> 备份。

删除 [keys]、[keys.indexed]、[[keys.command]] 的自定义设置，保留其他配置。运行中 server 可用 server reload-config 重载。

源码：[S01] [S03]


## `herdr channel`

```text
管理 stable / preview 更新通道。

Usage: herdr channel <COMMAND>

Commands:
  show                       打印当前配置的更新通道。
  set                        选择更新通道。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S03]


## `herdr channel show`

```text
打印当前配置的更新通道。

Usage: herdr channel show

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S03]


## `herdr channel set`

```text
选择更新通道。

Usage: herdr channel set <CHANNEL>

Arguments:
  <CHANNEL>  stable 或 preview。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

并非只改变一个显示值：保存通道后，直接安装版本会进入自更新流程；包管理器构建会给出相应指引。

配置 TOML 无法安全解析时不会静默覆盖。

源码：[S01] [S03]


## `herdr machine`

```text
管理保存的 SSH machine 配置。

Usage: herdr machine <COMMAND>

Commands:
  list                       列出保存的机器配置。
  status                     检查已保存机器的连接状态。
  reconnect                  从当前终端重新进行连接/认证。
  add                        准备远程 Herdr 并保存机器配置。
  rename                     重命名保存的机器配置。
  remove                     移除保存的机器配置。
  enable                     启用保存的机器配置。
  disable                    禁用保存的机器配置。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

配置 ID、显示 label 与 SSH_TARGET 不是同一个字段。

源码：[S11] [S10]


## `herdr machine list`

```text
列出保存的机器配置。

Usage: herdr machine list [OPTIONS]

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

源码：[S11] [S10]


## `herdr machine status`

```text
检查已保存机器的连接状态。

Usage: herdr machine status [LABEL_OR_ID] [OPTIONS]

Arguments:
  [LABEL_OR_ID]  只检查一个配置；省略时检查已保存的机器。

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

这是新发起的状态探测，不等同于某个 TUI 客户端正在显示的连接状态；不会弹出交互认证提示。

源码：[S11] [S10]


## `herdr machine reconnect`

```text
从当前终端重新进行连接/认证。

Usage: herdr machine reconnect <LABEL_OR_ID>

Arguments:
  <LABEL_OR_ID>  已保存的配置 ID 或唯一显示名称。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

不执行安装或升级；与 machine add 的准备流程不同。

源码：[S11] [S10]


## `herdr machine add`

```text
准备远程 Herdr 并保存机器配置。

Usage: herdr machine add <SSH_TARGET> [OPTIONS]

Arguments:
  <SSH_TARGET>  SSH 配置别名或 SSH 目标，例如 build-host；不是 Herdr profile ID。

Options:
  --label <LABEL>          本地保存的显示名；未指定时由主机与会话信息产生。
  --remote-session <NAME>  绑定的远程命名会话。
  -h, --help               打印该命令的帮助。
```

### 行为与限制

交互流程可能发现并询问远程会话。安装、升级、重启或重置操作以提示为准；重置可能终止远程进程。

该配置保存后，使用 herdr --machine <label-or-id> ... 执行允许的 API 命令。

源码：[S11] [S10]


## `herdr machine rename`

```text
重命名保存的机器配置。

Usage: herdr machine rename <PROFILE_ID> --label <LABEL>

Arguments:
  <PROFILE_ID>  配置 ID；此处不写 SSH_TARGET。

Options:
  --label <LABEL>  新的显示名称，必需。
  -h, --help       打印该命令的帮助。
```

源码：[S11] [S10]


## `herdr machine remove`

```text
移除保存的机器配置。

Usage: herdr machine remove <PROFILE_ID>

Arguments:
  <PROFILE_ID>  machine list 返回的配置 ID。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

只移除本地连接配置，不负责停止远程 server。

源码：[S11] [S10]


## `herdr machine enable`

```text
启用保存的机器配置。

Usage: herdr machine enable <PROFILE_ID>

Arguments:
  <PROFILE_ID>  machine list 返回的配置 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S11] [S10]


## `herdr machine disable`

```text
禁用保存的机器配置。

Usage: herdr machine disable <PROFILE_ID>

Arguments:
  <PROFILE_ID>  machine list 返回的配置 ID。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

禁用连接配置，不负责停止远程 server。

源码：[S11] [S10]


## `herdr server`

```text
运行或控制无界面后台 server。

Usage: herdr server [COMMAND]

Commands:
  stop                       停止当前目标 server。
  reload-config              让运行中的 server 重载配置。
  agent-manifests            查看当前启用的 Agent 检测 manifest。
  update-agent-manifests     获取并重载 Agent 检测 manifest。
  reload-agent-manifests     重载本地 Agent 检测 manifest 覆盖配置。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

直接运行启动 headless server。普通 TUI 客户端退出、detach 与 server stop 是不同操作。

源码：[S01] [S13]


## `herdr server stop`

```text
停止当前目标 server。

Usage: herdr server stop

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

破坏性操作：其托管的终端及进程会受影响；不要把它当成 detach。

源码：[S01] [S13]


## `herdr server reload-config`

```text
让运行中的 server 重载配置。

Usage: herdr server reload-config

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S13]


## `herdr server agent-manifests`

```text
查看当前启用的 Agent 检测 manifest。

Usage: herdr server agent-manifests [OPTIONS]

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S13]


## `herdr server update-agent-manifests`

```text
获取并重载 Agent 检测 manifest。

Usage: herdr server update-agent-manifests [OPTIONS]

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

这是获取检测规则，不是更新 Claude/Codex 等 Agent 可执行文件；--machine 路由不允许这个本地获取操作。

源码：[S01] [S13]


## `herdr server reload-agent-manifests`

```text
重载本地 Agent 检测 manifest 覆盖配置。

Usage: herdr server reload-agent-manifests

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S13]


## `herdr api`

```text
检查 socket API 元数据和会话状态。

Usage: herdr api <COMMAND>

Commands:
  snapshot                   打印当前会话的实时运行快照。
  schema                     查看或导出当前二进制内置 API schema。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S14] [S15]


## `herdr api snapshot`

```text
打印当前会话的实时运行快照。

Usage: herdr api snapshot

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

这是实时 API 查询，依赖目标 server；与内置 api schema 不同。

源码：[S01] [S14] [S15]


## `herdr api schema`

```text
查看或导出当前二进制内置 API schema。

Usage: herdr api schema [OPTIONS]

Options:
  --json           输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  --output <PATH>  将完整 schema 写入文件。
  -h, --help       打印该命令的帮助。
```

### 行为与限制

不加参数输出概要。--json 与 --output 在实际解析器中互斥。

schema 随客户端二进制打包，不需要在线 server；应与目标 server 的协议版本核对。

源码：[S01] [S14] [S15]


## `herdr workspace`

```text
通过 API 管理工作区。

Usage: herdr workspace <COMMAND>

Commands:
  list                       列出工作区。
  create                     创建工作区及其初始 tab / pane。
  get                        查看工作区。
  focus                      切换到工作区。
  rename                     重命名工作区。
  report-metadata            上报仅用于展示的工作区元数据。
  close                      关闭工作区。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S06]


## `herdr workspace list`

```text
列出工作区。

Usage: herdr workspace list

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S06]


## `herdr workspace create`

```text
创建工作区及其初始 tab / pane。

Usage: herdr workspace create [OPTIONS]

Options:
  --cwd <PATH>       新进程的工作目录；传入目标机器可访问的路径。
  --label <TEXT>     设置显示名称；含空格时整体加引号。
  --env <KEY=VALUE>  设置启动进程的环境变量；可重复。相同键后值覆盖前值，键不得为空。
  --focus            创建后切换焦点到新对象。
  --no-focus         创建后不改变当前焦点；不要与 --focus 同时传入。
  -h, --help         打印该命令的帮助。
```

### 行为与限制

默认不抢焦点。

成功 JSON 中可读取 .result.workspace.workspace_id、.result.tab.tab_id、.result.root_pane.pane_id；不要通过名称猜 ID。

源码：[S01] [S06]


## `herdr workspace get`

```text
查看工作区。

Usage: herdr workspace get <workspace_id>

Arguments:
  <workspace_id>  workspace list/create 返回的工作区 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S06]


## `herdr workspace focus`

```text
切换到工作区。

Usage: herdr workspace focus <workspace_id>

Arguments:
  <workspace_id>  workspace list/create 返回的工作区 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S06]


## `herdr workspace rename`

```text
重命名工作区。

Usage: herdr workspace rename <WORKSPACE_ID> <LABEL>...

Arguments:
  <WORKSPACE_ID>  目标工作区 ID。
  <LABEL>...      名称文本；建议整体加引号，解析器会连接多个词。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S06]


## `herdr workspace report-metadata`

```text
上报仅用于展示的工作区元数据。

Usage: herdr workspace report-metadata <WORKSPACE_ID> --source <ID> [OPTIONS]

Arguments:
  <WORKSPACE_ID>  目标工作区 ID。

Options:
  --source <ID>         非空来源标识，必需；用于区分不同报告方。
  --token <NAME=VALUE>  设置自定义展示 token；可重复。
  --clear-token <NAME>  清除指定 token；可重复。
  --seq <N>             来源提供的顺序编号，用于报告更新顺序；这是计数值，不是时间戳。
  --ttl-ms <N>          展示元数据的有效期，单位毫秒；省略时采用服务端默认策略。
  -h, --help            打印该命令的帮助。
```

### 行为与限制

必须至少设置或清除一个 token。不改变 Agent 的生命周期状态。成功时通常不打印正文。

源码：[S01] [S06]


## `herdr workspace close`

```text
关闭工作区。

Usage: herdr workspace close <workspace_id>

Arguments:
  <workspace_id>  目标工作区 ID。

Options:
  -h, --help  打印该命令的帮助。
```

### 运行时补充（未完整列入统一帮助）

- `--group`：实际解析器接受。关闭关联的 workspace 组；放在 workspace_id 之后。

### 行为与限制

关闭 Herdr 工作区不等于删除 Git checkout。要删除 worktree 使用 worktree remove，并先检查未提交数据。

带关联工作区的主工作区可能要求 --group，避免误关闭整组。

源码：[S01] [S06]


## `herdr worktree`

```text
管理基于 Git worktree 的工作区。

Usage: herdr worktree <COMMAND>

Commands:
  list                       列出仓库关联的 worktree 工作区。
  create                     创建 Git worktree 并打开对应工作区。
  open                       打开已经存在的 Git worktree。
  remove                     删除工作区对应的 Git worktree checkout。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

这里是真正的 Git worktree，不是 jj workspace。所有子命令默认输出 JSON。

源码：[S01] [S07]


## `herdr worktree list`

```text
列出仓库关联的 worktree 工作区。

Usage: herdr worktree list [OPTIONS]

Options:
  --workspace <ID>    从指定 Herdr workspace 解析 Git 仓库。
  --cwd <PATH>        从指定目录解析 Git 仓库；与 --workspace 二选一。
  --trust-repository  仅对本次命令解析到的仓库显式授予信任；不是全局修改 Git 的 safe.directory。
  -h, --help          打印该命令的帮助。
```

### 运行时补充（未完整列入统一帮助）

- `--json`：兼容参数：解析器接受，但默认已经是 JSON，不改变输出。

源码：[S01] [S07]


## `herdr worktree create`

```text
创建 Git worktree 并打开对应工作区。

Usage: herdr worktree create [OPTIONS]

Options:
  --workspace <ID>    从指定 Herdr workspace 解析 Git 仓库。
  --cwd <PATH>        从指定目录解析 Git 仓库；与 --workspace 二选一。
  --branch <NAME>     分支名；已有分支用于检出，否则创建新分支。
  --base <REF>        创建新分支的基准，未指定时以仓库默认/HEAD 规则处理。
  --path <PATH>       检出目录；省略时由 worktrees.directory、仓库和分支名生成。
  --label <TEXT>      设置显示名称；含空格时整体加引号。
  --focus             创建后切换焦点到新对象。
  --no-focus          创建后不改变当前焦点；不要与 --focus 同时传入。
  --trust-repository  仅对本次命令解析到的仓库显式授予信任；不是全局修改 Git 的 safe.directory。
  -h, --help          打印该命令的帮助。
```

### 运行时补充（未完整列入统一帮助）

- `--json`：兼容参数；默认已输出 JSON。

### 行为与限制

是磁盘与仓库写操作，会创建 checkout / 分支，不能当作纯 UI 标签页创建。

源码：[S01] [S07]


## `herdr worktree open`

```text
打开已经存在的 Git worktree。

Usage: herdr worktree open [OPTIONS]

Options:
  --workspace <ID>    从指定 Herdr workspace 解析 Git 仓库。
  --cwd <PATH>        从指定目录解析 Git 仓库；与 --workspace 二选一。
  --path <PATH>       选择现有 worktree 路径；与 --branch 二选一。
  --branch <NAME>     选择现有 worktree 的分支；与 --path 二选一。
  --label <TEXT>      设置显示名称；含空格时整体加引号。
  --focus             创建后切换焦点到新对象。
  --no-focus          创建后不改变当前焦点；不要与 --focus 同时传入。
  --trust-repository  仅对本次命令解析到的仓库显式授予信任；不是全局修改 Git 的 safe.directory。
  -h, --help          打印该命令的帮助。
```

### 运行时补充（未完整列入统一帮助）

- `--json`：兼容参数；默认已输出 JSON。

### 行为与限制

实际解析器要求 --path 或 --branch；不是 create 的另一种拼写。

源码：[S01] [S07]


## `herdr worktree remove`

```text
删除工作区对应的 Git worktree checkout。

Usage: herdr worktree remove --workspace <ID> [OPTIONS]

Options:
  --workspace <ID>    要删除其 checkout 的 Herdr 工作区 ID，必需。
  --force             请求强制删除；可能丢失未提交文件，务必先检查与备份。
  --trust-repository  仅对本次命令解析到的仓库显式授予信任；不是全局修改 Git 的 safe.directory。
  -h, --help          打印该命令的帮助。
```

### 运行时补充（未完整列入统一帮助）

- `--json`：兼容参数；默认已输出 JSON。

### 行为与限制

调用 Git 的 worktree 删除语义，不自动等同于删除该分支；与 workspace close 的风险不同。

源码：[S01] [S07]


## `herdr tab`

```text
通过 API 管理工作区内的标签页。

Usage: herdr tab <COMMAND>

Commands:
  list                       列出标签页。
  create                     创建标签页。
  get                        查看标签页。
  focus                      切换标签页。
  close                      关闭标签页及其窗格。
  rename                     重命名标签页。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S08]


## `herdr tab list`

```text
列出标签页。

Usage: herdr tab list [OPTIONS]

Options:
  --workspace <WORKSPACE_ID>  限定工作区。
  -h, --help                  打印该命令的帮助。
```

源码：[S01] [S08]


## `herdr tab create`

```text
创建标签页。

Usage: herdr tab create [OPTIONS]

Options:
  --workspace <WORKSPACE_ID>  目标工作区；自动化建议明确指定。
  --cwd <PATH>                新进程的工作目录；传入目标机器可访问的路径。
  --label <TEXT>              设置显示名称；含空格时整体加引号。
  --env <KEY=VALUE>           设置启动进程的环境变量；可重复。相同键后值覆盖前值，键不得为空。
  --focus                     创建后切换焦点到新对象。
  --no-focus                  创建后不改变当前焦点；不要与 --focus 同时传入。
  -h, --help                  打印该命令的帮助。
```

### 行为与限制

默认不抢焦点。

源码：[S01] [S08]


## `herdr tab get`

```text
查看标签页。

Usage: herdr tab get <tab_id>

Arguments:
  <tab_id>  标签页 ID，不是可见序号 1、2、3。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S08]


## `herdr tab focus`

```text
切换标签页。

Usage: herdr tab focus <tab_id>

Arguments:
  <tab_id>  标签页 ID，不是可见序号 1、2、3。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S08]


## `herdr tab close`

```text
关闭标签页及其窗格。

Usage: herdr tab close <tab_id>

Arguments:
  <tab_id>  标签页 ID，不是可见序号 1、2、3。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

关闭操作会影响其中正在运行的终端任务。

源码：[S01] [S08]


## `herdr tab rename`

```text
重命名标签页。

Usage: herdr tab rename <TAB_ID> <LABEL>...

Arguments:
  <TAB_ID>    标签页 ID。
  <LABEL>...  名称，建议加引号。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S08]


## `herdr notification`

```text
显示 Herdr 通知。

Usage: herdr notification <COMMAND>

Commands:
  show                       显示一条通知。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01]


## `herdr notification show`

```text
显示一条通知。

Usage: herdr notification show <TITLE> [OPTIONS]

Arguments:
  <TITLE>  通知标题。

Options:
  --body <TEXT>          正文。
  --position <POSITION>  Herdr 内部 toast 位置：top-left、top-right、bottom-left、bottom-right。
  --sound <SOUND>        声音类别：none、done、request；默认 none。
  -h, --help             打印该命令的帮助。
```

### 行为与限制

遵守 ui.toast 的投递配置；默认配置 delivery="off"，命令不会强制绕过关闭设置。

源码：[S01]


## `herdr agent`

```text
控制和检查已识别的 Agent 窗格。

Usage: herdr agent <COMMAND>

Commands:
  list                       列出当前识别到的 Agent。
  get                        查看 Agent 的结构化状态。
  read                       读取 Agent 的终端输出。
  send-keys                  向 Agent 发送按键。
  prompt                     向 Agent 提交提示词。
  rename                     给已识别的 Agent 命名或清除名称。
  focus                      切换到 Agent 所在位置。
  wait                       等待 Agent 状态匹配。
  attach                     直接附着到 Agent 的终端。
  start                      在现有交互 shell 窗格内启动支持的 Agent。
  explain                    解释 Agent 检测状态及证据。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

TARGET 可使用命令接受的 Agent/窗格标识或 Agent 名称；不要把 workspace 的显示名当作 Agent ID。

Agent 检测、内置集成、Agent 可执行程序的安装是三件不同的事。

源码：[S01] [S05]


## `herdr agent list`

```text
列出当前识别到的 Agent。

Usage: herdr agent list

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S05]


## `herdr agent get`

```text
查看 Agent 的结构化状态。

Usage: herdr agent get <target>

Arguments:
  <target>  目标 Agent 或所在窗格的可解析标识。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S05]


## `herdr agent read`

```text
读取 Agent 的终端输出。

Usage: herdr agent read <TARGET> [OPTIONS]

Arguments:
  <TARGET>  目标 Agent。

Options:
  --source <SOURCE>  快照来源：visible、recent、recent-unwrapped、detection；默认 recent。
  --lines <N>        限制快照的末尾渲染行数；软换行合并后的逻辑行数可能更少。
  --format <FORMAT>  输出格式：text 或 ansi；默认按普通文本读取。
  --ansi             请求 ANSI 格式；相当于选择 ansi 格式的便捷开关。
  -h, --help         打印该命令的帮助。
```

### 行为与限制

标准输出直接是文本或 ANSI 内容，不是通用 API JSON 外层。

本命令没有 pane read 的 --raw 开关。

源码：[S01] [S05]


## `herdr agent send-keys`

```text
向 Agent 发送按键。

Usage: herdr agent send-keys <TARGET> <KEY>...

Arguments:
  <TARGET>  目标 Agent。
  <KEY>...  一个或多个键名，如 enter、esc、ctrl+c；esc 为规范写法，escape 也接受。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

按键是操作真实交互界面，不是发送新的自然语言 prompt。确认当前屏幕后再操作；不要自动批准未知确认框。

源码：[S01] [S05]


## `herdr agent prompt`

```text
向 Agent 提交提示词。

Usage: herdr agent prompt <TARGET> <TEXT> [OPTIONS]

Arguments:
  <TARGET>  目标 Agent。
  <TEXT>    完整提示词，含空格或换行时整体引用。

Options:
  --wait            提交后等待首次观察到满足条件的状态。
  --until <STATUS>  匹配状态：idle、working、blocked、done、unknown；可重复，多个状态按“或”匹配。
  --timeout <MS>    超时毫秒数；等待命令省略时可无限等待。
  -h, --help        打印该命令的帮助。
```

### 行为与限制

--until 与 --timeout 都要求 --wait。默认匹配 idle、done、blocked。

目标已经 blocked 时，提交在发送任何输入之前被 agent_blocked 拒绝。

接受提交时若不处于 working，--wait 要求在 5000ms 内观察到 working 或 blocked，否则返回 agent_prompt_stalled；调用方超时更早到达则返回 timeout。

不追踪请求与 Agent turn 的因果关系。目标原本已 working 时，正在进行的旧 turn 结束也可能满足等待。

超时或 stalled 不是“提示词肯定没发出”的证明；先 get/read 再决定是否重试，避免重复提交。

源码：[S01] [S05]


## `herdr agent rename`

```text
给已识别的 Agent 命名或清除名称。

Usage: herdr agent rename <TARGET> <NAME>|--clear

Arguments:
  <TARGET>  已识别 Agent 的目标。
  <NAME>    新名称；与 --clear 二选一。

Options:
  --clear     清除自定义 Agent 名称。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

不能通过 rename 把一个普通 shell 声明成 Agent；重命名也不改变 Agent 种类。

源码：[S01] [S05]


## `herdr agent focus`

```text
切换到 Agent 所在位置。

Usage: herdr agent focus <target>

Arguments:
  <target>  目标 Agent。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S05]


## `herdr agent wait`

```text
等待 Agent 状态匹配。

Usage: herdr agent wait <TARGET> [OPTIONS]

Arguments:
  <TARGET>  目标 Agent。

Options:
  --until <STATUS>  匹配状态：idle、working、blocked、done、unknown；可重复，多个状态按“或”匹配。
  --timeout <MS>    超时毫秒数；等待命令省略时可无限等待。
  -h, --help        打印该命令的帮助。
```

### 行为与限制

默认匹配 idle、done、blocked；多个 --until 是“或”。没有 --timeout 时无限等待。

当前状态已经匹配时可立即返回；不是“等待下一轮完成”。unknown 必须显式指定才会匹配。

源码：[S01] [S05]


## `herdr agent attach`

```text
直接附着到 Agent 的终端。

Usage: herdr agent attach <TARGET> [OPTIONS]

Arguments:
  <TARGET>  目标 Agent。

Options:
  --takeover  显式接管已有终端写入控制权。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

交互式 attach，不是一次性 JSON 查询。Ctrl+B 然后 q 退出附着；Ctrl+B 连按两次发送字面 Ctrl+B。

--machine 路由不支持此交互 attach 命令。

源码：[S01] [S05]


## `herdr agent start`

```text
在现有交互 shell 窗格内启动支持的 Agent。

Usage: herdr agent start <NAME> --kind <KIND> --pane <ID> [OPTIONS] [-- [AGENT_ARG]...]

Arguments:
  <NAME>          启动后给该 Agent 使用的名称。
  [AGENT_ARG]...  -- 后的参数直接传给 Agent，不由 Herdr 解释。

Options:
  --kind <KIND>   必需。规范 Agent 种类见“Agent 种类与别名”表，共 24 种。
  --pane <ID>     必需。现有且停在交互式 shell 提示符的 pane ID。
  --timeout <MS>  等待可交互就绪；默认 30000ms，上限 300000ms。
  -h, --help      打印该命令的帮助。
```

### 行为与限制

不会替你安装 Agent 二进制；相关程序需已可在目标环境启动。

成功表示在同一终端检测到预期 Agent 并已准备接受输入，不只是成功写入了一行 shell 命令。

不能把仍在运行前台任务的 pane 当作空闲 shell 直接覆盖启动。

源码：[S01] [S05]


## `herdr agent explain`

```text
解释 Agent 检测状态及证据。

Usage: herdr agent explain [TARGET] [OPTIONS]

Arguments:
  [TARGET]  在线模式的 Agent/窗格目标；本地 --file 模式不使用该参数。

Options:
  --file <PATH>      读取本地 UTF-8 终端文本样本，离线解释检测结果。
  --agent <LABEL>    本地文件样本对应的 Agent 标签；与 --file 配套。
  --json             输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  --format <FORMAT>  text 或 json。
  -v, --verbose      展开详细证据、匹配区域/规则及覆盖来源。
  -h, --help         打印该命令的帮助。
```

### 行为与限制

两种形式：在线 TARGET；或离线 --file PATH --agent LABEL。文件模式与 TARGET 互斥。

--agent 不是在线模式的目标选择器。--json 输出解释对象自身，不保证含 result 外层。

源码：[S01] [S05]


## `herdr pane`

```text
管理终端窗格、输出、输入及 Agent 报告。

Usage: herdr pane <COMMAND>

Commands:
  list                       列出终端窗格。
  current                    解析当前窗格。
  get                        查看一个窗格。
  layout                     查看窗格布局信息。
  process-info               查看窗格进程信息。
  neighbor                   查找某方向上的相邻窗格。
  edges                      查看窗格在布局中的边缘信息。
  focus                      将焦点切到起点窗格某方向的相邻窗格。
  resize                     调整窗格分割尺寸。
  zoom                       切换或设置窗格放大状态。
  read                       读取窗格终端快照。
  rename                     设置或清除窗格显示名。
  input                      设置窗格输入路由。
  split                      分割窗格并创建新终端。
  swap                       交换两个窗格的位置。
  move                       把窗格移到其他标签页或工作区。
  close                      关闭窗格及其终端。
  send-text                  向窗格发送字面文本，不附加 Enter。
  send-keys                  向窗格发送按键序列。
  wait-output                等待窗格快照中出现匹配输出。
  run                        一次提交命令文本与 Enter。
  report-agent               由 hook/集成上报 Agent 生命周期状态。
  report-agent-session       上报 Agent 会话标识及可选恢复参数。
  release-agent              释放某个来源的 Agent 生命周期权威。
  report-metadata            上报仅用于展示的窗格元数据。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S04]


## `herdr pane list`

```text
列出终端窗格。

Usage: herdr pane list [OPTIONS]

Options:
  --workspace <WORKSPACE_ID>  限定工作区。
  -h, --help                  打印该命令的帮助。
```

源码：[S01] [S04]


## `herdr pane current`

```text
解析当前窗格。

Usage: herdr pane current [OPTIONS]

Options:
  --pane <ID>  显式指定作为操作起点的 pane ID。
  --current    使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help   打印该命令的帮助。
```

### 行为与限制

省略显式选择时会使用可用的调用上下文/焦点回退；自动化优先 --pane，避免随用户焦点变化。

源码：[S01] [S04]


## `herdr pane get`

```text
查看一个窗格。

Usage: herdr pane get <pane_id>

Arguments:
  <pane_id>  pane list/create 返回的窗格 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S04]


## `herdr pane layout`

```text
查看窗格布局信息。

Usage: herdr pane layout [OPTIONS]

Options:
  --pane <ID>  显式指定作为操作起点的 pane ID。
  --current    使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help   打印该命令的帮助。
```

源码：[S01] [S04]


## `herdr pane process-info`

```text
查看窗格进程信息。

Usage: herdr pane process-info [OPTIONS]

Options:
  --pane <ID>  显式指定作为操作起点的 pane ID。
  --current    使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help   打印该命令的帮助。
```

### 行为与限制

用于区分交互 shell、前台命令和 Agent 进程；不应只根据窗口标题判断进程是否存在。

源码：[S01] [S04]


## `herdr pane neighbor`

```text
查找某方向上的相邻窗格。

Usage: herdr pane neighbor --direction <DIRECTION> [OPTIONS]

Options:
  --direction <DIRECTION>  方向：left、right、up、down。
  --pane <ID>              显式指定作为操作起点的 pane ID。
  --current                使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help               打印该命令的帮助。
```

源码：[S01] [S04]


## `herdr pane edges`

```text
查看窗格在布局中的边缘信息。

Usage: herdr pane edges [OPTIONS]

Options:
  --pane <ID>  显式指定作为操作起点的 pane ID。
  --current    使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help   打印该命令的帮助。
```

源码：[S01] [S04]


## `herdr pane focus`

```text
将焦点切到起点窗格某方向的相邻窗格。

Usage: herdr pane focus --direction <DIRECTION> [OPTIONS]

Options:
  --direction <DIRECTION>  方向：left、right、up、down。
  --pane <ID>              显式指定作为操作起点的 pane ID。
  --current                使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help               打印该命令的帮助。
```

### 行为与限制

--pane 是方向导航的起点，不是“直接 focus 到这个 ID”的另一种写法。

源码：[S01] [S04]


## `herdr pane resize`

```text
调整窗格分割尺寸。

Usage: herdr pane resize --direction <DIRECTION> [OPTIONS]

Options:
  --direction <DIRECTION>  方向：left、right、up、down。
  --amount <FLOAT>         调整幅度，必须为有限浮点数；不要当作固定的终端列数/行数。
  --pane <ID>              显式指定作为操作起点的 pane ID。
  --current                使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help               打印该命令的帮助。
```

### 行为与限制

布局与有效调整范围由运行时判定；手册不臆造此选项未标注的默认值。

源码：[S01] [S04]


## `herdr pane zoom`

```text
切换或设置窗格放大状态。

Usage: herdr pane zoom [PANE_ID] [OPTIONS]

Arguments:
  [PANE_ID]  可选窗格 ID；也可用 --pane 或 --current 选择。

Options:
  --pane <ID>  显式指定作为操作起点的 pane ID。
  --current    使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  --toggle     反转放大状态；未传模式时的默认行为。
  --on         设为放大。
  --off        取消放大。
  -h, --help   打印该命令的帮助。
```

### 行为与限制

--toggle、--on、--off 互斥；不要混合目标选择方式。

源码：[S01] [S04]


## `herdr pane read`

```text
读取窗格终端快照。

Usage: herdr pane read <PANE_ID> [OPTIONS]

Arguments:
  <PANE_ID>  目标窗格 ID。

Options:
  --source <SOURCE>  快照来源：visible、recent、recent-unwrapped、detection；默认 recent。
  --lines <N>        限制快照的末尾渲染行数；软换行合并后的逻辑行数可能更少。
  --format <FORMAT>  输出格式：text 或 ansi；默认按普通文本读取。
  --ansi             请求 ANSI 格式；相当于选择 ansi 格式的便捷开关。
  --raw              保留 ANSI 转义，选择原始 ANSI 读取路径；不是二进制日志导出。
  -h, --help         打印该命令的帮助。
```

### 行为与限制

输出直接是文本/ANSI，不应无条件接 jq。

默认 recent 从末尾近期输出取样；visible 与 detection 的视图不同。见概念章节的快照表。

源码：[S01] [S04]


## `herdr pane rename`

```text
设置或清除窗格显示名。

Usage: herdr pane rename <PANE_ID> [LABEL]... [OPTIONS]

Arguments:
  <PANE_ID>   目标窗格 ID。
  [LABEL]...  名称；实际调用需提供名称或 --clear。

Options:
  --clear     清除自定义 pane 标签；不要与名称同时传入。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

与 agent rename、terminal title set 管理的是不同层级。

源码：[S01] [S04]


## `herdr pane input`

```text
设置窗格输入路由。

Usage: herdr pane input [PANE_ID] [OPTIONS] --right-click <TARGET>

Arguments:
  [PANE_ID]  目标窗格；或用 --pane / --current 明确选择。

Options:
  --pane <ID>             显式指定作为操作起点的 pane ID。
  --current               使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  --right-click <TARGET>  必需。herdr 交给 Herdr 菜单；pane 交给窗格内程序的鼠标输入路径。
  -h, --help              打印该命令的帮助。
```

### 行为与限制

实际解析器要求存在目标选择方式；--current 依赖 HERDR_PANE_ID。

pane 右键路由还受窗格内程序是否启用鼠标协议影响。

源码：[S01] [S04]


## `herdr pane split`

```text
分割窗格并创建新终端。

Usage: herdr pane split [PANE_ID] [OPTIONS]

Arguments:
  [PANE_ID]  起点窗格；可用 --pane 或 --current 替代。

Options:
  --pane <ID>              显式指定作为操作起点的 pane ID。
  --current                使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  --direction <DIRECTION>  分割方向：right 在右侧创建，down 在下侧创建。
  --ratio <FLOAT>          分割比例，由运行时布局校验；不是列数。
  --cwd <PATH>             新进程的工作目录；传入目标机器可访问的路径。
  --env <KEY=VALUE>        设置启动进程的环境变量；可重复。相同键后值覆盖前值，键不得为空。
  --right-click <TARGET>   新窗格右键路由：herdr 或 pane；默认 herdr。
  --focus                  创建后切换焦点到新对象。
  --no-focus               创建后不改变当前焦点；不要与 --focus 同时传入。
  -h, --help               打印该命令的帮助。
```

### 行为与限制

实际调用必须传 --direction right 或 --direction down；统一帮助定义没有标记成 required。

默认不改变焦点。自动化建议显式 --pane ID --direction right --no-focus。

源码：[S01] [S04]


## `herdr pane swap`

```text
交换两个窗格的位置。

Usage: herdr pane swap [OPTIONS]

Options:
  --direction <DIRECTION>  方向：left、right、up、down。
  --pane <ID>              显式指定作为操作起点的 pane ID。
  --current                使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  --source-pane <ID>       显式交换的源窗格 ID。
  --target-pane <ID>       显式交换的目标窗格 ID。
  -h, --help               打印该命令的帮助。
```

### 行为与限制

形式一：--direction left/right/up/down，加起点 --pane/--current。

形式二：--source-pane ID --target-pane ID。两种形式不要混用。

源码：[S01] [S04]


## `herdr pane move`

```text
把窗格移到其他标签页或工作区。

Usage: herdr pane move <PANE_ID> [OPTIONS]

Arguments:
  <PANE_ID>  被移动的窗格。

Options:
  --tab <TAB_ID>       移入现有标签页。
  --split <DIRECTION>  现有标签页中的分割方向：right 或 down。
  --target-pane <ID>   现有标签页里作为分割锚点的窗格。
  --ratio <FLOAT>      移入现有布局时的分割比例。
  --new-tab            创建新标签页承载被移动窗格。
  --workspace <ID>     新标签页的目标工作区。
  --new-workspace      创建新工作区承载被移动窗格。
  --label <TEXT>       新标签页或新工作区的名称。
  --tab-label <TEXT>   新工作区内初始标签页名称。
  --focus              创建后切换焦点到新对象。
  --no-focus           创建后不改变当前焦点；不要与 --focus 同时传入。
  -h, --help           打印该命令的帮助。
```

### 行为与限制

现有 tab：--tab TAB_ID --split right|down [--target-pane ID] [--ratio FLOAT]。

新 tab：--new-tab [--workspace ID] [--label TEXT]。

新 workspace：--new-workspace [--label TEXT] [--tab-label TEXT]。三种目的地形式互斥。

源码：[S01] [S04]


## `herdr pane close`

```text
关闭窗格及其终端。

Usage: herdr pane close <pane_id>

Arguments:
  <pane_id>  目标窗格 ID。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会影响正在运行的前台任务；不要误关闭承载当前自动化控制程序的窗格。

源码：[S01] [S04]


## `herdr pane send-text`

```text
向窗格发送字面文本，不附加 Enter。

Usage: herdr pane send-text <PANE_ID> <TEXT>

Arguments:
  <PANE_ID>  目标窗格。
  <TEXT>     要输入的原始文本；推荐整体引用。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

仅发送输入，不意味着命令已执行。要一次提交文本与 Enter 可用 pane run。

成功时通常没有标准输出。

源码：[S01] [S04]


## `herdr pane send-keys`

```text
向窗格发送按键序列。

Usage: herdr pane send-keys <PANE_ID> <KEY>...

Arguments:
  <PANE_ID>  目标窗格。
  <KEY>...   一个或多个键名，如 enter、esc、ctrl+c。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

解析器先校验键名，再发送输入；esc 为规范名称，escape 是兼容写法。成功时通常无正文。

源码：[S01] [S04]


## `herdr pane wait-output`

```text
等待窗格快照中出现匹配输出。

Usage: herdr pane wait-output <PANE_ID> [OPTIONS]

Arguments:
  <PANE_ID>  目标窗格。

Options:
  --match <TEXT>     按字面子串匹配，与 --regex 二选一，必须提供一种。
  --regex <PATTERN>  按 Rust 正则表达式匹配，与 --match 互斥；按行匹配而不是跨行全文匹配。
  --source <SOURCE>  visible、recent、recent-unwrapped；默认 recent。
  --lines <N>        限制搜索快照的渲染行数；recent 默认近期 80 行。
  --timeout <MS>     超时毫秒数；等待命令省略时可无限等待。
  --raw              匹配时保留 ANSI 转义序列；可能影响锚点及子串判断。
  -h, --help         打印该命令的帮助。
```

### 行为与限制

先立即搜索已存在的输出，再轮询。旧日志满足条件也会立即返回，不是“只看本次命令之后的新日志”。

recent / recent-unwrapped 在匹配时会合并软换行；行数截取在合并前执行。

没有 --timeout 则无限等待。帮助允许值不包括 detection，不建议依赖共享解析器的额外放行行为。

源码：[S01] [S04]


## `herdr pane run`

```text
一次提交命令文本与 Enter。

Usage: herdr pane run <PANE_ID> <COMMAND>...

Arguments:
  <PANE_ID>     目标窗格。
  <COMMAND>...  交给窗格内 shell 的命令文本；多个词会按空格连接，建议完整引用。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

API 成功只表示输入已提交，不是子进程成功退出，也不返回进程退出码。成功通常无标准输出。

只在明确处于 shell 提示符时使用；若窗格正运行 Agent/TUI，这些字节会发给那个程序。

源码：[S01] [S04]


## `herdr pane report-agent`

```text
由 hook/集成上报 Agent 生命周期状态。

Usage: herdr pane report-agent <PANE_ID> --source <ID> --agent <LABEL> --state <STATUS> [OPTIONS] [-- [RESUME_ARG]...]

Arguments:
  <PANE_ID>             状态归属的窗格。
  [-- [RESUME_ARG]...]  恢复此 agent 会话的 argv；必须以普通命令名开头，不是任意 shell 脚本字符串。

Options:
  --source <ID>                必需，生命周期报告来源。
  --agent <LABEL>              必需，Agent 规范标签。
  --state <STATUS>             必需，仅 idle、working、blocked、unknown。这里不接受 done。
  --message <TEXT>             补充状态说明。
  --seq <N>                    来源提供的顺序编号，用于报告更新顺序；这是计数值，不是时间戳。
  --agent-session-id <ID>      Agent 自己的会话标识，区别于 Herdr session。
  --agent-session-path <PATH>  Agent 会话存储路径。
  -h, --help                   打印该命令的帮助。
```

### 行为与限制

高级集成接口，会影响生命周期权威来源；普通使用者不应把它当成给任意任务手工造完成状态的命令。

与 wait 可匹配的状态集合不同。成功通常不打印正文。

源码：[S01] [S04]


## `herdr pane report-agent-session`

```text
上报 Agent 会话标识及可选恢复参数。

Usage: herdr pane report-agent-session <PANE_ID> --source <ID> --agent <LABEL> [OPTIONS] [-- [RESUME_ARG]...]

Arguments:
  <PANE_ID>             会话身份归属的窗格。
  [-- [RESUME_ARG]...]  恢复此 agent 会话的 argv；必须以普通命令名开头，不是任意 shell 脚本字符串。

Options:
  --source <ID>                    必需，报告来源。
  --agent <LABEL>                  必需，Agent 规范标签。
  --seq <N>                        来源提供的顺序编号，用于报告更新顺序；这是计数值，不是时间戳。
  --agent-session-id <ID>          Agent 自己的会话标识，区别于 Herdr session。
  --agent-session-path <PATH>      Agent 会话存储路径。
  --session-start-source <SOURCE>  描述 Agent 会话启动来源的标记；不是 pane read 的快照来源枚举。
  -h, --help                       打印该命令的帮助。
```

### 行为与限制

只报告会话身份/恢复信息，不宣称拥有 Agent 生命周期状态权威。成功通常无正文。

源码：[S01] [S04]


## `herdr pane release-agent`

```text
释放某个来源的 Agent 生命周期权威。

Usage: herdr pane release-agent <PANE_ID> --source <ID> --agent <LABEL> [OPTIONS]

Arguments:
  <PANE_ID>  目标窗格。

Options:
  --source <ID>    必需，要释放的报告来源。
  --agent <LABEL>  必需，Agent 规范标签。
  --seq <N>        来源提供的顺序编号，用于报告更新顺序；这是计数值，不是时间戳。
  -h, --help       打印该命令的帮助。
```

### 行为与限制

release 是释放状态报告权威，不是 kill、停止 Agent、关闭 pane 或删除会话。成功通常无正文。

源码：[S01] [S04]


## `herdr pane report-metadata`

```text
上报仅用于展示的窗格元数据。

Usage: herdr pane report-metadata <PANE_ID> --source <ID> [OPTIONS]

Arguments:
  <PANE_ID>  目标窗格。

Options:
  --source <ID>                必需，非空报告来源。
  --agent <LABEL>              将展示元数据关联到某 Agent 标签。
  --applies-to-source <ID>     限定这份展示覆盖适用于哪个状态来源。
  --title <TEXT>               展示标题。
  --clear-title                清除展示标题；与 --title 互斥。
  --display-agent <TEXT>       Agent 的展示文本，不改变真实种类。
  --clear-display-agent        清除展示 Agent 文本；与 --display-agent 互斥。
  --state-label <STATUS=TEXT>  覆盖某个状态的展示文字；运行时可重复设置多个状态。
  --clear-state-labels         清除状态展示文字覆盖。
  --token <NAME=VALUE>         设置自定义展示 token；可重复。
  --clear-token <NAME>         清除指定 token；可重复。
  --seq <N>                    来源提供的顺序编号，用于报告更新顺序；这是计数值，不是时间戳。
  --ttl-ms <N>                 展示元数据的有效期，单位毫秒；省略时采用服务端默认策略。
  -h, --help                   打印该命令的帮助。
```

### 行为与限制

实际解析器要求至少设置或清除一个展示字段；这类更新不改变 idle/working/blocked 的语义状态。

--state-label 在运行时支持重复，但 spec 没有为它配置 Append。成功通常无正文。

源码：[S01] [S04]


## `herdr terminal`

```text
附着或观察底层终端流。

Usage: herdr terminal <COMMAND>

Commands:
  attach                     直接附着到底层终端。
  session                    通过 NDJSON 控制或观察终端会话。
  title                      设置外层终端窗口标题。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

terminal 是 pane 承载的终端实例；不是外层终端模拟器窗口。

源码：[S01] [S03]


## `herdr terminal attach`

```text
直接附着到底层终端。

Usage: herdr terminal attach <TERMINAL_ID> [OPTIONS]

Arguments:
  <TERMINAL_ID>  底层终端 ID；不要把 workspace/tab ID 填到这里。

Options:
  --takeover  显式接管现有写入控制权。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

交互式命令；退出附着为 Ctrl+B 然后 q。退出附着不等于终止终端进程。

源码：[S01] [S03]


## `herdr terminal session`

```text
通过 NDJSON 控制或观察终端会话。

Usage: herdr terminal session <COMMAND>

Commands:
  control                    通过 NDJSON 持有终端写入控制流。
  observe                    只读观察终端 NDJSON 流。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

面向程序的持续流协议，不是一次返回一个 JSON 的查询；请按行解码事件。

源码：[S01] [S03]


## `herdr terminal session control`

```text
通过 NDJSON 持有终端写入控制流。

Usage: herdr terminal session control <TARGET> [OPTIONS]

Arguments:
  <TARGET>  受支持的 pane / terminal / agent 目标。

Options:
  --takeover  接管已有控制流。
  --cols <N>  终端列数，1..65535；默认 120。
  --rows <N>  终端行数，1..65535；默认 40。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

标准输出持续发送终端帧/关闭事件；标准输入读取协议规定的 input/resize/mouse 等消息。

一个终端仅一个写入控制者。不要把任意文本直接写入 stdin 当成键盘字节；先查 api schema。

源码：[S01] [S03]


## `herdr terminal session observe`

```text
只读观察终端 NDJSON 流。

Usage: herdr terminal session observe <TARGET> [OPTIONS]

Arguments:
  <TARGET>  受支持的 pane / terminal / agent 目标。

Options:
  --cols <N>  终端列数，1..65535；默认 120。
  --rows <N>  终端行数，1..65535；默认 40。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

输出 terminal.frame 等事件，帧内 ANSI 数据按协议编码；不要当作可直接 cat 的终端画面。

只读观察，不发送按键，也不抢占输入控制权。

源码：[S01] [S03]


## `herdr terminal title`

```text
设置外层终端窗口标题。

Usage: herdr terminal title <COMMAND>

Commands:
  set                        设置外层终端窗口标题。
  clear                      清除手工设置的外层标题。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S03]


## `herdr terminal title set`

```text
设置外层终端窗口标题。

Usage: herdr terminal title set <TITLE>

Arguments:
  <TITLE>  标题文本。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

与 pane rename、tab rename 和 Agent 名称不是同一个字段。

源码：[S01] [S03]


## `herdr terminal title clear`

```text
清除手工设置的外层标题。

Usage: herdr terminal title clear

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

恢复由 ui.window_title 配置生成的标题。

源码：[S01] [S03]


## `herdr session`

```text
管理命名持久会话。

Usage: herdr session <COMMAND>

Commands:
  list                       列出会话。
  attach                     启动客户端附着到会话。
  stop                       停止命名会话。
  delete                     删除已经停止的会话。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会话控制 server 与保存的工作区结构。默认会话名称为 default。

源码：[S01] [S03]


## `herdr session list`

```text
列出会话。

Usage: herdr session list [OPTIONS]

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S03]


## `herdr session attach`

```text
启动客户端附着到会话。

Usage: herdr session attach <NAME>

Arguments:
  <NAME>  会话名称。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

这是启动/进入 TUI 的操作，不是 JSON 状态查询。

源码：[S01] [S03]


## `herdr session stop`

```text
停止命名会话。

Usage: herdr session stop <NAME> [OPTIONS]

Arguments:
  <NAME>  会话名称。

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会影响该会话托管的进程。只想离开 TUI 时应 detach，不要 stop。

源码：[S01] [S03]


## `herdr session delete`

```text
删除已经停止的会话。

Usage: herdr session delete <NAME> [OPTIONS]

Arguments:
  <NAME>  已停止会话的名称；默认会话显式填写 default。

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会删除保存的会话状态；正在运行的会话不能直接作为 stopped 会话删除。

源码：[S01] [S03]


## `herdr integration`

```text
安装和检查内置 Agent 集成。

Usage: herdr integration <COMMAND>

Commands:
  install                    安装或更新一个 Agent 的 Herdr 集成。
  uninstall                  卸载一个 Agent 的 Herdr 集成。
  status                     检查集成安装状态。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

安装的是 Herdr 的 hook/集成配置，不是安装 Agent 主程序。目标名不总与 agent start --kind 相同。

源码：[S01] [S17] [S19] [S20]


## `herdr integration install`

```text
安装或更新一个 Agent 的 Herdr 集成。

Usage: herdr integration install <TARGET>

Arguments:
  <TARGET>  17 个常规目标及实验性 letta，见集成目标表。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会修改对应 Agent 的配置或 hook 文件。该版本没有 integration install all，也没有此命令的 --json。

源码：[S01] [S17] [S19] [S20]


## `herdr integration uninstall`

```text
卸载一个 Agent 的 Herdr 集成。

Usage: herdr integration uninstall <TARGET>

Arguments:
  <TARGET>  17 个常规目标及实验性 letta，见集成目标表。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会修改对应 Agent 的配置或 hook 文件。该版本没有 integration install all，也没有此命令的 --json。

源码：[S01] [S17] [S19] [S20]


## `herdr integration status`

```text
检查集成安装状态。

Usage: herdr integration status [OPTIONS]

Options:
  --outdated-only  只列出被判为过期、需要更新的集成。
  -h, --help       打印该命令的帮助。
```

### 行为与限制

检查后可对具体目标重新运行 integration install；检测支持的 Agent 数量不等于可安装集成目标数量。

源码：[S01] [S17] [S19] [S20]


## `herdr plugin`

```text
安装、关联及运行工作流插件。

Usage: herdr plugin <COMMAND>

Commands:
  install                    从 GitHub 安装插件。
  uninstall                  卸载插件。
  link                       关联本地插件目录。
  unlink                     取消本地插件目录关联。
  enable                     启用插件。
  disable                    禁用插件。
  list                       列出插件及状态。
  config-dir                 输出插件用户配置目录。
  action                     列出或调用插件动作。
  log                        查看插件命令日志。
  pane                       管理插件拥有的窗格。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

插件可执行本机代码、访问本地资源。安装/启用前应确认来源、版本、配置与权限。

源码：[S01] [S09]


## `herdr plugin install`

```text
从 GitHub 安装插件。

Usage: herdr plugin install <OWNER/REPO[/SUBDIR]> [OPTIONS]

Arguments:
  <OWNER/REPO[/SUBDIR]>  GitHub 仓库简写，可带插件子目录；不是任意 HTTPS/Git URL。

Options:
  --ref <REF>  指定 Git 引用，如固定 tag 或提交。
  -y, --yes    跳过交互确认；只对已审核的来源使用。
  -h, --help   打印该命令的帮助。
```

### 行为与限制

属于磁盘/代码安装操作；--machine 不允许把本地安装器当作远程命令运行。

源码：[S01] [S09]


## `herdr plugin uninstall`

```text
卸载插件。

Usage: herdr plugin uninstall <PLUGIN>

Arguments:
  <PLUGIN>  已安装插件 ID 或安装来源简写。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

与 unlink 本地开发目录不同；先检查 plugin list 确认对象。

源码：[S01] [S09]


## `herdr plugin link`

```text
关联本地插件目录。

Usage: herdr plugin link <PATH> [OPTIONS]

Arguments:
  <PATH>  插件目录；远程 --machine 场景必须为远程绝对路径。

Options:
  --disabled  关联但保持禁用，适合先检查新插件。
  --enabled   关联并启用；默认启用。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

不要同时传 --enabled 与 --disabled。不是上传本地目录到远程机器。

源码：[S01] [S09]


## `herdr plugin unlink`

```text
取消本地插件目录关联。

Usage: herdr plugin unlink <PLUGIN_ID>

Arguments:
  <PLUGIN_ID>  关联的插件 ID。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

管理关联关系，不等于删除原始开发仓库。

源码：[S01] [S09]


## `herdr plugin enable`

```text
启用插件。

Usage: herdr plugin enable <PLUGIN_ID>

Arguments:
  <PLUGIN_ID>  插件 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin disable`

```text
禁用插件。

Usage: herdr plugin disable <PLUGIN_ID>

Arguments:
  <PLUGIN_ID>  插件 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin list`

```text
列出插件及状态。

Usage: herdr plugin list [OPTIONS]

Options:
  --plugin <ID>  仅查看指定插件。
  --json         输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help     打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin config-dir`

```text
输出插件用户配置目录。

Usage: herdr plugin config-dir <PLUGIN_ID>

Arguments:
  <PLUGIN_ID>  插件 ID。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

并非严格只读：实现会确保相关用户目录已创建。输出目录路径文本。

源码：[S01] [S09]


## `herdr plugin action`

```text
列出或调用插件动作。

Usage: herdr plugin action <COMMAND>

Commands:
  list                       列出可用插件动作。
  invoke                     调用一个插件动作。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin action list`

```text
列出可用插件动作。

Usage: herdr plugin action list [OPTIONS]

Options:
  --plugin <ID>  仅列出指定插件动作。
  -h, --help     打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin action invoke`

```text
调用一个插件动作。

Usage: herdr plugin action invoke <ACTION_ID> [OPTIONS]

Arguments:
  <ACTION_ID>  动作标识；可用 <plugin-id>.<local-action> 形式。

Options:
  --plugin <ID>  显式指定插件，避免本地动作名歧义。
  -h, --help     打印该命令的帮助。
```

### 行为与限制

本地动作名不能自行随意添加点号层级。调用动作可能运行外部命令，以插件定义为准。

源码：[S01] [S09]


## `herdr plugin log`

```text
查看插件命令日志。

Usage: herdr plugin log <COMMAND>

Aliases: logs

Commands:
  list                       列出插件命令日志。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin log list`

```text
列出插件命令日志。

Usage: herdr plugin log list [OPTIONS]

Options:
  --plugin <ID>  限定插件。
  --limit <N>    最多返回的日志条数；未传时由实现采用默认上限。
  -h, --help     打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin pane`

```text
管理插件拥有的窗格。

Usage: herdr plugin pane <COMMAND>

Commands:
  open                       打开插件入口对应的窗格。
  focus                      聚焦插件窗格。
  close                      关闭插件窗格。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin pane open`

```text
打开插件入口对应的窗格。

Usage: herdr plugin pane open [OPTIONS]

Options:
  --plugin <ID>            插件 ID；实际解析器要求提供。
  --entrypoint <ID>        插件入口 ID；实际解析器要求提供。
  --placement <PLACEMENT>  spec 列出 overlay、split、tab、zoomed；运行时额外支持 popup，见补注。
  --workspace <ID>         目标工作区。
  --target-pane <PANE>     目标/锚点窗格。
  --direction <DIRECTION>  分割方向：right 在右侧创建，down 在下侧创建。
  --cwd <PATH>             新进程的工作目录；传入目标机器可访问的路径。
  --env <KEY=VALUE>        设置启动进程的环境变量；可重复。相同键后值覆盖前值，键不得为空。
  --focus                  创建后切换焦点到新对象。
  --no-focus               创建后不改变当前焦点；不要与 --focus 同时传入。
  -h, --help               打印该命令的帮助。
```

### 运行时补充（未完整列入统一帮助）

- `--placement popup`：实际解析器支持弹出式窗格；此外 fullscreen 是 zoomed 的兼容别名。
- `--width <SIZE>`：弹出式窗格宽度，可用终端单元格数或百分比，例如 100、80%。
- `--height <SIZE>`：弹出式窗格高度，可用终端单元格数或百分比，例如 30、70%。

### 行为与限制

默认 focus=true，与 workspace create / tab create / pane split 默认不抢焦点不同。

尺寸选项未列入统一 spec。布局相关组合限制仍由运行时验证；popup 示例见工作流。

源码：[S01] [S09]


## `herdr plugin pane focus`

```text
聚焦插件窗格。

Usage: herdr plugin pane focus <PANE_ID>

Arguments:
  <PANE_ID>  plugin pane open/list 信息中的窗格 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin pane close`

```text
关闭插件窗格。

Usage: herdr plugin pane close <PANE_ID>

Arguments:
  <PANE_ID>  plugin pane open/list 信息中的窗格 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


[S01]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec.rs#L6-L966
[S02]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/main.rs
[S03]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli.rs
[S04]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/pane.rs
[S05]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/agent.rs
[S06]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/workspace.rs
[S07]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/worktree.rs
[S08]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/tab.rs
[S09]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/plugin.rs
[S10]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/target.rs#L174-L301
[S11]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/machine.rs
[S12]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/completion.rs
[S13]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/server.rs
[S14]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/api.rs
[S15]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/runtime.rs
[S16]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/status.rs
[S17]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/integration.rs
[S18]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/detect/mod.rs
[S19]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/registry.rs
[S20]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/mod.rs
