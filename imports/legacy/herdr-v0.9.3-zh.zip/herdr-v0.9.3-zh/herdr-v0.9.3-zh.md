# Herdr v0.9.3 中文帮助与源码使用手册

**非官方 · 版本固定 v0.9.3 · 调研日期 2026-10-01 · release 短提交 7b116c0**

本套文档参照此前 jj 手册的方式组织：完整公开命令树、逐参数中文释义、帮助式结构、行为约束、使用场景，以及单独的概念/枚举与差异附录。

## 阅读边界

这是一份**源码核对版**，不是在本环境运行 Herdr 后逐字节导出的中文化输出。已检查该 tag 的统一 help spec、根帮助和关键实际解析器；当前环境未成功取得并运行发布二进制，因此所有操作示例均未做本地/远程实际冒烟验证。

命令名、参数名、枚举值保留英文；解释翻译为中文。保留 `Usage / Commands / Arguments / Options` 的帮助式层次，但会补足源帮助里空缺的参数含义，不承诺与某台终端的排版逐字一致。运行时额外接受的参数单独标注，避免冒充原帮助内容。

**覆盖范围：125 个公开帮助节点（包含根命令）、18 个顶层入口、103 个叶子命令节点、24 个工作流。** `status`、`server` 等部分分组自身也可执行，不能将“叶子数”简单当作全部可执行形式的数量。另列 `server live-handoff` 及内部桥接入口，不混入公开节点统计。

## 文件导航

| 文件 | 用途 |
|---|---|
| `herdr-v0.9.3-zh.html` | 离线单页总手册，搜索、目录、展开/折叠与代码复制 |
| `herdr-v0.9.3-zh.md` | Markdown 总手册 |
| `commands-zh.md` / `.txt` | 逐节点中文帮助与源码补注 |
| `concepts-zh.md` | ID、状态、快照、枚举、输出格式、SSH、配置与快捷键 |
| `workflows-zh.md` | 24 个工作流 |
| `help-differences-zh.md` | help spec 与运行时差异、隐藏入口和验证边界 |
| `sources.md` | 固定 tag 的源码链接与对应模块 |
| `commands.json` | 可程序读取的命令、参数、说明与来源清单 |
| `command-tree.txt` | 精简命令树 |
| `audit-help.py` | 在已安装 0.9.3 的机器上采集原始英文帮助 |
| `NOTICE.txt` | 上游归属与许可说明 |

## 建议阅读顺序

初次使用先看“概念”前四节，再看工作流 01、05、10、11。写脚本前必须看“CLI 输出分类”“SSH 路由白名单”和等待命令的边界。查某个参数时直接搜索完整命令，例如 `pane wait-output`。

## 在自己的机器上采集原始帮助

解压后，在 `audit-help.py` 所在目录执行：

```bash
uv run --no-project python audit-help.py \
  --binary herdr --output ./help-capture-v0.9.3
```

脚本只执行版本查询及 125 条精确命令路径的 `--help`，不启动会话、不运行内部入口、不安装插件；遇到版本不符会停止。输出目录需尚不存在，以免覆盖以前的采集。它生成英文原文与采集报告，不会自动完成新版本中文翻译。

## 版本与归属

v0.9.3 的 release 发布于 2026-09-29，短提交 `7b116c0`。发布信息和实时网站可能在之后更新，本手册源码链接固定在 tag。

这是独立中文整理，不是 Herdr 官方承诺、官方翻译或运行结果认证。上游项目许可证为 Apache-2.0；本包不包含 Herdr 二进制、完整源码仓库、用户配置、令牌或字体文件。


---

# 快速定位

| 你要做什么 | 从哪里开始 |
|---|---|
| 进入终端工作区 | `herdr` |
| 看客户端/server 是否在线及版本 | `herdr status` |
| 得到当前托管的对象 ID | `workspace list`、`tab list`、`pane list`、`agent list` |
| 在现有 shell 中启动 Agent | `agent start` |
| 提交 prompt 并观察状态 | `agent prompt --wait`，随后 `agent get/read` |
| 读当前屏幕或长日志 | `pane read --source visible/recent-unwrapped` |
| 提交 shell 命令 | `pane run`，但它不返回该命令的退出码 |
| 等待本次任务日志 | `pane wait-output`，使用本次唯一的完整行标记 |
| 不抢焦点地创建对象 | 显式 `--no-focus` |
| 远程 TUI | `--remote SSH_TARGET` |
| 远程 API | `--machine SAVED_LABEL_OR_ID` |
| 为 jj 工作目录开界面 | 普通 `workspace create --cwd ...` |
| 创建 Git worktree | `worktree create`，不是 jj workspace |
| 查协议字段 | `api schema` |
| 查状态检测原因 | `agent explain --verbose` |

以下所有 `herdr` 子命令都应在前面添加实际所需的根级会话/机器前缀；`--machine` 仅允许特定 API 命令，并非通用 ssh exec。


---

# 概念、状态、枚举与快捷键

> 基准：Herdr v0.9.3，调研日期 2026-10-01。这里解释命令的操作模型，不把未检查的内部实现当作公开承诺。

## 1. 先分清这六层

```text
machine（本机或保存的 SSH 机器）
└── session / server（一个命名运行会话）
    └── workspace（项目或任务工作区）
        └── tab（标签页）
            └── pane（布局中的窗格）
                └── terminal / PTY（真实终端及其进程）
                    └── Agent（被检测到的交互式编程助手）
```

这是理解 CLI 对象关系的示意，不是数据库结构图。工作区、标签页、窗格、底层终端和 Agent 的 ID 不可随意互换。API 返回的 ID 应视为**不透明字符串**，保留原值；不要自行拼接 `w1:p1`，也不要把 UI 的第一个标签页当作 `tab_id=1`。

显示名称用于可读性，ID 用于稳定定位。Agent 命令中允许的 TARGET 解析与严格的 workspace/tab ID 参数不同。机器配置中的 `PROFILE_ID`、`LABEL_OR_ID`、`SSH_TARGET` 也有不同含义。自动化应创建/列举对象、保存返回的 ID，再对这些 ID 操作。

默认会话名称是 `default`。`HERDR_SESSION` 和根级 `--session NAME` 用于会话选择。`--machine` 则使用保存的机器配置中绑定的远程会话，不能再混入其他启动选项。[S02][S03][S10]

## 2. detach、停止、关闭、恢复不是同一件事

| 操作 | 实际意图 | 需要警惕 |
|---|---|---|
| TUI 的 detach | 离开客户端，server 继续托管终端 | 不会自动“完成”后台任务 |
| `server stop` / `session stop` | 停止托管会话 | 会影响该 server 下的真实进程 |
| `pane close` / `tab close` / `workspace close` | 关闭对应运行对象 | 会影响其中的终端任务 |
| `session delete` | 删除已停止会话的保存状态 | 不是普通清理屏幕操作 |
| `worktree remove` | 删除 Git checkout | 比关闭 Herdr 工作区风险更高 |

Server 重启后恢复工作区结构，并不意味着原进程及其内存原样存活。配置允许恢复支持的 Agent 会话，也依赖 Agent 提供可恢复的会话身份/启动参数；不要据此推断任意 shell 命令都能续跑。

实验性的 live handoff 是另一条运行中交接路径，不应与普通持久会话恢复混为一谈。默认工作流使用常规更新和显式重启；只有理解版本/协议兼容风险时才考虑 handoff。[S02][S04][S06][S07][S13]

## 3. Agent 状态的两套集合

| 值 | 阅读状态时的含义 | `agent wait` / `prompt --until` | `pane report-agent --state` |
|---|---|---|---|
| `idle` | 当前不在工作、可等待下一步输入 | 接受 | 接受 |
| `working` | 正在工作 | 接受 | 接受 |
| `blocked` | 等待人工输入、确认或其他介入 | 接受 | 接受 |
| `done` | 对外呈现的完成状态 | 接受 | **不接受** |
| `unknown` | 无法可靠识别当前状态 | 接受，但须显式指定才进入默认等待以外的匹配 | 接受 |

`unknown` 不是 `idle`，`blocked` 也不是业务成功。`agent wait` 默认的匹配集合是 **idle / done / blocked**。`--until` 可重复，关系是**或**，不是先后顺序。

`agent wait` 等待的是状态条件，不是新任务。调用瞬间已匹配便可能立即返回。`agent prompt --wait` 加入了提交后的启动观察，但仍不追踪请求对应的 turn：原本正在工作的 Agent 可能以旧任务完成状态满足等待。因此，业务自动化必须核验 Agent 输出，不能把命令退出 0 直接等同于“这次需求已完成”。

当 prompt 被接受且开始于非 working 状态，5000ms 内没有观察到 working 或 blocked，会报 `agent_prompt_stalled`；更早到期的调用方 timeout 则先返回 timeout。两者都不构成安全重复提交的依据。[S01][S05]

## 4. 输出快照来源与行数

| `--source` | 选择什么 | 主要用途 |
|---|---|---|
| `visible` | 当前渲染的可见屏幕 | 查看菜单、确认框、当前 TUI |
| `recent` | 终端近期输出/滚动历史，保留读取视图中的软换行 | 常规日志检查；默认来源 |
| `recent-unwrapped` | 近期输出合并软换行 | 阅读长命令、较长回答、长日志 |
| `detection` | 状态检测使用的底部快照 | 排查识别问题，不代表全部日志 |

近期快照默认取最后 **80 个渲染行**；显式 `--lines N` 限制行数。合并软换行发生在选择渲染行之后，所以 80 个渲染行不一定等于 80 条完整日志。`visible` / `detection` 使用各自完整视图，显式行数再截取；不要把所有来源都理解成同一个 80 行缓存。

`pane read` / `agent read` 的 `--format text|ansi` 和 `--ansi` 控制输出格式。`pane read` 另有 `--raw`，`agent read` 没有。`detection` 是检测用纯文本视图，不是重放原始控制序列的途径。

`pane wait-output` 的公开来源集合只有 visible、recent、recent-unwrapped。匹配先检查已有快照；recent 两种来源的匹配会合并软换行。`--regex` 使用 Rust 正则且逐行匹配，不能把它当成任意 PCRE 或跨多行全文正则。`--raw` 保留 ANSI 会使颜色/控制码参与匹配，可能导致表面相同的字符串不命中。

运行时还接受 `recent_unwrapped` 兼容拼写；文档和脚本统一使用 `recent-unwrapped`。[S01][S03][S04]

## 5. `--kind` 的 24 个规范 Agent 名称

这些是该版本源码中的 Agent 类型枚举，不是“所有类型具有完全相同集成能力”的承诺。程序仍需自行安装并完成登录配置。以下名称可以作为 `agent start --kind` 的规范值。[S01][S18]

| 规范 KIND | 规范启动程序 | 备注 |
|---|---|---|
| `pi` | `pi` |  |
| `claude` | `claude` | 识别别名含 `claude-code` |
| `codex` | `codex` |  |
| `gemini` | `gemini` |  |
| `cursor` | `cursor-agent` | Windows 对应启动程序可能使用 `.cmd` |
| `devin` | `devin` | 别名含 `devin-cli`、`devin cli` |
| `agy` | `agy` | 识别别名含 `antigravity`、`antigravity-cli` |
| `cline` | `cline` | 识别别名含 `.cline` |
| `omp` | `omp` |  |
| `mastracode` | `mastracode` | 别名含 `mastra-code`、`mastra code` |
| `opencode` | `opencode` | 别名含 `opencode2`、`open-code` |
| `copilot` | `copilot` | 别名含 `github-copilot`、`ghcs` |
| `kimi` | `kimi` | 别名含 `kimi-code`、`kimi code` |
| `kiro` | `kiro-cli` |  |
| `droid` | `droid` |  |
| `amp` | `amp` | 识别别名含 `amp-local` |
| `grok` | `grok` | 识别别名含 `grok-build` |
| `hermes` | `hermes` | 识别别名含 `hermes-agent` |
| `kilo` | `kilo` | 别名含 `kilo-code`、`kilo code` |
| `qodercli` | `qodercli` | 别名含 `qoderclicn`、`qoder`、`qodercn` |
| `qwen` | `qwen` | 别名含 `qwen-code`、`qwen code` |
| `letta` | `letta` | 内置集成目标仍列为实验性 |
| `maki` | `maki` |  |
| `muse` | `muse` | 别名含 `muse-code`、`muse-cli`，识别版本化 `muse-bin-*` |

别名表描述检测/名称归一化路径，不代表每一种别名都在 `--help` 的枚举里显示。调用示例优先使用左侧规范 KIND。

## 6. 可安装的集成目标不等于 Agent KIND

17 个常规集成目标：

```text
pi  omp  claude  codex  copilot  devin  droid  kimi  opencode
kilo  hermes  qodercli  qwen  cursor  mastracode  antigravity-cli  grok
```

另有实验性 `letta`。尤其注意：

```bash
herdr agent start my-agy --kind agy --pane "$pane_id"
herdr integration install antigravity-cli
```

这是两个命名体系，不能为了“统一”把第二个参数改为 agy。集成安装写入 Agent 的 hook/config，通常用于提升状态与会话识别可靠性；不同目标提供的生命周期、会话恢复能力不完全一致。先查看 `integration status`，按具体目标安装/更新。[S17][S19][S20]

## 7. 三种输入方式及其完成边界

| 命令 | 发送什么 | 返回成功能证明什么 |
|---|---|---|
| `pane send-text` | 字面文本，无 Enter | 输入请求被接受 |
| `pane send-keys` / `agent send-keys` | 键盘事件序列 | 按键请求被接受 |
| `pane run` | 文本 + Enter 的一次提交 | 命令被提交，不是进程退出成功 |
| `agent prompt` | 面向 Agent 的 prompt 提交 | 以该命令返回语义为准；不等于任务已完成 |
| `agent prompt --wait` | 提交并等待状态 | 某个状态条件被满足，仍需核验任务结果 |

`pane run` 不是 `exec` 返回退出码的远程调用接口。要可靠判断自己控制的 shell 任务，输出本次运行唯一的结束标记并带退出码，再用 `wait-output` 匹配。匹配应锚定完整一行，避免 shell 回显中的标记误命中。

按键名中 `esc` 是规范 Escape 名称，`escape` 仍被接受。组合键如 `ctrl+c`；支持的常见修饰符包含 ctrl/control、alt、shift、cmd、super，实际效果仍取决于终端/平台。不要把 `ctrl+c` 当作三个可见字符输入。[S03][S04][S05]

## 8. CLI 输出分类与错误处理

| 类别 | 代表命令 | 脚本处理方式 |
|---|---|---|
| API JSON 响应 | workspace/tab/pane 查询与创建、agent 查询等 | 按具体 schema 读取 `result` |
| 默认人类文本，可选 JSON | status、machine list/status、session list/stop/delete、plugin list | 需要结构化读取时显式 `--json` |
| 直接文本 / ANSI | pane read、agent read | 保存或按文本处理，不直接假设 JSON |
| 成功通常无正文 | pane send-text/send-keys/run/report-*、release-agent、workspace report-metadata | 首先检查退出码 |
| 持续 NDJSON 流 | terminal session control/observe | 逐行解码，处理持续流与关闭事件 |
| 本地文件/脚本文本 | completion、--default-config、--skill、config-dir | 按对应文件格式保存 |

通用 API 响应常见形式为 `{ "id": ..., "result": ... }`，API 错误写入 stderr，常见形态为 `{ "id": ..., "error": { "code": ..., "message": ... } }`。但参数错误、本地工具错误等也可能是普通文本 stderr；**不是所有 stderr 都能直接交给 JSON parser**。

常用退出约定：成功 0；运行/API 失败通常 1；使用方式错误通常 2。`config check` 发现问题也返回 1。不要把所有非零都解释成“目标对象不存在”。

`api schema --json` 输出 schema；`api schema --output PATH` 写文件；两者互斥。`agent explain --json` 输出解释对象，不是固定的 API 响应外层。自动化应为正在调用的命令确定契约，而不是给整个 CLI 写一个盲目的 `.result` 解包器。[S03][S04][S05][S14][S15][S16]

## 9. SSH 的两条路径与允许路由的命令

`herdr --remote SSH_TARGET` 是远程 **TUI 附着**。`herdr --machine LABEL_OR_ID ...` 是对已保存机器的 **API 路由**。在 TUI 里选中远程机器，不会让另一个本地 shell 发出的 `herdr pane ...` 自动变成远程命令。

`--machine` 解析 ID 优先；名称必须唯一且大小写精确匹配，配置必须处于启用状态。SSH 别名不自动等同于 Herdr label。它使用保存配置的会话，不能与 `--session`、`--remote` 等启动选项组合。不存在“远程失败后自动落到本机继续执行”的安全承诺；写请求也不应在连接错误后盲目重放。[S10]

v0.9.3 的路由白名单：

| 分类 | 可路由命令 |
|---|---|
| 对象 API | workspace、worktree、tab、pane、notification |
| Agent | 除 `attach` 和 `explain --file` 外的 Agent API 命令 |
| 快照/状态 | `api snapshot`、`status server` |
| 插件 API | link、unlink、enable、disable、list、action、log/logs、pane |
| Server API | stop、reload-config、agent-manifests、reload-agent-manifests |

本地 update、config、machine 管理、session 管理、integration 安装、plugin install/uninstall/config-dir、api schema，以及 terminal 附着/流，不在这个白名单。`server update-agent-manifests` 也不在其中。所有路径参数均应以**实际执行机器**的文件系统为准。[S10，特别是 `validate_machine_command`]

## 10. 配置、环境变量与展示模板

默认配置可由当前版本二进制直接导出：

```bash
herdr --default-config > herdr-default.toml
herdr config check
```

常见 Unix 配置路径为 `~/.config/herdr/config.toml`；`HERDR_CONFIG_PATH` 可显式覆盖。跨平台路径以该二进制的 `herdr --help` 与实际平台解析为准。本节是与 CLI 操作直接相关的配置摘要，不冒充整个应用配置 schema。

| 配置项 | v0.9.3 内置默认/用途 |
|---|---|
| `terminal.new_cwd` | `follow`，跟随当前目录策略 |
| `server.headless_cols` / `headless_rows` | `120` / `40` |
| `worktrees.directory` | `~/.herdr/worktrees` |
| `session.resume_agents_on_restore` | `true`，尝试恢复支持的 Agent 会话 |
| `session.startup_per_agent_delay_ms` | `100` |
| `experimental.pane_history` | `false` |
| `ui.window_title` | `{hostname}: {workspace}` |
| `ui.toast.delivery` | `off`；其他投递方式有 herdr、terminal、system |
| `ui.toast.herdr.position` | `bottom-right` |

相关环境变量摘要：

| 变量 | 用途 |
|---|---|
| `HERDR_CONFIG_PATH` | 显式指定配置路径 |
| `HERDR_SESSION` | 命名会话选择 |
| `HERDR_SOCKET_PATH` | API socket 路径覆盖，通常用于高级连接场景 |
| `HERDR_ENV` | Herdr 管理的环境标记 |
| `HERDR_PANE_ID` | 当前进程所属窗格 |
| `HERDR_TAB_ID` | 当前进程所属标签页 |
| `HERDR_WORKSPACE_ID` | 当前进程所属工作区 |
| `HERDR_LOG` | 日志过滤配置，例如 `herdr=debug` |
| `HERDR_DISABLE_SOUND` | 禁用声音的环境开关 |

`ui.window_title` 的占位符包含 `{hostname}`、`{workspace}`、`{tab}`、`{pane}`、`{terminal_title}`，用 `{{` / `}}` 表示字面花括号。自定义展示元数据的 token 可以在支持的侧栏配置位置以 `$name` 形式引用。

注意双重解释：shell 会先展开 `$name`，Herdr 配置才处理自己的 token。需要把字面 `$build` 写到配置/参数时使用单引号或正确转义。展示 token 不是 jj revset，Herdr 也没有 jj 那种 revision 集合表达式系统。[S02][S03][S04][S06]

## 11. 常用默认快捷键

默认前缀是 **Ctrl+B**。表中的 `前缀 → x` 表示先按 Ctrl+B，再按 x，不是一直按住所有键。自定义配置可能覆盖这些默认值。[S02]

| 动作 | 默认键 |
|---|---|
| 显示帮助 | 前缀 → `?` |
| 打开设置 | 前缀 → `s` |
| 脱离客户端 | 前缀 → `q` |
| 重载配置 | 前缀 → `Shift+R` |
| 打开通知目标 | 前缀 → `o` |
| 工作区选择器 | 前缀 → `w` |
| 跳转 | 前缀 → `g` |
| 新建工作区 | 前缀 → `Shift+N` |
| 新建 Git worktree | 前缀 → `Shift+G` |
| 重命名工作区 | 前缀 → `Shift+W` |
| 关闭工作区 | 前缀 → `Shift+D` |
| 新建标签页 | 前缀 → `c` |
| 重命名标签页 | 前缀 → `Shift+T` |
| 上/下一个标签页 | 前缀 → `p` / `n` |
| 标签页 1..9 | 前缀 → `1`..`9` |
| 关闭标签页 | 前缀 → `Shift+X` |
| 重命名窗格 | 前缀 → `Shift+P` |
| 编辑滚动历史 | 前缀 → `e` |
| 左/下/上/右窗格 | 前缀 → `h` / `j` / `k` / `l` |
| 下/上一个窗格 | 前缀 → `Tab` / `Shift+Tab` |
| 向右分割 | 前缀 → `v` |
| 向下分割 | 前缀 → `-` |
| 关闭窗格 | 前缀 → `x` |
| 放大/恢复窗格 | 前缀 → `z` |
| 调整尺寸模式 | 前缀 → `r` |
| 切换侧栏 | 前缀 → `b` |

在直接 attach 中，Ctrl+B 连按两次可向程序发送字面 Ctrl+B。需要精确的本机配置时，以 `--default-config` 和当前 `config.toml` 为准，不能假定默认键一定未被终端或操作系统截获。


---

# 全部公开命令的中文帮助

> 125 个节点（含根），按 v0.9.3 的公开 spec 树组织。说明基于源码重建，不是二进制输出转储。命令顺序保留源树的分组顺序；完整参数互斥关系与执行限制还需看每节补注。

## `herdr`

```text
面向 AI 编程 Agent 的终端工作区管理器。

Usage: herdr [OPTIONS]
       herdr [--session <NAME>] <COMMAND>
       herdr --machine <LABEL-OR-ID> <COMMAND>

Commands:
  completion                 生成 shell 补全脚本。
  update                     下载并安装更新。
  status                     查看客户端与运行中 server 的状态。
  config                     管理本地配置。
  channel                    管理 stable / preview 更新通道。
  machine                    管理保存的 SSH machine 配置。
  server                     运行或控制无界面后台 server。
  api                        检查 socket API 元数据和会话状态。
  workspace                  通过 API 管理工作区。
  worktree                   管理基于 Git worktree 的工作区。
  tab                        通过 API 管理工作区内的标签页。
  notification               显示 Herdr 通知。
  agent                      控制和检查已识别的 Agent 窗格。
  pane                       管理终端窗格、输出、输入及 Agent 报告。
  terminal                   附着或观察底层终端流。
  session                    管理命名持久会话。
  integration                安装和检查内置 Agent 集成。
  plugin                     安装、关联及运行工作流插件。

Options:
  --session <NAME>             使用或创建命名持久会话；可用于本地启动和会话范围的命令。
  --machine <LABEL-OR-ID>      将受支持的 API 命令路由到已保存且启用的 SSH machine。不能与其他启动选项混用。
  --remote <TARGET>            通过 SSH 连接远程 Herdr TUI；不是任意 CLI 子命令的远程执行开关。
  --remote-keybindings <MODE>  远程 TUI 使用 local 或 server 快捷键；默认 local。
  --handoff                    为更新或远程连接显式启用实验性 live handoff。
  --default-config             输出此二进制内置的默认 TOML 配置并退出。
  --skill                      输出内置的 Agent 操作说明文件并退出。
  -V, --version                打印版本并退出。
  -h, --help                   打印该命令的帮助。
```

### 行为与限制

不带子命令时进入交互式 TUI。后台 server 管理终端，detach 不等于停止 server。

这是按统一 spec 补齐的完整命令索引。实际根帮助由 main.rs 手写，未列全 terminal、plugin 等命令；不是根帮助的逐字终端转储。

优先使用 herdr pane read --help 这种“完整命令路径紧接 --help”的形式。没有通用的 herdr help <COMMAND>。

全局选项放在子命令之前；不要假定每个手写解析器都支持 --option=value。示例统一使用 --option VALUE。

源码：[S01] [S02] [S03]


## `herdr completion`

```text
生成 shell 补全脚本。

Usage: herdr completion <SHELL>

Aliases: completions

Arguments:
  <SHELL>  bash、zsh、fish、powershell、elvish。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

脚本写到标准输出；生成脚本本身不修改 shell 配置。

源码：[S12]


## `herdr update`

```text
下载并安装更新。

Usage: herdr update [OPTIONS]

Options:
  --handoff   安装后尝试实验性的运行中 server 交接。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

更新通道由 channel 管理。包管理器安装的构建可能要求通过原包管理器更新。

升级客户端文件不等于所有已运行 server 都已换成新版本；用 status 比较。

源码：[S01] [S02]


## `herdr status`

```text
查看客户端与运行中 server 的状态。

Usage: herdr status [OPTIONS] [COMMAND]

Commands:
  server                     查看运行中 server 状态。
  client                     查看本地客户端状态。

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

本命令自身可执行；server/client 子命令可只查看一侧。

源码：[S01] [S16]


## `herdr status server`

```text
查看运行中 server 状态。

Usage: herdr status server [OPTIONS]

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S16]


## `herdr status client`

```text
查看本地客户端状态。

Usage: herdr status client [OPTIONS]

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S16]


## `herdr config`

```text
管理本地配置。

Usage: herdr config <COMMAND>

Commands:
  check                      校验 config.toml 并输出诊断。
  reset-keys                 移除自定义快捷键配置以回到内置默认。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S03]


## `herdr config check`

```text
校验 config.toml 并输出诊断。

Usage: herdr config check

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

没有问题退出 0；发现问题退出 1。它不是对全部 Agent、插件、SSH 环境的健康检查。

源码：[S01] [S03]


## `herdr config reset-keys`

```text
移除自定义快捷键配置以回到内置默认。

Usage: herdr config reset-keys

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会修改配置文件并生成 config.toml.bak-keybind-v2-<timestamp> 备份。

删除 [keys]、[keys.indexed]、[[keys.command]] 的自定义设置，保留其他配置。运行中 server 可用 server reload-config 重载。

源码：[S01] [S03]


## `herdr channel`

```text
管理 stable / preview 更新通道。

Usage: herdr channel <COMMAND>

Commands:
  show                       打印当前配置的更新通道。
  set                        选择更新通道。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S03]


## `herdr channel show`

```text
打印当前配置的更新通道。

Usage: herdr channel show

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S03]


## `herdr channel set`

```text
选择更新通道。

Usage: herdr channel set <CHANNEL>

Arguments:
  <CHANNEL>  stable 或 preview。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

并非只改变一个显示值：保存通道后，直接安装版本会进入自更新流程；包管理器构建会给出相应指引。

配置 TOML 无法安全解析时不会静默覆盖。

源码：[S01] [S03]


## `herdr machine`

```text
管理保存的 SSH machine 配置。

Usage: herdr machine <COMMAND>

Commands:
  list                       列出保存的机器配置。
  status                     检查已保存机器的连接状态。
  reconnect                  从当前终端重新进行连接/认证。
  add                        准备远程 Herdr 并保存机器配置。
  rename                     重命名保存的机器配置。
  remove                     移除保存的机器配置。
  enable                     启用保存的机器配置。
  disable                    禁用保存的机器配置。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

配置 ID、显示 label 与 SSH_TARGET 不是同一个字段。

源码：[S11] [S10]


## `herdr machine list`

```text
列出保存的机器配置。

Usage: herdr machine list [OPTIONS]

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

源码：[S11] [S10]


## `herdr machine status`

```text
检查已保存机器的连接状态。

Usage: herdr machine status [LABEL_OR_ID] [OPTIONS]

Arguments:
  [LABEL_OR_ID]  只检查一个配置；省略时检查已保存的机器。

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

这是新发起的状态探测，不等同于某个 TUI 客户端正在显示的连接状态；不会弹出交互认证提示。

源码：[S11] [S10]


## `herdr machine reconnect`

```text
从当前终端重新进行连接/认证。

Usage: herdr machine reconnect <LABEL_OR_ID>

Arguments:
  <LABEL_OR_ID>  已保存的配置 ID 或唯一显示名称。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

不执行安装或升级；与 machine add 的准备流程不同。

源码：[S11] [S10]


## `herdr machine add`

```text
准备远程 Herdr 并保存机器配置。

Usage: herdr machine add <SSH_TARGET> [OPTIONS]

Arguments:
  <SSH_TARGET>  SSH 配置别名或 SSH 目标，例如 build-host；不是 Herdr profile ID。

Options:
  --label <LABEL>          本地保存的显示名；未指定时由主机与会话信息产生。
  --remote-session <NAME>  绑定的远程命名会话。
  -h, --help               打印该命令的帮助。
```

### 行为与限制

交互流程可能发现并询问远程会话。安装、升级、重启或重置操作以提示为准；重置可能终止远程进程。

该配置保存后，使用 herdr --machine <label-or-id> ... 执行允许的 API 命令。

源码：[S11] [S10]


## `herdr machine rename`

```text
重命名保存的机器配置。

Usage: herdr machine rename <PROFILE_ID> --label <LABEL>

Arguments:
  <PROFILE_ID>  配置 ID；此处不写 SSH_TARGET。

Options:
  --label <LABEL>  新的显示名称，必需。
  -h, --help       打印该命令的帮助。
```

源码：[S11] [S10]


## `herdr machine remove`

```text
移除保存的机器配置。

Usage: herdr machine remove <PROFILE_ID>

Arguments:
  <PROFILE_ID>  machine list 返回的配置 ID。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

只移除本地连接配置，不负责停止远程 server。

源码：[S11] [S10]


## `herdr machine enable`

```text
启用保存的机器配置。

Usage: herdr machine enable <PROFILE_ID>

Arguments:
  <PROFILE_ID>  machine list 返回的配置 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S11] [S10]


## `herdr machine disable`

```text
禁用保存的机器配置。

Usage: herdr machine disable <PROFILE_ID>

Arguments:
  <PROFILE_ID>  machine list 返回的配置 ID。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

禁用连接配置，不负责停止远程 server。

源码：[S11] [S10]


## `herdr server`

```text
运行或控制无界面后台 server。

Usage: herdr server [COMMAND]

Commands:
  stop                       停止当前目标 server。
  reload-config              让运行中的 server 重载配置。
  agent-manifests            查看当前启用的 Agent 检测 manifest。
  update-agent-manifests     获取并重载 Agent 检测 manifest。
  reload-agent-manifests     重载本地 Agent 检测 manifest 覆盖配置。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

直接运行启动 headless server。普通 TUI 客户端退出、detach 与 server stop 是不同操作。

源码：[S01] [S13]


## `herdr server stop`

```text
停止当前目标 server。

Usage: herdr server stop

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

破坏性操作：其托管的终端及进程会受影响；不要把它当成 detach。

源码：[S01] [S13]


## `herdr server reload-config`

```text
让运行中的 server 重载配置。

Usage: herdr server reload-config

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S13]


## `herdr server agent-manifests`

```text
查看当前启用的 Agent 检测 manifest。

Usage: herdr server agent-manifests [OPTIONS]

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S13]


## `herdr server update-agent-manifests`

```text
获取并重载 Agent 检测 manifest。

Usage: herdr server update-agent-manifests [OPTIONS]

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

这是获取检测规则，不是更新 Claude/Codex 等 Agent 可执行文件；--machine 路由不允许这个本地获取操作。

源码：[S01] [S13]


## `herdr server reload-agent-manifests`

```text
重载本地 Agent 检测 manifest 覆盖配置。

Usage: herdr server reload-agent-manifests

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S13]


## `herdr api`

```text
检查 socket API 元数据和会话状态。

Usage: herdr api <COMMAND>

Commands:
  snapshot                   打印当前会话的实时运行快照。
  schema                     查看或导出当前二进制内置 API schema。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S14] [S15]


## `herdr api snapshot`

```text
打印当前会话的实时运行快照。

Usage: herdr api snapshot

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

这是实时 API 查询，依赖目标 server；与内置 api schema 不同。

源码：[S01] [S14] [S15]


## `herdr api schema`

```text
查看或导出当前二进制内置 API schema。

Usage: herdr api schema [OPTIONS]

Options:
  --json           输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  --output <PATH>  将完整 schema 写入文件。
  -h, --help       打印该命令的帮助。
```

### 行为与限制

不加参数输出概要。--json 与 --output 在实际解析器中互斥。

schema 随客户端二进制打包，不需要在线 server；应与目标 server 的协议版本核对。

源码：[S01] [S14] [S15]


## `herdr workspace`

```text
通过 API 管理工作区。

Usage: herdr workspace <COMMAND>

Commands:
  list                       列出工作区。
  create                     创建工作区及其初始 tab / pane。
  get                        查看工作区。
  focus                      切换到工作区。
  rename                     重命名工作区。
  report-metadata            上报仅用于展示的工作区元数据。
  close                      关闭工作区。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S06]


## `herdr workspace list`

```text
列出工作区。

Usage: herdr workspace list

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S06]


## `herdr workspace create`

```text
创建工作区及其初始 tab / pane。

Usage: herdr workspace create [OPTIONS]

Options:
  --cwd <PATH>       新进程的工作目录；传入目标机器可访问的路径。
  --label <TEXT>     设置显示名称；含空格时整体加引号。
  --env <KEY=VALUE>  设置启动进程的环境变量；可重复。相同键后值覆盖前值，键不得为空。
  --focus            创建后切换焦点到新对象。
  --no-focus         创建后不改变当前焦点；不要与 --focus 同时传入。
  -h, --help         打印该命令的帮助。
```

### 行为与限制

默认不抢焦点。

成功 JSON 中可读取 .result.workspace.workspace_id、.result.tab.tab_id、.result.root_pane.pane_id；不要通过名称猜 ID。

源码：[S01] [S06]


## `herdr workspace get`

```text
查看工作区。

Usage: herdr workspace get <workspace_id>

Arguments:
  <workspace_id>  workspace list/create 返回的工作区 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S06]


## `herdr workspace focus`

```text
切换到工作区。

Usage: herdr workspace focus <workspace_id>

Arguments:
  <workspace_id>  workspace list/create 返回的工作区 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S06]


## `herdr workspace rename`

```text
重命名工作区。

Usage: herdr workspace rename <WORKSPACE_ID> <LABEL>...

Arguments:
  <WORKSPACE_ID>  目标工作区 ID。
  <LABEL>...      名称文本；建议整体加引号，解析器会连接多个词。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S06]


## `herdr workspace report-metadata`

```text
上报仅用于展示的工作区元数据。

Usage: herdr workspace report-metadata <WORKSPACE_ID> --source <ID> [OPTIONS]

Arguments:
  <WORKSPACE_ID>  目标工作区 ID。

Options:
  --source <ID>         非空来源标识，必需；用于区分不同报告方。
  --token <NAME=VALUE>  设置自定义展示 token；可重复。
  --clear-token <NAME>  清除指定 token；可重复。
  --seq <N>             来源提供的顺序编号，用于报告更新顺序；这是计数值，不是时间戳。
  --ttl-ms <N>          展示元数据的有效期，单位毫秒；省略时采用服务端默认策略。
  -h, --help            打印该命令的帮助。
```

### 行为与限制

必须至少设置或清除一个 token。不改变 Agent 的生命周期状态。成功时通常不打印正文。

源码：[S01] [S06]


## `herdr workspace close`

```text
关闭工作区。

Usage: herdr workspace close <workspace_id>

Arguments:
  <workspace_id>  目标工作区 ID。

Options:
  -h, --help  打印该命令的帮助。
```

### 运行时补充（未完整列入统一帮助）

- `--group`：实际解析器接受。关闭关联的 workspace 组；放在 workspace_id 之后。

### 行为与限制

关闭 Herdr 工作区不等于删除 Git checkout。要删除 worktree 使用 worktree remove，并先检查未提交数据。

带关联工作区的主工作区可能要求 --group，避免误关闭整组。

源码：[S01] [S06]


## `herdr worktree`

```text
管理基于 Git worktree 的工作区。

Usage: herdr worktree <COMMAND>

Commands:
  list                       列出仓库关联的 worktree 工作区。
  create                     创建 Git worktree 并打开对应工作区。
  open                       打开已经存在的 Git worktree。
  remove                     删除工作区对应的 Git worktree checkout。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

这里是真正的 Git worktree，不是 jj workspace。所有子命令默认输出 JSON。

源码：[S01] [S07]


## `herdr worktree list`

```text
列出仓库关联的 worktree 工作区。

Usage: herdr worktree list [OPTIONS]

Options:
  --workspace <ID>    从指定 Herdr workspace 解析 Git 仓库。
  --cwd <PATH>        从指定目录解析 Git 仓库；与 --workspace 二选一。
  --trust-repository  仅对本次命令解析到的仓库显式授予信任；不是全局修改 Git 的 safe.directory。
  -h, --help          打印该命令的帮助。
```

### 运行时补充（未完整列入统一帮助）

- `--json`：兼容参数：解析器接受，但默认已经是 JSON，不改变输出。

源码：[S01] [S07]


## `herdr worktree create`

```text
创建 Git worktree 并打开对应工作区。

Usage: herdr worktree create [OPTIONS]

Options:
  --workspace <ID>    从指定 Herdr workspace 解析 Git 仓库。
  --cwd <PATH>        从指定目录解析 Git 仓库；与 --workspace 二选一。
  --branch <NAME>     分支名；已有分支用于检出，否则创建新分支。
  --base <REF>        创建新分支的基准，未指定时以仓库默认/HEAD 规则处理。
  --path <PATH>       检出目录；省略时由 worktrees.directory、仓库和分支名生成。
  --label <TEXT>      设置显示名称；含空格时整体加引号。
  --focus             创建后切换焦点到新对象。
  --no-focus          创建后不改变当前焦点；不要与 --focus 同时传入。
  --trust-repository  仅对本次命令解析到的仓库显式授予信任；不是全局修改 Git 的 safe.directory。
  -h, --help          打印该命令的帮助。
```

### 运行时补充（未完整列入统一帮助）

- `--json`：兼容参数；默认已输出 JSON。

### 行为与限制

是磁盘与仓库写操作，会创建 checkout / 分支，不能当作纯 UI 标签页创建。

源码：[S01] [S07]


## `herdr worktree open`

```text
打开已经存在的 Git worktree。

Usage: herdr worktree open [OPTIONS]

Options:
  --workspace <ID>    从指定 Herdr workspace 解析 Git 仓库。
  --cwd <PATH>        从指定目录解析 Git 仓库；与 --workspace 二选一。
  --path <PATH>       选择现有 worktree 路径；与 --branch 二选一。
  --branch <NAME>     选择现有 worktree 的分支；与 --path 二选一。
  --label <TEXT>      设置显示名称；含空格时整体加引号。
  --focus             创建后切换焦点到新对象。
  --no-focus          创建后不改变当前焦点；不要与 --focus 同时传入。
  --trust-repository  仅对本次命令解析到的仓库显式授予信任；不是全局修改 Git 的 safe.directory。
  -h, --help          打印该命令的帮助。
```

### 运行时补充（未完整列入统一帮助）

- `--json`：兼容参数；默认已输出 JSON。

### 行为与限制

实际解析器要求 --path 或 --branch；不是 create 的另一种拼写。

源码：[S01] [S07]


## `herdr worktree remove`

```text
删除工作区对应的 Git worktree checkout。

Usage: herdr worktree remove --workspace <ID> [OPTIONS]

Options:
  --workspace <ID>    要删除其 checkout 的 Herdr 工作区 ID，必需。
  --force             请求强制删除；可能丢失未提交文件，务必先检查与备份。
  --trust-repository  仅对本次命令解析到的仓库显式授予信任；不是全局修改 Git 的 safe.directory。
  -h, --help          打印该命令的帮助。
```

### 运行时补充（未完整列入统一帮助）

- `--json`：兼容参数；默认已输出 JSON。

### 行为与限制

调用 Git 的 worktree 删除语义，不自动等同于删除该分支；与 workspace close 的风险不同。

源码：[S01] [S07]


## `herdr tab`

```text
通过 API 管理工作区内的标签页。

Usage: herdr tab <COMMAND>

Commands:
  list                       列出标签页。
  create                     创建标签页。
  get                        查看标签页。
  focus                      切换标签页。
  close                      关闭标签页及其窗格。
  rename                     重命名标签页。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S08]


## `herdr tab list`

```text
列出标签页。

Usage: herdr tab list [OPTIONS]

Options:
  --workspace <WORKSPACE_ID>  限定工作区。
  -h, --help                  打印该命令的帮助。
```

源码：[S01] [S08]


## `herdr tab create`

```text
创建标签页。

Usage: herdr tab create [OPTIONS]

Options:
  --workspace <WORKSPACE_ID>  目标工作区；自动化建议明确指定。
  --cwd <PATH>                新进程的工作目录；传入目标机器可访问的路径。
  --label <TEXT>              设置显示名称；含空格时整体加引号。
  --env <KEY=VALUE>           设置启动进程的环境变量；可重复。相同键后值覆盖前值，键不得为空。
  --focus                     创建后切换焦点到新对象。
  --no-focus                  创建后不改变当前焦点；不要与 --focus 同时传入。
  -h, --help                  打印该命令的帮助。
```

### 行为与限制

默认不抢焦点。

源码：[S01] [S08]


## `herdr tab get`

```text
查看标签页。

Usage: herdr tab get <tab_id>

Arguments:
  <tab_id>  标签页 ID，不是可见序号 1、2、3。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S08]


## `herdr tab focus`

```text
切换标签页。

Usage: herdr tab focus <tab_id>

Arguments:
  <tab_id>  标签页 ID，不是可见序号 1、2、3。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S08]


## `herdr tab close`

```text
关闭标签页及其窗格。

Usage: herdr tab close <tab_id>

Arguments:
  <tab_id>  标签页 ID，不是可见序号 1、2、3。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

关闭操作会影响其中正在运行的终端任务。

源码：[S01] [S08]


## `herdr tab rename`

```text
重命名标签页。

Usage: herdr tab rename <TAB_ID> <LABEL>...

Arguments:
  <TAB_ID>    标签页 ID。
  <LABEL>...  名称，建议加引号。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S08]


## `herdr notification`

```text
显示 Herdr 通知。

Usage: herdr notification <COMMAND>

Commands:
  show                       显示一条通知。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01]


## `herdr notification show`

```text
显示一条通知。

Usage: herdr notification show <TITLE> [OPTIONS]

Arguments:
  <TITLE>  通知标题。

Options:
  --body <TEXT>          正文。
  --position <POSITION>  Herdr 内部 toast 位置：top-left、top-right、bottom-left、bottom-right。
  --sound <SOUND>        声音类别：none、done、request；默认 none。
  -h, --help             打印该命令的帮助。
```

### 行为与限制

遵守 ui.toast 的投递配置；默认配置 delivery="off"，命令不会强制绕过关闭设置。

源码：[S01]


## `herdr agent`

```text
控制和检查已识别的 Agent 窗格。

Usage: herdr agent <COMMAND>

Commands:
  list                       列出当前识别到的 Agent。
  get                        查看 Agent 的结构化状态。
  read                       读取 Agent 的终端输出。
  send-keys                  向 Agent 发送按键。
  prompt                     向 Agent 提交提示词。
  rename                     给已识别的 Agent 命名或清除名称。
  focus                      切换到 Agent 所在位置。
  wait                       等待 Agent 状态匹配。
  attach                     直接附着到 Agent 的终端。
  start                      在现有交互 shell 窗格内启动支持的 Agent。
  explain                    解释 Agent 检测状态及证据。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

TARGET 可使用命令接受的 Agent/窗格标识或 Agent 名称；不要把 workspace 的显示名当作 Agent ID。

Agent 检测、内置集成、Agent 可执行程序的安装是三件不同的事。

源码：[S01] [S05]


## `herdr agent list`

```text
列出当前识别到的 Agent。

Usage: herdr agent list

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S05]


## `herdr agent get`

```text
查看 Agent 的结构化状态。

Usage: herdr agent get <target>

Arguments:
  <target>  目标 Agent 或所在窗格的可解析标识。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S05]


## `herdr agent read`

```text
读取 Agent 的终端输出。

Usage: herdr agent read <TARGET> [OPTIONS]

Arguments:
  <TARGET>  目标 Agent。

Options:
  --source <SOURCE>  快照来源：visible、recent、recent-unwrapped、detection；默认 recent。
  --lines <N>        限制快照的末尾渲染行数；软换行合并后的逻辑行数可能更少。
  --format <FORMAT>  输出格式：text 或 ansi；默认按普通文本读取。
  --ansi             请求 ANSI 格式；相当于选择 ansi 格式的便捷开关。
  -h, --help         打印该命令的帮助。
```

### 行为与限制

标准输出直接是文本或 ANSI 内容，不是通用 API JSON 外层。

本命令没有 pane read 的 --raw 开关。

源码：[S01] [S05]


## `herdr agent send-keys`

```text
向 Agent 发送按键。

Usage: herdr agent send-keys <TARGET> <KEY>...

Arguments:
  <TARGET>  目标 Agent。
  <KEY>...  一个或多个键名，如 enter、esc、ctrl+c；esc 为规范写法，escape 也接受。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

按键是操作真实交互界面，不是发送新的自然语言 prompt。确认当前屏幕后再操作；不要自动批准未知确认框。

源码：[S01] [S05]


## `herdr agent prompt`

```text
向 Agent 提交提示词。

Usage: herdr agent prompt <TARGET> <TEXT> [OPTIONS]

Arguments:
  <TARGET>  目标 Agent。
  <TEXT>    完整提示词，含空格或换行时整体引用。

Options:
  --wait            提交后等待首次观察到满足条件的状态。
  --until <STATUS>  匹配状态：idle、working、blocked、done、unknown；可重复，多个状态按“或”匹配。
  --timeout <MS>    超时毫秒数；等待命令省略时可无限等待。
  -h, --help        打印该命令的帮助。
```

### 行为与限制

--until 与 --timeout 都要求 --wait。默认匹配 idle、done、blocked。

目标已经 blocked 时，提交在发送任何输入之前被 agent_blocked 拒绝。

接受提交时若不处于 working，--wait 要求在 5000ms 内观察到 working 或 blocked，否则返回 agent_prompt_stalled；调用方超时更早到达则返回 timeout。

不追踪请求与 Agent turn 的因果关系。目标原本已 working 时，正在进行的旧 turn 结束也可能满足等待。

超时或 stalled 不是“提示词肯定没发出”的证明；先 get/read 再决定是否重试，避免重复提交。

源码：[S01] [S05]


## `herdr agent rename`

```text
给已识别的 Agent 命名或清除名称。

Usage: herdr agent rename <TARGET> <NAME>|--clear

Arguments:
  <TARGET>  已识别 Agent 的目标。
  <NAME>    新名称；与 --clear 二选一。

Options:
  --clear     清除自定义 Agent 名称。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

不能通过 rename 把一个普通 shell 声明成 Agent；重命名也不改变 Agent 种类。

源码：[S01] [S05]


## `herdr agent focus`

```text
切换到 Agent 所在位置。

Usage: herdr agent focus <target>

Arguments:
  <target>  目标 Agent。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S05]


## `herdr agent wait`

```text
等待 Agent 状态匹配。

Usage: herdr agent wait <TARGET> [OPTIONS]

Arguments:
  <TARGET>  目标 Agent。

Options:
  --until <STATUS>  匹配状态：idle、working、blocked、done、unknown；可重复，多个状态按“或”匹配。
  --timeout <MS>    超时毫秒数；等待命令省略时可无限等待。
  -h, --help        打印该命令的帮助。
```

### 行为与限制

默认匹配 idle、done、blocked；多个 --until 是“或”。没有 --timeout 时无限等待。

当前状态已经匹配时可立即返回；不是“等待下一轮完成”。unknown 必须显式指定才会匹配。

源码：[S01] [S05]


## `herdr agent attach`

```text
直接附着到 Agent 的终端。

Usage: herdr agent attach <TARGET> [OPTIONS]

Arguments:
  <TARGET>  目标 Agent。

Options:
  --takeover  显式接管已有终端写入控制权。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

交互式 attach，不是一次性 JSON 查询。Ctrl+B 然后 q 退出附着；Ctrl+B 连按两次发送字面 Ctrl+B。

--machine 路由不支持此交互 attach 命令。

源码：[S01] [S05]


## `herdr agent start`

```text
在现有交互 shell 窗格内启动支持的 Agent。

Usage: herdr agent start <NAME> --kind <KIND> --pane <ID> [OPTIONS] [-- [AGENT_ARG]...]

Arguments:
  <NAME>          启动后给该 Agent 使用的名称。
  [AGENT_ARG]...  -- 后的参数直接传给 Agent，不由 Herdr 解释。

Options:
  --kind <KIND>   必需。规范 Agent 种类见“Agent 种类与别名”表，共 24 种。
  --pane <ID>     必需。现有且停在交互式 shell 提示符的 pane ID。
  --timeout <MS>  等待可交互就绪；默认 30000ms，上限 300000ms。
  -h, --help      打印该命令的帮助。
```

### 行为与限制

不会替你安装 Agent 二进制；相关程序需已可在目标环境启动。

成功表示在同一终端检测到预期 Agent 并已准备接受输入，不只是成功写入了一行 shell 命令。

不能把仍在运行前台任务的 pane 当作空闲 shell 直接覆盖启动。

源码：[S01] [S05]


## `herdr agent explain`

```text
解释 Agent 检测状态及证据。

Usage: herdr agent explain [TARGET] [OPTIONS]

Arguments:
  [TARGET]  在线模式的 Agent/窗格目标；本地 --file 模式不使用该参数。

Options:
  --file <PATH>      读取本地 UTF-8 终端文本样本，离线解释检测结果。
  --agent <LABEL>    本地文件样本对应的 Agent 标签；与 --file 配套。
  --json             输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  --format <FORMAT>  text 或 json。
  -v, --verbose      展开详细证据、匹配区域/规则及覆盖来源。
  -h, --help         打印该命令的帮助。
```

### 行为与限制

两种形式：在线 TARGET；或离线 --file PATH --agent LABEL。文件模式与 TARGET 互斥。

--agent 不是在线模式的目标选择器。--json 输出解释对象自身，不保证含 result 外层。

源码：[S01] [S05]


## `herdr pane`

```text
管理终端窗格、输出、输入及 Agent 报告。

Usage: herdr pane <COMMAND>

Commands:
  list                       列出终端窗格。
  current                    解析当前窗格。
  get                        查看一个窗格。
  layout                     查看窗格布局信息。
  process-info               查看窗格进程信息。
  neighbor                   查找某方向上的相邻窗格。
  edges                      查看窗格在布局中的边缘信息。
  focus                      将焦点切到起点窗格某方向的相邻窗格。
  resize                     调整窗格分割尺寸。
  zoom                       切换或设置窗格放大状态。
  read                       读取窗格终端快照。
  rename                     设置或清除窗格显示名。
  input                      设置窗格输入路由。
  split                      分割窗格并创建新终端。
  swap                       交换两个窗格的位置。
  move                       把窗格移到其他标签页或工作区。
  close                      关闭窗格及其终端。
  send-text                  向窗格发送字面文本，不附加 Enter。
  send-keys                  向窗格发送按键序列。
  wait-output                等待窗格快照中出现匹配输出。
  run                        一次提交命令文本与 Enter。
  report-agent               由 hook/集成上报 Agent 生命周期状态。
  report-agent-session       上报 Agent 会话标识及可选恢复参数。
  release-agent              释放某个来源的 Agent 生命周期权威。
  report-metadata            上报仅用于展示的窗格元数据。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S04]


## `herdr pane list`

```text
列出终端窗格。

Usage: herdr pane list [OPTIONS]

Options:
  --workspace <WORKSPACE_ID>  限定工作区。
  -h, --help                  打印该命令的帮助。
```

源码：[S01] [S04]


## `herdr pane current`

```text
解析当前窗格。

Usage: herdr pane current [OPTIONS]

Options:
  --pane <ID>  显式指定作为操作起点的 pane ID。
  --current    使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help   打印该命令的帮助。
```

### 行为与限制

省略显式选择时会使用可用的调用上下文/焦点回退；自动化优先 --pane，避免随用户焦点变化。

源码：[S01] [S04]


## `herdr pane get`

```text
查看一个窗格。

Usage: herdr pane get <pane_id>

Arguments:
  <pane_id>  pane list/create 返回的窗格 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S04]


## `herdr pane layout`

```text
查看窗格布局信息。

Usage: herdr pane layout [OPTIONS]

Options:
  --pane <ID>  显式指定作为操作起点的 pane ID。
  --current    使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help   打印该命令的帮助。
```

源码：[S01] [S04]


## `herdr pane process-info`

```text
查看窗格进程信息。

Usage: herdr pane process-info [OPTIONS]

Options:
  --pane <ID>  显式指定作为操作起点的 pane ID。
  --current    使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help   打印该命令的帮助。
```

### 行为与限制

用于区分交互 shell、前台命令和 Agent 进程；不应只根据窗口标题判断进程是否存在。

源码：[S01] [S04]


## `herdr pane neighbor`

```text
查找某方向上的相邻窗格。

Usage: herdr pane neighbor --direction <DIRECTION> [OPTIONS]

Options:
  --direction <DIRECTION>  方向：left、right、up、down。
  --pane <ID>              显式指定作为操作起点的 pane ID。
  --current                使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help               打印该命令的帮助。
```

源码：[S01] [S04]


## `herdr pane edges`

```text
查看窗格在布局中的边缘信息。

Usage: herdr pane edges [OPTIONS]

Options:
  --pane <ID>  显式指定作为操作起点的 pane ID。
  --current    使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help   打印该命令的帮助。
```

源码：[S01] [S04]


## `herdr pane focus`

```text
将焦点切到起点窗格某方向的相邻窗格。

Usage: herdr pane focus --direction <DIRECTION> [OPTIONS]

Options:
  --direction <DIRECTION>  方向：left、right、up、down。
  --pane <ID>              显式指定作为操作起点的 pane ID。
  --current                使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help               打印该命令的帮助。
```

### 行为与限制

--pane 是方向导航的起点，不是“直接 focus 到这个 ID”的另一种写法。

源码：[S01] [S04]


## `herdr pane resize`

```text
调整窗格分割尺寸。

Usage: herdr pane resize --direction <DIRECTION> [OPTIONS]

Options:
  --direction <DIRECTION>  方向：left、right、up、down。
  --amount <FLOAT>         调整幅度，必须为有限浮点数；不要当作固定的终端列数/行数。
  --pane <ID>              显式指定作为操作起点的 pane ID。
  --current                使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  -h, --help               打印该命令的帮助。
```

### 行为与限制

布局与有效调整范围由运行时判定；手册不臆造此选项未标注的默认值。

源码：[S01] [S04]


## `herdr pane zoom`

```text
切换或设置窗格放大状态。

Usage: herdr pane zoom [PANE_ID] [OPTIONS]

Arguments:
  [PANE_ID]  可选窗格 ID；也可用 --pane 或 --current 选择。

Options:
  --pane <ID>  显式指定作为操作起点的 pane ID。
  --current    使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  --toggle     反转放大状态；未传模式时的默认行为。
  --on         设为放大。
  --off        取消放大。
  -h, --help   打印该命令的帮助。
```

### 行为与限制

--toggle、--on、--off 互斥；不要混合目标选择方式。

源码：[S01] [S04]


## `herdr pane read`

```text
读取窗格终端快照。

Usage: herdr pane read <PANE_ID> [OPTIONS]

Arguments:
  <PANE_ID>  目标窗格 ID。

Options:
  --source <SOURCE>  快照来源：visible、recent、recent-unwrapped、detection；默认 recent。
  --lines <N>        限制快照的末尾渲染行数；软换行合并后的逻辑行数可能更少。
  --format <FORMAT>  输出格式：text 或 ansi；默认按普通文本读取。
  --ansi             请求 ANSI 格式；相当于选择 ansi 格式的便捷开关。
  --raw              保留 ANSI 转义，选择原始 ANSI 读取路径；不是二进制日志导出。
  -h, --help         打印该命令的帮助。
```

### 行为与限制

输出直接是文本/ANSI，不应无条件接 jq。

默认 recent 从末尾近期输出取样；visible 与 detection 的视图不同。见概念章节的快照表。

源码：[S01] [S04]


## `herdr pane rename`

```text
设置或清除窗格显示名。

Usage: herdr pane rename <PANE_ID> [LABEL]... [OPTIONS]

Arguments:
  <PANE_ID>   目标窗格 ID。
  [LABEL]...  名称；实际调用需提供名称或 --clear。

Options:
  --clear     清除自定义 pane 标签；不要与名称同时传入。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

与 agent rename、terminal title set 管理的是不同层级。

源码：[S01] [S04]


## `herdr pane input`

```text
设置窗格输入路由。

Usage: herdr pane input [PANE_ID] [OPTIONS] --right-click <TARGET>

Arguments:
  [PANE_ID]  目标窗格；或用 --pane / --current 明确选择。

Options:
  --pane <ID>             显式指定作为操作起点的 pane ID。
  --current               使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  --right-click <TARGET>  必需。herdr 交给 Herdr 菜单；pane 交给窗格内程序的鼠标输入路径。
  -h, --help              打印该命令的帮助。
```

### 行为与限制

实际解析器要求存在目标选择方式；--current 依赖 HERDR_PANE_ID。

pane 右键路由还受窗格内程序是否启用鼠标协议影响。

源码：[S01] [S04]


## `herdr pane split`

```text
分割窗格并创建新终端。

Usage: herdr pane split [PANE_ID] [OPTIONS]

Arguments:
  [PANE_ID]  起点窗格；可用 --pane 或 --current 替代。

Options:
  --pane <ID>              显式指定作为操作起点的 pane ID。
  --current                使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  --direction <DIRECTION>  分割方向：right 在右侧创建，down 在下侧创建。
  --ratio <FLOAT>          分割比例，由运行时布局校验；不是列数。
  --cwd <PATH>             新进程的工作目录；传入目标机器可访问的路径。
  --env <KEY=VALUE>        设置启动进程的环境变量；可重复。相同键后值覆盖前值，键不得为空。
  --right-click <TARGET>   新窗格右键路由：herdr 或 pane；默认 herdr。
  --focus                  创建后切换焦点到新对象。
  --no-focus               创建后不改变当前焦点；不要与 --focus 同时传入。
  -h, --help               打印该命令的帮助。
```

### 行为与限制

实际调用必须传 --direction right 或 --direction down；统一帮助定义没有标记成 required。

默认不改变焦点。自动化建议显式 --pane ID --direction right --no-focus。

源码：[S01] [S04]


## `herdr pane swap`

```text
交换两个窗格的位置。

Usage: herdr pane swap [OPTIONS]

Options:
  --direction <DIRECTION>  方向：left、right、up、down。
  --pane <ID>              显式指定作为操作起点的 pane ID。
  --current                使用调用进程环境中的 HERDR_PANE_ID；不是“鼠标正指着的窗格”。
  --source-pane <ID>       显式交换的源窗格 ID。
  --target-pane <ID>       显式交换的目标窗格 ID。
  -h, --help               打印该命令的帮助。
```

### 行为与限制

形式一：--direction left/right/up/down，加起点 --pane/--current。

形式二：--source-pane ID --target-pane ID。两种形式不要混用。

源码：[S01] [S04]


## `herdr pane move`

```text
把窗格移到其他标签页或工作区。

Usage: herdr pane move <PANE_ID> [OPTIONS]

Arguments:
  <PANE_ID>  被移动的窗格。

Options:
  --tab <TAB_ID>       移入现有标签页。
  --split <DIRECTION>  现有标签页中的分割方向：right 或 down。
  --target-pane <ID>   现有标签页里作为分割锚点的窗格。
  --ratio <FLOAT>      移入现有布局时的分割比例。
  --new-tab            创建新标签页承载被移动窗格。
  --workspace <ID>     新标签页的目标工作区。
  --new-workspace      创建新工作区承载被移动窗格。
  --label <TEXT>       新标签页或新工作区的名称。
  --tab-label <TEXT>   新工作区内初始标签页名称。
  --focus              创建后切换焦点到新对象。
  --no-focus           创建后不改变当前焦点；不要与 --focus 同时传入。
  -h, --help           打印该命令的帮助。
```

### 行为与限制

现有 tab：--tab TAB_ID --split right|down [--target-pane ID] [--ratio FLOAT]。

新 tab：--new-tab [--workspace ID] [--label TEXT]。

新 workspace：--new-workspace [--label TEXT] [--tab-label TEXT]。三种目的地形式互斥。

源码：[S01] [S04]


## `herdr pane close`

```text
关闭窗格及其终端。

Usage: herdr pane close <pane_id>

Arguments:
  <pane_id>  目标窗格 ID。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会影响正在运行的前台任务；不要误关闭承载当前自动化控制程序的窗格。

源码：[S01] [S04]


## `herdr pane send-text`

```text
向窗格发送字面文本，不附加 Enter。

Usage: herdr pane send-text <PANE_ID> <TEXT>

Arguments:
  <PANE_ID>  目标窗格。
  <TEXT>     要输入的原始文本；推荐整体引用。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

仅发送输入，不意味着命令已执行。要一次提交文本与 Enter 可用 pane run。

成功时通常没有标准输出。

源码：[S01] [S04]


## `herdr pane send-keys`

```text
向窗格发送按键序列。

Usage: herdr pane send-keys <PANE_ID> <KEY>...

Arguments:
  <PANE_ID>  目标窗格。
  <KEY>...   一个或多个键名，如 enter、esc、ctrl+c。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

解析器先校验键名，再发送输入；esc 为规范名称，escape 是兼容写法。成功时通常无正文。

源码：[S01] [S04]


## `herdr pane wait-output`

```text
等待窗格快照中出现匹配输出。

Usage: herdr pane wait-output <PANE_ID> [OPTIONS]

Arguments:
  <PANE_ID>  目标窗格。

Options:
  --match <TEXT>     按字面子串匹配，与 --regex 二选一，必须提供一种。
  --regex <PATTERN>  按 Rust 正则表达式匹配，与 --match 互斥；按行匹配而不是跨行全文匹配。
  --source <SOURCE>  visible、recent、recent-unwrapped；默认 recent。
  --lines <N>        限制搜索快照的渲染行数；recent 默认近期 80 行。
  --timeout <MS>     超时毫秒数；等待命令省略时可无限等待。
  --raw              匹配时保留 ANSI 转义序列；可能影响锚点及子串判断。
  -h, --help         打印该命令的帮助。
```

### 行为与限制

先立即搜索已存在的输出，再轮询。旧日志满足条件也会立即返回，不是“只看本次命令之后的新日志”。

recent / recent-unwrapped 在匹配时会合并软换行；行数截取在合并前执行。

没有 --timeout 则无限等待。帮助允许值不包括 detection，不建议依赖共享解析器的额外放行行为。

源码：[S01] [S04]


## `herdr pane run`

```text
一次提交命令文本与 Enter。

Usage: herdr pane run <PANE_ID> <COMMAND>...

Arguments:
  <PANE_ID>     目标窗格。
  <COMMAND>...  交给窗格内 shell 的命令文本；多个词会按空格连接，建议完整引用。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

API 成功只表示输入已提交，不是子进程成功退出，也不返回进程退出码。成功通常无标准输出。

只在明确处于 shell 提示符时使用；若窗格正运行 Agent/TUI，这些字节会发给那个程序。

源码：[S01] [S04]


## `herdr pane report-agent`

```text
由 hook/集成上报 Agent 生命周期状态。

Usage: herdr pane report-agent <PANE_ID> --source <ID> --agent <LABEL> --state <STATUS> [OPTIONS] [-- [RESUME_ARG]...]

Arguments:
  <PANE_ID>             状态归属的窗格。
  [-- [RESUME_ARG]...]  恢复此 agent 会话的 argv；必须以普通命令名开头，不是任意 shell 脚本字符串。

Options:
  --source <ID>                必需，生命周期报告来源。
  --agent <LABEL>              必需，Agent 规范标签。
  --state <STATUS>             必需，仅 idle、working、blocked、unknown。这里不接受 done。
  --message <TEXT>             补充状态说明。
  --seq <N>                    来源提供的顺序编号，用于报告更新顺序；这是计数值，不是时间戳。
  --agent-session-id <ID>      Agent 自己的会话标识，区别于 Herdr session。
  --agent-session-path <PATH>  Agent 会话存储路径。
  -h, --help                   打印该命令的帮助。
```

### 行为与限制

高级集成接口，会影响生命周期权威来源；普通使用者不应把它当成给任意任务手工造完成状态的命令。

与 wait 可匹配的状态集合不同。成功通常不打印正文。

源码：[S01] [S04]


## `herdr pane report-agent-session`

```text
上报 Agent 会话标识及可选恢复参数。

Usage: herdr pane report-agent-session <PANE_ID> --source <ID> --agent <LABEL> [OPTIONS] [-- [RESUME_ARG]...]

Arguments:
  <PANE_ID>             会话身份归属的窗格。
  [-- [RESUME_ARG]...]  恢复此 agent 会话的 argv；必须以普通命令名开头，不是任意 shell 脚本字符串。

Options:
  --source <ID>                    必需，报告来源。
  --agent <LABEL>                  必需，Agent 规范标签。
  --seq <N>                        来源提供的顺序编号，用于报告更新顺序；这是计数值，不是时间戳。
  --agent-session-id <ID>          Agent 自己的会话标识，区别于 Herdr session。
  --agent-session-path <PATH>      Agent 会话存储路径。
  --session-start-source <SOURCE>  描述 Agent 会话启动来源的标记；不是 pane read 的快照来源枚举。
  -h, --help                       打印该命令的帮助。
```

### 行为与限制

只报告会话身份/恢复信息，不宣称拥有 Agent 生命周期状态权威。成功通常无正文。

源码：[S01] [S04]


## `herdr pane release-agent`

```text
释放某个来源的 Agent 生命周期权威。

Usage: herdr pane release-agent <PANE_ID> --source <ID> --agent <LABEL> [OPTIONS]

Arguments:
  <PANE_ID>  目标窗格。

Options:
  --source <ID>    必需，要释放的报告来源。
  --agent <LABEL>  必需，Agent 规范标签。
  --seq <N>        来源提供的顺序编号，用于报告更新顺序；这是计数值，不是时间戳。
  -h, --help       打印该命令的帮助。
```

### 行为与限制

release 是释放状态报告权威，不是 kill、停止 Agent、关闭 pane 或删除会话。成功通常无正文。

源码：[S01] [S04]


## `herdr pane report-metadata`

```text
上报仅用于展示的窗格元数据。

Usage: herdr pane report-metadata <PANE_ID> --source <ID> [OPTIONS]

Arguments:
  <PANE_ID>  目标窗格。

Options:
  --source <ID>                必需，非空报告来源。
  --agent <LABEL>              将展示元数据关联到某 Agent 标签。
  --applies-to-source <ID>     限定这份展示覆盖适用于哪个状态来源。
  --title <TEXT>               展示标题。
  --clear-title                清除展示标题；与 --title 互斥。
  --display-agent <TEXT>       Agent 的展示文本，不改变真实种类。
  --clear-display-agent        清除展示 Agent 文本；与 --display-agent 互斥。
  --state-label <STATUS=TEXT>  覆盖某个状态的展示文字；运行时可重复设置多个状态。
  --clear-state-labels         清除状态展示文字覆盖。
  --token <NAME=VALUE>         设置自定义展示 token；可重复。
  --clear-token <NAME>         清除指定 token；可重复。
  --seq <N>                    来源提供的顺序编号，用于报告更新顺序；这是计数值，不是时间戳。
  --ttl-ms <N>                 展示元数据的有效期，单位毫秒；省略时采用服务端默认策略。
  -h, --help                   打印该命令的帮助。
```

### 行为与限制

实际解析器要求至少设置或清除一个展示字段；这类更新不改变 idle/working/blocked 的语义状态。

--state-label 在运行时支持重复，但 spec 没有为它配置 Append。成功通常无正文。

源码：[S01] [S04]


## `herdr terminal`

```text
附着或观察底层终端流。

Usage: herdr terminal <COMMAND>

Commands:
  attach                     直接附着到底层终端。
  session                    通过 NDJSON 控制或观察终端会话。
  title                      设置外层终端窗口标题。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

terminal 是 pane 承载的终端实例；不是外层终端模拟器窗口。

源码：[S01] [S03]


## `herdr terminal attach`

```text
直接附着到底层终端。

Usage: herdr terminal attach <TERMINAL_ID> [OPTIONS]

Arguments:
  <TERMINAL_ID>  底层终端 ID；不要把 workspace/tab ID 填到这里。

Options:
  --takeover  显式接管现有写入控制权。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

交互式命令；退出附着为 Ctrl+B 然后 q。退出附着不等于终止终端进程。

源码：[S01] [S03]


## `herdr terminal session`

```text
通过 NDJSON 控制或观察终端会话。

Usage: herdr terminal session <COMMAND>

Commands:
  control                    通过 NDJSON 持有终端写入控制流。
  observe                    只读观察终端 NDJSON 流。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

面向程序的持续流协议，不是一次返回一个 JSON 的查询；请按行解码事件。

源码：[S01] [S03]


## `herdr terminal session control`

```text
通过 NDJSON 持有终端写入控制流。

Usage: herdr terminal session control <TARGET> [OPTIONS]

Arguments:
  <TARGET>  受支持的 pane / terminal / agent 目标。

Options:
  --takeover  接管已有控制流。
  --cols <N>  终端列数，1..65535；默认 120。
  --rows <N>  终端行数，1..65535；默认 40。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

标准输出持续发送终端帧/关闭事件；标准输入读取协议规定的 input/resize/mouse 等消息。

一个终端仅一个写入控制者。不要把任意文本直接写入 stdin 当成键盘字节；先查 api schema。

源码：[S01] [S03]


## `herdr terminal session observe`

```text
只读观察终端 NDJSON 流。

Usage: herdr terminal session observe <TARGET> [OPTIONS]

Arguments:
  <TARGET>  受支持的 pane / terminal / agent 目标。

Options:
  --cols <N>  终端列数，1..65535；默认 120。
  --rows <N>  终端行数，1..65535；默认 40。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

输出 terminal.frame 等事件，帧内 ANSI 数据按协议编码；不要当作可直接 cat 的终端画面。

只读观察，不发送按键，也不抢占输入控制权。

源码：[S01] [S03]


## `herdr terminal title`

```text
设置外层终端窗口标题。

Usage: herdr terminal title <COMMAND>

Commands:
  set                        设置外层终端窗口标题。
  clear                      清除手工设置的外层标题。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S03]


## `herdr terminal title set`

```text
设置外层终端窗口标题。

Usage: herdr terminal title set <TITLE>

Arguments:
  <TITLE>  标题文本。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

与 pane rename、tab rename 和 Agent 名称不是同一个字段。

源码：[S01] [S03]


## `herdr terminal title clear`

```text
清除手工设置的外层标题。

Usage: herdr terminal title clear

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

恢复由 ui.window_title 配置生成的标题。

源码：[S01] [S03]


## `herdr session`

```text
管理命名持久会话。

Usage: herdr session <COMMAND>

Commands:
  list                       列出会话。
  attach                     启动客户端附着到会话。
  stop                       停止命名会话。
  delete                     删除已经停止的会话。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会话控制 server 与保存的工作区结构。默认会话名称为 default。

源码：[S01] [S03]


## `herdr session list`

```text
列出会话。

Usage: herdr session list [OPTIONS]

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S03]


## `herdr session attach`

```text
启动客户端附着到会话。

Usage: herdr session attach <NAME>

Arguments:
  <NAME>  会话名称。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

这是启动/进入 TUI 的操作，不是 JSON 状态查询。

源码：[S01] [S03]


## `herdr session stop`

```text
停止命名会话。

Usage: herdr session stop <NAME> [OPTIONS]

Arguments:
  <NAME>  会话名称。

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会影响该会话托管的进程。只想离开 TUI 时应 detach，不要 stop。

源码：[S01] [S03]


## `herdr session delete`

```text
删除已经停止的会话。

Usage: herdr session delete <NAME> [OPTIONS]

Arguments:
  <NAME>  已停止会话的名称；默认会话显式填写 default。

Options:
  --json      输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会删除保存的会话状态；正在运行的会话不能直接作为 stopped 会话删除。

源码：[S01] [S03]


## `herdr integration`

```text
安装和检查内置 Agent 集成。

Usage: herdr integration <COMMAND>

Commands:
  install                    安装或更新一个 Agent 的 Herdr 集成。
  uninstall                  卸载一个 Agent 的 Herdr 集成。
  status                     检查集成安装状态。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

安装的是 Herdr 的 hook/集成配置，不是安装 Agent 主程序。目标名不总与 agent start --kind 相同。

源码：[S01] [S17] [S19] [S20]


## `herdr integration install`

```text
安装或更新一个 Agent 的 Herdr 集成。

Usage: herdr integration install <TARGET>

Arguments:
  <TARGET>  17 个常规目标及实验性 letta，见集成目标表。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会修改对应 Agent 的配置或 hook 文件。该版本没有 integration install all，也没有此命令的 --json。

源码：[S01] [S17] [S19] [S20]


## `herdr integration uninstall`

```text
卸载一个 Agent 的 Herdr 集成。

Usage: herdr integration uninstall <TARGET>

Arguments:
  <TARGET>  17 个常规目标及实验性 letta，见集成目标表。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

会修改对应 Agent 的配置或 hook 文件。该版本没有 integration install all，也没有此命令的 --json。

源码：[S01] [S17] [S19] [S20]


## `herdr integration status`

```text
检查集成安装状态。

Usage: herdr integration status [OPTIONS]

Options:
  --outdated-only  只列出被判为过期、需要更新的集成。
  -h, --help       打印该命令的帮助。
```

### 行为与限制

检查后可对具体目标重新运行 integration install；检测支持的 Agent 数量不等于可安装集成目标数量。

源码：[S01] [S17] [S19] [S20]


## `herdr plugin`

```text
安装、关联及运行工作流插件。

Usage: herdr plugin <COMMAND>

Commands:
  install                    从 GitHub 安装插件。
  uninstall                  卸载插件。
  link                       关联本地插件目录。
  unlink                     取消本地插件目录关联。
  enable                     启用插件。
  disable                    禁用插件。
  list                       列出插件及状态。
  config-dir                 输出插件用户配置目录。
  action                     列出或调用插件动作。
  log                        查看插件命令日志。
  pane                       管理插件拥有的窗格。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

插件可执行本机代码、访问本地资源。安装/启用前应确认来源、版本、配置与权限。

源码：[S01] [S09]


## `herdr plugin install`

```text
从 GitHub 安装插件。

Usage: herdr plugin install <OWNER/REPO[/SUBDIR]> [OPTIONS]

Arguments:
  <OWNER/REPO[/SUBDIR]>  GitHub 仓库简写，可带插件子目录；不是任意 HTTPS/Git URL。

Options:
  --ref <REF>  指定 Git 引用，如固定 tag 或提交。
  -y, --yes    跳过交互确认；只对已审核的来源使用。
  -h, --help   打印该命令的帮助。
```

### 行为与限制

属于磁盘/代码安装操作；--machine 不允许把本地安装器当作远程命令运行。

源码：[S01] [S09]


## `herdr plugin uninstall`

```text
卸载插件。

Usage: herdr plugin uninstall <PLUGIN>

Arguments:
  <PLUGIN>  已安装插件 ID 或安装来源简写。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

与 unlink 本地开发目录不同；先检查 plugin list 确认对象。

源码：[S01] [S09]


## `herdr plugin link`

```text
关联本地插件目录。

Usage: herdr plugin link <PATH> [OPTIONS]

Arguments:
  <PATH>  插件目录；远程 --machine 场景必须为远程绝对路径。

Options:
  --disabled  关联但保持禁用，适合先检查新插件。
  --enabled   关联并启用；默认启用。
  -h, --help  打印该命令的帮助。
```

### 行为与限制

不要同时传 --enabled 与 --disabled。不是上传本地目录到远程机器。

源码：[S01] [S09]


## `herdr plugin unlink`

```text
取消本地插件目录关联。

Usage: herdr plugin unlink <PLUGIN_ID>

Arguments:
  <PLUGIN_ID>  关联的插件 ID。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

管理关联关系，不等于删除原始开发仓库。

源码：[S01] [S09]


## `herdr plugin enable`

```text
启用插件。

Usage: herdr plugin enable <PLUGIN_ID>

Arguments:
  <PLUGIN_ID>  插件 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin disable`

```text
禁用插件。

Usage: herdr plugin disable <PLUGIN_ID>

Arguments:
  <PLUGIN_ID>  插件 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin list`

```text
列出插件及状态。

Usage: herdr plugin list [OPTIONS]

Options:
  --plugin <ID>  仅查看指定插件。
  --json         输出 JSON，而不是默认的人类可读格式。具体结构以本命令为准，不假定都有 result 外层。
  -h, --help     打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin config-dir`

```text
输出插件用户配置目录。

Usage: herdr plugin config-dir <PLUGIN_ID>

Arguments:
  <PLUGIN_ID>  插件 ID。

Options:
  -h, --help  打印该命令的帮助。
```

### 行为与限制

并非严格只读：实现会确保相关用户目录已创建。输出目录路径文本。

源码：[S01] [S09]


## `herdr plugin action`

```text
列出或调用插件动作。

Usage: herdr plugin action <COMMAND>

Commands:
  list                       列出可用插件动作。
  invoke                     调用一个插件动作。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin action list`

```text
列出可用插件动作。

Usage: herdr plugin action list [OPTIONS]

Options:
  --plugin <ID>  仅列出指定插件动作。
  -h, --help     打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin action invoke`

```text
调用一个插件动作。

Usage: herdr plugin action invoke <ACTION_ID> [OPTIONS]

Arguments:
  <ACTION_ID>  动作标识；可用 <plugin-id>.<local-action> 形式。

Options:
  --plugin <ID>  显式指定插件，避免本地动作名歧义。
  -h, --help     打印该命令的帮助。
```

### 行为与限制

本地动作名不能自行随意添加点号层级。调用动作可能运行外部命令，以插件定义为准。

源码：[S01] [S09]


## `herdr plugin log`

```text
查看插件命令日志。

Usage: herdr plugin log <COMMAND>

Aliases: logs

Commands:
  list                       列出插件命令日志。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin log list`

```text
列出插件命令日志。

Usage: herdr plugin log list [OPTIONS]

Options:
  --plugin <ID>  限定插件。
  --limit <N>    最多返回的日志条数；未传时由实现采用默认上限。
  -h, --help     打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin pane`

```text
管理插件拥有的窗格。

Usage: herdr plugin pane <COMMAND>

Commands:
  open                       打开插件入口对应的窗格。
  focus                      聚焦插件窗格。
  close                      关闭插件窗格。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin pane open`

```text
打开插件入口对应的窗格。

Usage: herdr plugin pane open [OPTIONS]

Options:
  --plugin <ID>            插件 ID；实际解析器要求提供。
  --entrypoint <ID>        插件入口 ID；实际解析器要求提供。
  --placement <PLACEMENT>  spec 列出 overlay、split、tab、zoomed；运行时额外支持 popup，见补注。
  --workspace <ID>         目标工作区。
  --target-pane <PANE>     目标/锚点窗格。
  --direction <DIRECTION>  分割方向：right 在右侧创建，down 在下侧创建。
  --cwd <PATH>             新进程的工作目录；传入目标机器可访问的路径。
  --env <KEY=VALUE>        设置启动进程的环境变量；可重复。相同键后值覆盖前值，键不得为空。
  --focus                  创建后切换焦点到新对象。
  --no-focus               创建后不改变当前焦点；不要与 --focus 同时传入。
  -h, --help               打印该命令的帮助。
```

### 运行时补充（未完整列入统一帮助）

- `--placement popup`：实际解析器支持弹出式窗格；此外 fullscreen 是 zoomed 的兼容别名。
- `--width <SIZE>`：弹出式窗格宽度，可用终端单元格数或百分比，例如 100、80%。
- `--height <SIZE>`：弹出式窗格高度，可用终端单元格数或百分比，例如 30、70%。

### 行为与限制

默认 focus=true，与 workspace create / tab create / pane split 默认不抢焦点不同。

尺寸选项未列入统一 spec。布局相关组合限制仍由运行时验证；popup 示例见工作流。

源码：[S01] [S09]


## `herdr plugin pane focus`

```text
聚焦插件窗格。

Usage: herdr plugin pane focus <PANE_ID>

Arguments:
  <PANE_ID>  plugin pane open/list 信息中的窗格 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


## `herdr plugin pane close`

```text
关闭插件窗格。

Usage: herdr plugin pane close <PANE_ID>

Arguments:
  <PANE_ID>  plugin pane open/list 信息中的窗格 ID。

Options:
  -h, --help  打印该命令的帮助。
```

源码：[S01] [S09]


---

# 24 个典型工作流

> 本页是按源码语义编写的使用模板，**未在调研环境执行**。Shell 示例以 Bash/Zsh 为主；JSON 提取示例依赖 `jq`，Python 调用使用 `uv run`。
>
> 路径、Agent 名、插件 ID 都要替换为真实值。会写磁盘、发送输入、停止会话或删除 checkout 的步骤已注明；不要整页无差别执行。工作流 05 建立的 `$workspace_id`、`$tab_id`、`$pane_id` 只在继续使用同一 shell 时有效。

## 01. 首次启动、离开与返回

```bash
herdr --version
herdr
```

进入 TUI 后创建/使用窗格。需要暂时离开时，按 **Ctrl+B，然后 q**；之后再次执行 `herdr` 返回。不要为了离开界面运行 `server stop`，否则会影响托管进程。

在另一个 shell 查看状态：

```bash
herdr status
herdr workspace list
herdr agent list
```

本手册绑定 0.9.3；版本不同先核对本机帮助。

源码依据：[S02] [S03] [S16]

## 02. 为任务使用独立命名会话

```bash
herdr --session review
```

在另一个终端查询同一个会话：

```bash
herdr --session review workspace list
herdr session list --json
herdr session attach review
```

默认会话 `default` 与 `review` 分开。下面是有破坏性的清理，不是退出界面的步骤：

```bash
# 仅在确认该会话任务不再需要运行时执行：
herdr session stop review --json
# 仅在还确认不需要保留布局/会话状态时执行：
herdr session delete review --json
```

源码依据：[S01] [S02] [S03]

## 03. 检查配置并恢复错误快捷键

先导出当前二进制内置默认值作参考，不直接覆盖现有配置：

```bash
herdr --default-config > herdr-default.toml
herdr config check
```

手动修复配置后重载：

```bash
herdr server reload-config
```

只有确实要放弃自定义键位时使用：

```bash
# 会修改配置并自动留下键位重置备份。
herdr config reset-keys
herdr server reload-config
```

不要在尚未理解现有定制时把 `herdr-default.toml` 整份复制覆盖到个人配置。

源码依据：[S01] [S02] [S03] [S13]

## 04. 在 Mac 的 zsh 中安装命令补全

```bash
mkdir -p ~/.zfunc
herdr completion zsh > ~/.zfunc/_herdr
```

在 `~/.zshrc` 中将下面目录设置放在 `compinit` 之前；已有初始化时合并，不重复添加：

```zsh
fpath=(~/.zfunc $fpath)
autoload -Uz compinit
compinit
```

重新打开 shell。补全来自统一 spec，所以 `--group`、插件 popup 尺寸等运行时补充项可能没有提示；没有补全不等于不可用。

其他 shell 可用 `bash`、`fish`、`powershell`、`elvish` 参数生成对应脚本，加载方式按相应 shell 配置。

源码依据：[S01] [S12]

## 05. 创建工作区并保存真实 ID

以下脚本使用 Bash/Zsh 与 `jq`。把路径改成真实项目目录；这会创建工作区，不只是查询。

```bash
PROJECT="/absolute/path/to/project"
created=$(herdr workspace create \
  --cwd "$PROJECT" --label "review" --no-focus) || exit 1

workspace_id=$(printf '%s' "$created" |
  jq -er '.result.workspace.workspace_id') || exit 1
tab_id=$(printf '%s' "$created" |
  jq -er '.result.tab.tab_id') || exit 1
pane_id=$(printf '%s' "$created" |
  jq -er '.result.root_pane.pane_id') || exit 1

printf 'workspace=%s\ntab=%s\npane=%s\n' \
  "$workspace_id" "$tab_id" "$pane_id"
herdr workspace get "$workspace_id"
```

后续示例的 `$workspace_id` / `$pane_id` 均应替换为你的真实 ID，或沿用本步骤变量。不要照抄别人机器上的 `w1:p1`。

源码依据：[S06] [S15]

## 06. 把编辑、测试与日志拆成 tab / pane

```bash
herdr tab create --workspace "$workspace_id" \
  --cwd "$PROJECT" --label "tests" --no-focus

herdr pane split --pane "$pane_id" \
  --direction right --cwd "$PROJECT" --no-focus

herdr tab list --workspace "$workspace_id"
herdr pane list --workspace "$workspace_id"
```

保存新返回对象中的真实 ID。不要假定 split 后新 pane 的 ID 是旧 ID 加一。`right` 是向右新增窗格，`down` 是向下；`pane split` 实际要求方向，即使某些帮助展示没有将其标成必需。

要从某个起点向右导航，才使用：

```bash
herdr pane focus --pane "$pane_id" --direction right
```

源码依据：[S04] [S08]

## 07. 分别读当前屏幕、近期日志和检测视图

```bash
herdr pane read "$pane_id" --source visible
herdr pane read "$pane_id" --source recent-unwrapped --lines 120
herdr pane read "$pane_id" --source detection
```

看确认框用 visible；看长日志用 recent-unwrapped；检查状态识别依据用 detection。需要保留颜色/控制序列的导出可显式选择 ANSI：

```bash
herdr pane read "$pane_id" --source recent --ansi > pane-ansi.txt
```

这些命令直接输出文本，不应统一接 `.result` 的 jq 过滤器。ANSI 文件包含控制序列，展示、转发前注意终端安全。

源码依据：[S03] [S04]

## 08. 区分输入文本、按键与提交 shell 命令

先确认该 pane 当前停在 shell 提示符：

```bash
herdr pane process-info --pane "$pane_id"
herdr pane read "$pane_id" --source visible
```

分两次输入：

```bash
herdr pane send-text "$pane_id" "pwd"
herdr pane send-keys "$pane_id" enter
```

或者一次提交：

```bash
herdr pane run "$pane_id" "pwd"
```

二者都是向真实终端发送输入。若当前是 Agent 或编辑器界面，输入会进入那个程序。`pane run` 返回 0 不代表 `pwd` 或后续命令的退出码为 0。

源码依据：[S04] [S15]

## 09. 为 shell 任务设置本次运行的完成标记

只用于你能控制命令内容、且 pane 已停在 shell 的场景。下面以 Rust 项目的 `cargo check` 为例；Python 命令使用 `uv run`。

```bash
marker="HERDR_DONE_$(uv run --no-project python -c \
  'import uuid; print(uuid.uuid4().hex)')"

herdr pane run "$pane_id" \
  "cargo check; rc=\$?; printf '\n%s:%s\n' '$marker' \"\$rc\"" \
  || exit 1

herdr pane wait-output "$pane_id" \
  --regex "^${marker}:[0-9]+$" \
  --source recent-unwrapped --lines 200 --timeout 120000

herdr pane read "$pane_id" --source recent-unwrapped --lines 200
```

正则锚定整行，避免命令回显包含 marker 时提前命中。不同运行使用不同 marker，避免旧日志误匹配。最后一行的 `:0` 才表示所包装命令成功；其他数字是失败退出码。等待超时只是尚未观察到标记，不应立即重复提交原任务。

这个模式不是 Herdr 原生进程 exit-code API，也不能消除历史被截断、终端关闭等情况。

源码依据：[S04]

## 10. 在现有 shell 窗格内启动一个 Codex Agent

前提：目标环境中已安装并配置好 `codex`；本工作流不替你安装或登录它。

```bash
herdr pane process-info --pane "$pane_id"
herdr pane read "$pane_id" --source visible

herdr agent start reviewer --kind codex \
  --pane "$pane_id" --timeout 60000

herdr agent get reviewer
herdr agent read reviewer --source visible
```

`agent start` 成功表示已在同一终端检测到预期 Agent，且能够交互。不是只把命令名写进了终端。若需要传 Agent 自己的参数，应放到 `--` 后，并按你安装的 Agent 版本确认其支持的参数。

源码依据：[S01] [S05] [S18]

## 11. 提交提示词，并正确解释等待结果

```bash
if ! herdr agent prompt reviewer \
  "只检查当前代码并给出问题清单，不修改文件。" \
  --wait --timeout 120000; then
  printf '%s\n' "提交/等待未成功；先检查状态，不自动重试。"
fi

herdr agent get reviewer
herdr agent read reviewer --source recent-unwrapped --lines 160
```

即使命令成功，也要判断返回的是 idle、done 还是 blocked。`blocked` 可能在等你授权，并不是审查完成。

显式限制等待目标时：

```bash
herdr agent wait reviewer \
  --until idle --until done --timeout 120000
```

这仍然是状态等待；不是“自动跳过 blocked”。目标持续 blocked 时可能等到超时，必须读屏处理。

源码依据：[S01] [S05]

## 12. Agent blocked 时先看屏幕，不盲目补发 prompt

```bash
herdr agent get reviewer
herdr agent read reviewer --source visible
```

先确认它究竟在问什么。人工决定需要的回复或键盘操作，再发对应输入。例如确认要退出当前界面的场景才发送 Escape：

```bash
# 仅当你已读屏并确认 Escape 是所需操作：
herdr agent send-keys reviewer esc
```

不要在未知确认框里自动发送 enter、y 或授权选项。已经 blocked 的 Agent 会在 prompt 提交前报 `agent_blocked`；`release-agent` 也不是解决确认框的命令，它释放的是 hook 状态报告权威。

源码依据：[S04] [S05]

## 13. 两个 Agent 并行，但不要让焦点决定目标

分别创建两个工作区，保存每个返回的 root pane ID。最简单是重复工作流 05，将 label 改为 `review-a`、`review-b`，分别保存为 `pane_a`、`pane_b`。

```bash
herdr agent start reviewer-a --kind codex --pane "$pane_a"
herdr agent start reviewer-b --kind codex --pane "$pane_b"

herdr agent prompt reviewer-a "只审查错误处理，不修改文件。"
herdr agent prompt reviewer-b "只审查并发与资源释放，不修改文件。"

herdr agent wait reviewer-a --timeout 120000
herdr agent wait reviewer-b --timeout 120000

herdr agent read reviewer-a --source recent-unwrapped --lines 160
herdr agent read reviewer-b --source recent-unwrapped --lines 160
```

这里两个 prompt 先后快速提交，工作可以并行，随后逐个等待。不要用随用户焦点变化的“当前 pane”指挥多个 Agent。若两者要修改代码，应先隔离 checkout / jj workspace 或明确协调策略；两个 Herdr 工作区指向同一目录并不提供文件隔离。

源码依据：[S05] [S06]

## 14. 排查 Agent 识别错误

在线解释：

```bash
herdr agent explain reviewer --verbose
herdr agent explain reviewer --json > detection-explain.json
herdr pane read "$pane_id" --source detection > detection-screen.txt
```

离线复现（样本应清除密钥、私人路径或敏感输出）：

```bash
herdr agent explain --file detection-screen.txt \
  --agent codex --verbose
```

查看规则版本，再按需更新：

```bash
herdr server agent-manifests --json
# 下面会获取并重载检测规则。
herdr server update-agent-manifests --json
```

更新检测 manifest 不会升级 codex 可执行程序，也不保证所有问题来自识别规则。

源码依据：[S05] [S13]

## 15. 检查与更新 Agent hook 集成

```bash
herdr integration status
herdr integration status --outdated-only
```

确认使用的 Agent 和改动范围后，针对具体目标安装/更新：

```bash
# 将修改 Codex 的相关集成配置。
herdr integration install codex
herdr integration status
```

要移除时使用对应目标的 `integration uninstall`。没有通用的 `install all`。

Antigravity 的 KIND / TARGET 不同：启动种类使用 `agy`，集成安装使用 `antigravity-cli`。`letta` 在该版本仍标为实验性。

源码依据：[S17] [S18] [S19] [S20]

## 16. 分别命名对象，并上报纯展示信息

```bash
herdr workspace rename "$workspace_id" "API review"
herdr pane rename "$pane_id" "review console"
herdr agent rename reviewer "api-reviewer"
herdr terminal title set "Review session"
```

这四个名称属于不同层级。纯展示状态可以通过元数据报告：

```bash
herdr workspace report-metadata "$workspace_id" \
  --source my-review-script --token phase=review --ttl-ms 60000

herdr pane report-metadata "$pane_id" \
  --source my-review-script --title "正在审查" \
  --token stage=analysis --ttl-ms 60000
```

token 只有被相应 UI 配置引用才会显示。引用字面 `$stage` 时注意 shell 引号。清理时：

```bash
herdr pane report-metadata "$pane_id" \
  --source my-review-script --clear-title --clear-token stage
herdr terminal title clear
```

不要使用 `report-agent --state done` 伪造完成：该状态值根本不在这条命令的允许集合中。

源码依据：[S04] [S05] [S06] [S01]

## 17. 只读观察，或明确接管交互控制

只读流：

```bash
herdr terminal session observe "$pane_id" > terminal-events.ndjson
```

这是持续运行的 NDJSON 流，可由调用端中断观察；不要把文件当作普通屏幕文本。流中帧数据需按 schema 解码。若只要当前输出，`pane read` 更简单。

直接交互附着：

```bash
herdr agent attach reviewer
```

需要接管时才加 `--takeover`，这可能影响现有写入控制者。退出附着按 Ctrl+B 然后 q，而不是在 Agent 里发送终止进程的按键。`terminal session control` 面向协议集成，应先阅读 `api schema`，不要往它的 stdin 直接粘贴 shell 命令。

源码依据：[S01] [S03] [S05]

## 18. 远程 TUI 与命名会话

把 `build-host` 替换为你的 SSH 配置别名：

```bash
herdr --remote build-host
```

选择远程按键策略：

```bash
herdr --remote build-host --remote-keybindings local
# 或明确使用 server 配置：
herdr --remote build-host --remote-keybindings server
```

这是远程 TUI 启动，不写成 `herdr --remote build-host pane list`。远程安装/升级提示中涉及重启或重置时，应确认远程正在运行的任务是否可以受影响。不要为了消除版本警告直接批准破坏性重置。

源码依据：[S02] [S10]

## 19. 保存 SSH machine，再显式路由 API

```bash
herdr machine add build-host --label builder --remote-session review
herdr machine list --json
herdr machine status builder --json
```

连接准备可能安装或升级远程 Herdr，以交互提示为准。然后所有远程 API 调用显式带相同前缀：

```bash
herdr --machine builder status server --json
herdr --machine builder workspace list
herdr --machine builder agent list
```

创建远程工作区：

```bash
herdr --machine builder workspace create \
  --cwd "/remote/absolute/project" --label "remote-review" --no-focus
```

返回的 ID 属于远程目标，不要去掉 `--machine builder` 后继续操作。也不要再加本地 `--session`。连接失败后先检查状态；写请求可能已经执行，不应盲目自动重放。

源码依据：[S10] [S11]

## 20. Git worktree：创建、重新打开与安全清理

这是 **Git 仓库** 的 workflow，不是 jj 的 workspace 管理。先列出现状：

```bash
herdr worktree list --cwd "$PROJECT"
```

需要隔离的 Git 分支 checkout 时：

```bash
herdr worktree create --cwd "$PROJECT" \
  --branch feature/herdr-review --label "isolated-review" --no-focus
```

现有 worktree 可按真实路径重新打开：

```bash
herdr worktree open --cwd "$PROJECT" \
  --path "/absolute/path/to/existing-worktree" --no-focus
```

只是关闭 Herdr 工作区用 `workspace close`。确实要删除 checkout、且已检查并保存所有改动时，才对对应 Herdr workspace ID 执行：

```bash
# 此命令删除 checkout；先确认 ID 及未提交内容。
herdr worktree remove --workspace "$worktree_workspace_id"
```

不要把 `--force` 当成默认参数。`--trust-repository` 也只对已审核的仓库显式使用。

源码依据：[S07]

## 21. 继续用 jj 管版本，让 Herdr 只管理终端

Herdr 的 `worktree` 子命令不会变成 `jj workspace`。对于已经准备好的 jj 工作目录，直接创建普通 Herdr workspace：

```bash
JJ_DIR="/absolute/path/to/existing-jj-workspace"
herdr workspace create --cwd "$JJ_DIR" --label "jj-review" --no-focus
```

进入该目录的终端后，版本控制仍由你熟悉的 jj 工作流完成。Herdr 负责终端布局、Agent 启停交互和可观察性，不接管 revision 管理。

多个 Herdr workspace 指向同一个 jj 工作目录也不等于独立 working copy。需要并行写代码时，先按你安装的 jj 版本建立并检查独立 workspace，再将各目录传给 Herdr；不要用 Git worktree 命令代替 jj 的隔离设计。

源码依据：[S06] [S07]

## 22. 先禁用关联本地插件，再审查和调用动作

把下面路径与 ID 替换成自己已审核的插件：

```bash
herdr plugin link "/absolute/path/to/my-plugin" --disabled
herdr plugin list --json
herdr plugin config-dir my-plugin
```

先读插件 manifest、入口脚本及配置。`config-dir` 会确保相关用户目录存在，不能视为完全无副作用的路径查询。

确认后：

```bash
herdr plugin enable my-plugin
herdr plugin action list --plugin my-plugin
```

只调用真实列出的动作；例如你确有 `refresh`：

```bash
herdr plugin action invoke refresh --plugin my-plugin
herdr plugin log list --plugin my-plugin --limit 50
```

`my-plugin` / `refresh` 是模板占位，不声称这是上游内置插件。不要安装未知来源时默认加 `--yes`。

源码依据：[S09]

## 23. 打开带百分比尺寸的插件 popup

前提：已有启用的插件及真实 entrypoint。将 `my-plugin`、`dashboard` 换成插件中实际存在的 ID。

```bash
herdr plugin pane open \
  --plugin my-plugin \
  --entrypoint dashboard \
  --placement popup \
  --width 80% --height 70% \
  --workspace "$workspace_id" \
  --no-focus
```

这些 popup/尺寸参数来自 v0.9.3 实际解析器，不是从该版本 spec 的枚举里推出来的。可能不会出现在补全中。

`plugin pane open` 默认会聚焦，因此示例显式写 `--no-focus`。拿到真实 plugin pane ID 后才执行：

```bash
herdr plugin pane focus "$plugin_pane_id"
# 不再使用这个插件窗格时：
herdr plugin pane close "$plugin_pane_id"
```

不要把目标 workspace 的 ID 当成插件 pane ID。

源码依据：[S01] [S09]

## 24. 导出 schema / snapshot，并为自动化建立检查边界

schema 是当前二进制内置文档：

```bash
herdr api schema
herdr api schema --output herdr-api.schema.json
```

不要把 `--output` 与 `--json` 一起使用。实时状态则来自 server：

```bash
if herdr api snapshot > snapshot.json 2> snapshot-error.txt; then
  jq . snapshot.json
else
  cat snapshot-error.txt >&2
fi
```

接入程序应明确：请求目标机器与 session、对象 ID、超时、退出码、返回类型、是否可以重试。`pane run` / `agent prompt` 属于有副作用的输入提交；连接失败或等待超时后，先查询状态再决定重试。

长期维护这份中文手册时，先运行包内 `audit-help.py` 在已安装的 0.9.3 上导出本机原始帮助。升级到新版本后应重新对照源码；不要静默沿用所有历史别名、默认值和隐藏参数。

源码依据：[S10] [S14] [S15]

---

# 源码、帮助定义与运行时差异

> 本表针对 **v0.9.3**。它记录调研中确认的差异，不代表上游已承认的 bug 列表，也不保证未来版本不变。

## 1. 帮助文档的两个来源

根帮助来自 `src/main.rs` 的手工输出；子命令 `--help` 主要来自 `src/cli/spec.rs` 的 clap 命令树。业务执行又经过各子模块的手写解析器。因而，“帮助显示什么”“补全提供什么”“运行时接受什么”可能不同。

本套文档保留 `Usage / Commands / Arguments / Options` 帮助式结构，以及命令名、选项和枚举的英文原值；中文含义由源码解释补齐。**没有在此环境运行 v0.9.3 二进制，故不是逐字节导出的翻译版，不承诺与某个终端的换行、缩进完全一致。**

## 2. 已确认差异

| 项目 | 帮助/spec | 运行时或实际约束 | 写脚本的建议 |
|---|---|---|---|
| 根命令目录 | 手写根帮助没有列全 `terminal`、`plugin` | 统一 spec 和分发器支持 | 使用完整命令索引 |
| `workspace close --group` | spec 未列 | workspace 解析器接受 | 放在 workspace ID 后，确认关闭范围 |
| `plugin pane open --placement popup` | spec 枚举未列 popup | 插件解析器支持 | 版本固定后使用，见工作流 |
| `plugin pane open --width/--height` | spec 未列 | 解析器接受尺寸/百分比 | 与适用的 popup 布局配合 |
| `--placement fullscreen` | 不是 spec 规范值 | 运行时作 `zoomed` 兼容别名 | 新脚本用 zoomed |
| `plugin pane open --plugin/--entrypoint` | 未标记 required | 运行时要求提供 | 两项总是显式传入 |
| `pane split --direction` | 未标记 required | 运行时要求提供 | 显式 right 或 down |
| `worktree ... --json` | spec 未列 | 四个子命令接受，无效果 | 默认已经 JSON，无需添加 |
| `pane report-metadata --state-label` | spec 使用单值设置 | 运行时可重复 | 每个状态独立一次选项 |
| `api schema --json --output` | spec 没声明互斥 | 解析器拒绝同时使用 | 二选一 |
| `pane input` 的目标 | spec 选择项看似全可选 | 运行时需要有效目标选择 | 用 ID 或 --current |
| `worktree remove --workspace` | spec 未标记 required | 运行时要求 workspace | 总是传 ID |
| `worktree open` 选择条件 | 单项看似可选 | 实际需 path 或 branch | 明确二选一 |
| `recent_unwrapped` | 帮助只列带连字符的值 | 读取解析器保留下划线别名 | 新脚本用 recent-unwrapped |
| `--flag=value` | clap 风格容易使人以为均支持 | 并非所有手写解析器统一展开 | 优先 `--flag VALUE` |
| `herdr help ...` | 自动 help 子命令被关闭 | 某些组有手写 `help` 处理，但不是通用入口 | 用完整路径紧接 `--help` |
| 子命令帮助定位 | 按命令路径寻找帮助节点 | 中间夹入业务位置参数/`--` 可能走别的解析路径 | 使用 `herdr pane read --help` |
| `done` | wait 状态枚举包括 | report-agent 的 state 枚举不包括 | 不要跨命令复用状态枚举 |

来源：[S01][S03][S04][S06][S07][S09][S14]。这些补充项独立标注在命令章节中，未伪装成原帮助已有内容。

## 3. 非公开命令树中的入口

### `herdr server live-handoff`

```text
Usage: herdr server live-handoff [OPTIONS]

Options:
  --import-exe <PATH>           交接导入方可执行文件
  --expected-protocol <N>       期望协议版本
  --expected-version <VERSION>  期望程序版本
```

该入口在 server 手写运行分发/帮助中可见，但不在统一公开 spec 树中。用于实验性 live handoff 和特定恢复路径，可能绕过普通命令前置的版本/协议检查。这里单独列出，不计入 125 个公开节点，也不放进默认帮助采集脚本。**不是常规升级必跑命令。** [S13]

### 内部启动与桥接入口

`client`、`remote-client-bridge`、`remote-api-bridge` 是主分发里的内部启动/传输入口。`server --handoff-import` 是交接导入路径。这些不是普通操作手册应承诺稳定性的 API；不建议从名称推断参数，更不要把它们加入批量“试运行”脚本。

本手册记录其存在，但不臆造未展开检查的内部协议、文件描述符、环境约定及完整参数表。[S02][S03][S13]

## 4. 不要混用旧文档的拼写

v0.9.3 的公开命令树中没有顶层 `wait output`、`agent send` 或根级 `--no-session`。与当前功能对应的规范命令是：

```text
herdr pane wait-output ...
herdr agent prompt ...
herdr pane send-text ...
herdr pane send-keys ...
```

看到其他版本、分叉仓库或旧教程出现不同拼写时，先用 `herdr --version` 与精确子命令 `--help` 核对；不要把所有网上出现过的命令合并成一份“超集手册”。[S01][S03]

## 5. 验证边界

已完成：固定 release/tag、检查公开命令树、逐项解释该树的参数、核对关键运行时解析器、阅读源码测试/帮助中的行为约束、记录差异、核对清单与生成物结构。

未完成：在本环境下载并执行 v0.9.3 二进制；实际启动 TUI/server；验证本地/SSH/Windows/macOS 的运行行为；真实执行插件安装、Agent 登录及任务；对不同终端尺寸截图比对原始帮助。

环境的 GitHub 下载访问未成功，因此未把“源码推导”冒充“跑过的结果”。包中的 `audit-help.py` 可在你已安装该版本的机器上采集原始英文帮助；它只执行版本查询与精确命令路径的 `--help`。


---

# 版本、来源与调研方法

## 基准版本

- 官方仓库：<https://github.com/herdrdev/herdr>
- 固定 release：<https://github.com/herdrdev/herdr/releases/tag/v0.9.3>
- 发布日期：2026-09-29；短提交：`7b116c0`。
- 调研日期：2026-10-01。
- 官方在线 CLI 参考：<https://herdr.dev/docs/cli-reference/>。网站用于交叉检查；行为以本手册锁定版本源码为准。
- 上游许可证：<https://github.com/herdrdev/herdr/blob/v0.9.3/LICENSE>（Apache-2.0）。

## 主要源码索引

| 编号 | 核对内容 | 固定版本源码 |
|---|---|---|
| S01 | 统一命令树、参数与帮助生成 | [src/cli/spec.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec.rs#L6-L966) |
| S02 | 根命令、启动选项、默认配置及快捷键 | [src/main.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/main.rs) |
| S03 | 主分发、读取参数、ID 与键名处理 | [src/cli.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli.rs) |
| S04 | Pane 命令及实际参数解析 | [src/cli/pane.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/pane.rs) |
| S05 | Agent 命令、等待与启动语义 | [src/cli/agent.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/agent.rs) |
| S06 | Workspace 命令及 --group | [src/cli/workspace.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/workspace.rs) |
| S07 | Git worktree 命令 | [src/cli/worktree.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/worktree.rs) |
| S08 | Tab 命令 | [src/cli/tab.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/tab.rs) |
| S09 | 插件命令、popup 与尺寸参数 | [src/cli/plugin.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/plugin.rs) |
| S10 | --machine 路由与白名单 | [src/cli/target.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/target.rs#L174-L301) |
| S11 | Machine 命令帮助定义 | [src/cli/spec/machine.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/machine.rs) |
| S12 | 补全命令帮助定义 | [src/cli/spec/completion.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/completion.rs) |
| S13 | Server 命令及 live-handoff | [src/cli/server.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/server.rs) |
| S14 | API 输出与 schema | [src/cli/api.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/api.rs) |
| S15 | API 请求输出适配 | [src/cli/runtime.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/runtime.rs) |
| S16 | 状态命令 | [src/cli/status.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/status.rs) |
| S17 | 集成安装命令 | [src/cli/integration.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/integration.rs) |
| S18 | Agent 类型、名称与别名 | [src/detect/mod.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/detect/mod.rs) |
| S19 | 集成注册与规范名称 | [src/integration/registry.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/registry.rs) |
| S20 | 实验性集成目标 | [src/integration/mod.rs](https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/mod.rs) |

## 方法

先固定 release 与 tag，再从 `spec::command()` 递归梳理公开节点；查看 `main.rs` 的根帮助与实际分发；对 pane、agent、workspace、worktree、plugin、machine 路由、schema 输出等关键路径检查手写解析器；再整理说明、互斥/必需条件、枚举、默认行为、已有测试断言和工作流。

125 是手册所覆盖公开命令树的节点数，而不是通过执行二进制递归导出的实测数量。该计数包含根与分组，并排除别名重复计数和内部入口。自动化生成检查验证了：命令路径唯一、父子节点存在、18 个顶层入口、103 个叶子、24 个工作流，以及参数条目均有中文说明。

由于环境中的发布包/原始文件下载未成功，本包没有声称已经构建源码、运行 server、测试 SSH、安装插件或完成 Agent 操作。公开帮助树覆盖是全量的；应用内部实现与所有协议方法的核对不是全量代码审计。

## 翻译约定

命令与参数保持原值；占位符保留帮助式英文形式。中文说明包含对无 `.help()` 参数的解释性补充。未在 spec 列出的运行时接受项另列，未确认的默认值不填猜测数。这里的“支持”仅指该版本相应解析/分发路径，不保证外部 Agent、插件、SSH 环境可用。


[S01]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec.rs#L6-L966
[S02]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/main.rs
[S03]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli.rs
[S04]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/pane.rs
[S05]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/agent.rs
[S06]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/workspace.rs
[S07]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/worktree.rs
[S08]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/tab.rs
[S09]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/plugin.rs
[S10]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/target.rs#L174-L301
[S11]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/machine.rs
[S12]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/completion.rs
[S13]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/server.rs
[S14]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/api.rs
[S15]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/runtime.rs
[S16]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/status.rs
[S17]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/integration.rs
[S18]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/detect/mod.rs
[S19]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/registry.rs
[S20]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/mod.rs
