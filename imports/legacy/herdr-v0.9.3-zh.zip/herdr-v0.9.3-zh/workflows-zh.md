# 24 个典型工作流

> 本页是按源码语义编写的使用模板，**未在调研环境执行**。Shell 示例以 Bash/Zsh 为主；JSON 提取示例依赖 `jq`，Python 调用使用 `uv run`。
>
> 路径、Agent 名、插件 ID 都要替换为真实值。会写磁盘、发送输入、停止会话或删除 checkout 的步骤已注明；不要整页无差别执行。工作流 05 建立的 `$workspace_id`、`$tab_id`、`$pane_id` 只在继续使用同一 shell 时有效。

## 01. 首次启动、离开与返回

```bash
herdr --version
herdr
```

进入 TUI 后创建/使用窗格。需要暂时离开时，按 **Ctrl+B，然后 q**；之后再次执行 `herdr` 返回。不要为了离开界面运行 `server stop`，否则会影响托管进程。

在另一个 shell 查看状态：

```bash
herdr status
herdr workspace list
herdr agent list
```

本手册绑定 0.9.3；版本不同先核对本机帮助。

源码依据：[S02] [S03] [S16]

## 02. 为任务使用独立命名会话

```bash
herdr --session review
```

在另一个终端查询同一个会话：

```bash
herdr --session review workspace list
herdr session list --json
herdr session attach review
```

默认会话 `default` 与 `review` 分开。下面是有破坏性的清理，不是退出界面的步骤：

```bash
# 仅在确认该会话任务不再需要运行时执行：
herdr session stop review --json
# 仅在还确认不需要保留布局/会话状态时执行：
herdr session delete review --json
```

源码依据：[S01] [S02] [S03]

## 03. 检查配置并恢复错误快捷键

先导出当前二进制内置默认值作参考，不直接覆盖现有配置：

```bash
herdr --default-config > herdr-default.toml
herdr config check
```

手动修复配置后重载：

```bash
herdr server reload-config
```

只有确实要放弃自定义键位时使用：

```bash
# 会修改配置并自动留下键位重置备份。
herdr config reset-keys
herdr server reload-config
```

不要在尚未理解现有定制时把 `herdr-default.toml` 整份复制覆盖到个人配置。

源码依据：[S01] [S02] [S03] [S13]

## 04. 在 Mac 的 zsh 中安装命令补全

```bash
mkdir -p ~/.zfunc
herdr completion zsh > ~/.zfunc/_herdr
```

在 `~/.zshrc` 中将下面目录设置放在 `compinit` 之前；已有初始化时合并，不重复添加：

```zsh
fpath=(~/.zfunc $fpath)
autoload -Uz compinit
compinit
```

重新打开 shell。补全来自统一 spec，所以 `--group`、插件 popup 尺寸等运行时补充项可能没有提示；没有补全不等于不可用。

其他 shell 可用 `bash`、`fish`、`powershell`、`elvish` 参数生成对应脚本，加载方式按相应 shell 配置。

源码依据：[S01] [S12]

## 05. 创建工作区并保存真实 ID

以下脚本使用 Bash/Zsh 与 `jq`。把路径改成真实项目目录；这会创建工作区，不只是查询。

```bash
PROJECT="/absolute/path/to/project"
created=$(herdr workspace create \
  --cwd "$PROJECT" --label "review" --no-focus) || exit 1

workspace_id=$(printf '%s' "$created" |
  jq -er '.result.workspace.workspace_id') || exit 1
tab_id=$(printf '%s' "$created" |
  jq -er '.result.tab.tab_id') || exit 1
pane_id=$(printf '%s' "$created" |
  jq -er '.result.root_pane.pane_id') || exit 1

printf 'workspace=%s\ntab=%s\npane=%s\n' \
  "$workspace_id" "$tab_id" "$pane_id"
herdr workspace get "$workspace_id"
```

后续示例的 `$workspace_id` / `$pane_id` 均应替换为你的真实 ID，或沿用本步骤变量。不要照抄别人机器上的 `w1:p1`。

源码依据：[S06] [S15]

## 06. 把编辑、测试与日志拆成 tab / pane

```bash
herdr tab create --workspace "$workspace_id" \
  --cwd "$PROJECT" --label "tests" --no-focus

herdr pane split --pane "$pane_id" \
  --direction right --cwd "$PROJECT" --no-focus

herdr tab list --workspace "$workspace_id"
herdr pane list --workspace "$workspace_id"
```

保存新返回对象中的真实 ID。不要假定 split 后新 pane 的 ID 是旧 ID 加一。`right` 是向右新增窗格，`down` 是向下；`pane split` 实际要求方向，即使某些帮助展示没有将其标成必需。

要从某个起点向右导航，才使用：

```bash
herdr pane focus --pane "$pane_id" --direction right
```

源码依据：[S04] [S08]

## 07. 分别读当前屏幕、近期日志和检测视图

```bash
herdr pane read "$pane_id" --source visible
herdr pane read "$pane_id" --source recent-unwrapped --lines 120
herdr pane read "$pane_id" --source detection
```

看确认框用 visible；看长日志用 recent-unwrapped；检查状态识别依据用 detection。需要保留颜色/控制序列的导出可显式选择 ANSI：

```bash
herdr pane read "$pane_id" --source recent --ansi > pane-ansi.txt
```

这些命令直接输出文本，不应统一接 `.result` 的 jq 过滤器。ANSI 文件包含控制序列，展示、转发前注意终端安全。

源码依据：[S03] [S04]

## 08. 区分输入文本、按键与提交 shell 命令

先确认该 pane 当前停在 shell 提示符：

```bash
herdr pane process-info --pane "$pane_id"
herdr pane read "$pane_id" --source visible
```

分两次输入：

```bash
herdr pane send-text "$pane_id" "pwd"
herdr pane send-keys "$pane_id" enter
```

或者一次提交：

```bash
herdr pane run "$pane_id" "pwd"
```

二者都是向真实终端发送输入。若当前是 Agent 或编辑器界面，输入会进入那个程序。`pane run` 返回 0 不代表 `pwd` 或后续命令的退出码为 0。

源码依据：[S04] [S15]

## 09. 为 shell 任务设置本次运行的完成标记

只用于你能控制命令内容、且 pane 已停在 shell 的场景。下面以 Rust 项目的 `cargo check` 为例；Python 命令使用 `uv run`。

```bash
marker="HERDR_DONE_$(uv run --no-project python -c \
  'import uuid; print(uuid.uuid4().hex)')"

herdr pane run "$pane_id" \
  "cargo check; rc=\$?; printf '\n%s:%s\n' '$marker' \"\$rc\"" \
  || exit 1

herdr pane wait-output "$pane_id" \
  --regex "^${marker}:[0-9]+$" \
  --source recent-unwrapped --lines 200 --timeout 120000

herdr pane read "$pane_id" --source recent-unwrapped --lines 200
```

正则锚定整行，避免命令回显包含 marker 时提前命中。不同运行使用不同 marker，避免旧日志误匹配。最后一行的 `:0` 才表示所包装命令成功；其他数字是失败退出码。等待超时只是尚未观察到标记，不应立即重复提交原任务。

这个模式不是 Herdr 原生进程 exit-code API，也不能消除历史被截断、终端关闭等情况。

源码依据：[S04]

## 10. 在现有 shell 窗格内启动一个 Codex Agent

前提：目标环境中已安装并配置好 `codex`；本工作流不替你安装或登录它。

```bash
herdr pane process-info --pane "$pane_id"
herdr pane read "$pane_id" --source visible

herdr agent start reviewer --kind codex \
  --pane "$pane_id" --timeout 60000

herdr agent get reviewer
herdr agent read reviewer --source visible
```

`agent start` 成功表示已在同一终端检测到预期 Agent，且能够交互。不是只把命令名写进了终端。若需要传 Agent 自己的参数，应放到 `--` 后，并按你安装的 Agent 版本确认其支持的参数。

源码依据：[S01] [S05] [S18]

## 11. 提交提示词，并正确解释等待结果

```bash
if ! herdr agent prompt reviewer \
  "只检查当前代码并给出问题清单，不修改文件。" \
  --wait --timeout 120000; then
  printf '%s\n' "提交/等待未成功；先检查状态，不自动重试。"
fi

herdr agent get reviewer
herdr agent read reviewer --source recent-unwrapped --lines 160
```

即使命令成功，也要判断返回的是 idle、done 还是 blocked。`blocked` 可能在等你授权，并不是审查完成。

显式限制等待目标时：

```bash
herdr agent wait reviewer \
  --until idle --until done --timeout 120000
```

这仍然是状态等待；不是“自动跳过 blocked”。目标持续 blocked 时可能等到超时，必须读屏处理。

源码依据：[S01] [S05]

## 12. Agent blocked 时先看屏幕，不盲目补发 prompt

```bash
herdr agent get reviewer
herdr agent read reviewer --source visible
```

先确认它究竟在问什么。人工决定需要的回复或键盘操作，再发对应输入。例如确认要退出当前界面的场景才发送 Escape：

```bash
# 仅当你已读屏并确认 Escape 是所需操作：
herdr agent send-keys reviewer esc
```

不要在未知确认框里自动发送 enter、y 或授权选项。已经 blocked 的 Agent 会在 prompt 提交前报 `agent_blocked`；`release-agent` 也不是解决确认框的命令，它释放的是 hook 状态报告权威。

源码依据：[S04] [S05]

## 13. 两个 Agent 并行，但不要让焦点决定目标

分别创建两个工作区，保存每个返回的 root pane ID。最简单是重复工作流 05，将 label 改为 `review-a`、`review-b`，分别保存为 `pane_a`、`pane_b`。

```bash
herdr agent start reviewer-a --kind codex --pane "$pane_a"
herdr agent start reviewer-b --kind codex --pane "$pane_b"

herdr agent prompt reviewer-a "只审查错误处理，不修改文件。"
herdr agent prompt reviewer-b "只审查并发与资源释放，不修改文件。"

herdr agent wait reviewer-a --timeout 120000
herdr agent wait reviewer-b --timeout 120000

herdr agent read reviewer-a --source recent-unwrapped --lines 160
herdr agent read reviewer-b --source recent-unwrapped --lines 160
```

这里两个 prompt 先后快速提交，工作可以并行，随后逐个等待。不要用随用户焦点变化的“当前 pane”指挥多个 Agent。若两者要修改代码，应先隔离 checkout / jj workspace 或明确协调策略；两个 Herdr 工作区指向同一目录并不提供文件隔离。

源码依据：[S05] [S06]

## 14. 排查 Agent 识别错误

在线解释：

```bash
herdr agent explain reviewer --verbose
herdr agent explain reviewer --json > detection-explain.json
herdr pane read "$pane_id" --source detection > detection-screen.txt
```

离线复现（样本应清除密钥、私人路径或敏感输出）：

```bash
herdr agent explain --file detection-screen.txt \
  --agent codex --verbose
```

查看规则版本，再按需更新：

```bash
herdr server agent-manifests --json
# 下面会获取并重载检测规则。
herdr server update-agent-manifests --json
```

更新检测 manifest 不会升级 codex 可执行程序，也不保证所有问题来自识别规则。

源码依据：[S05] [S13]

## 15. 检查与更新 Agent hook 集成

```bash
herdr integration status
herdr integration status --outdated-only
```

确认使用的 Agent 和改动范围后，针对具体目标安装/更新：

```bash
# 将修改 Codex 的相关集成配置。
herdr integration install codex
herdr integration status
```

要移除时使用对应目标的 `integration uninstall`。没有通用的 `install all`。

Antigravity 的 KIND / TARGET 不同：启动种类使用 `agy`，集成安装使用 `antigravity-cli`。`letta` 在该版本仍标为实验性。

源码依据：[S17] [S18] [S19] [S20]

## 16. 分别命名对象，并上报纯展示信息

```bash
herdr workspace rename "$workspace_id" "API review"
herdr pane rename "$pane_id" "review console"
herdr agent rename reviewer "api-reviewer"
herdr terminal title set "Review session"
```

这四个名称属于不同层级。纯展示状态可以通过元数据报告：

```bash
herdr workspace report-metadata "$workspace_id" \
  --source my-review-script --token phase=review --ttl-ms 60000

herdr pane report-metadata "$pane_id" \
  --source my-review-script --title "正在审查" \
  --token stage=analysis --ttl-ms 60000
```

token 只有被相应 UI 配置引用才会显示。引用字面 `$stage` 时注意 shell 引号。清理时：

```bash
herdr pane report-metadata "$pane_id" \
  --source my-review-script --clear-title --clear-token stage
herdr terminal title clear
```

不要使用 `report-agent --state done` 伪造完成：该状态值根本不在这条命令的允许集合中。

源码依据：[S04] [S05] [S06] [S01]

## 17. 只读观察，或明确接管交互控制

只读流：

```bash
herdr terminal session observe "$pane_id" > terminal-events.ndjson
```

这是持续运行的 NDJSON 流，可由调用端中断观察；不要把文件当作普通屏幕文本。流中帧数据需按 schema 解码。若只要当前输出，`pane read` 更简单。

直接交互附着：

```bash
herdr agent attach reviewer
```

需要接管时才加 `--takeover`，这可能影响现有写入控制者。退出附着按 Ctrl+B 然后 q，而不是在 Agent 里发送终止进程的按键。`terminal session control` 面向协议集成，应先阅读 `api schema`，不要往它的 stdin 直接粘贴 shell 命令。

源码依据：[S01] [S03] [S05]

## 18. 远程 TUI 与命名会话

把 `build-host` 替换为你的 SSH 配置别名：

```bash
herdr --remote build-host
```

选择远程按键策略：

```bash
herdr --remote build-host --remote-keybindings local
# 或明确使用 server 配置：
herdr --remote build-host --remote-keybindings server
```

这是远程 TUI 启动，不写成 `herdr --remote build-host pane list`。远程安装/升级提示中涉及重启或重置时，应确认远程正在运行的任务是否可以受影响。不要为了消除版本警告直接批准破坏性重置。

源码依据：[S02] [S10]

## 19. 保存 SSH machine，再显式路由 API

```bash
herdr machine add build-host --label builder --remote-session review
herdr machine list --json
herdr machine status builder --json
```

连接准备可能安装或升级远程 Herdr，以交互提示为准。然后所有远程 API 调用显式带相同前缀：

```bash
herdr --machine builder status server --json
herdr --machine builder workspace list
herdr --machine builder agent list
```

创建远程工作区：

```bash
herdr --machine builder workspace create \
  --cwd "/remote/absolute/project" --label "remote-review" --no-focus
```

返回的 ID 属于远程目标，不要去掉 `--machine builder` 后继续操作。也不要再加本地 `--session`。连接失败后先检查状态；写请求可能已经执行，不应盲目自动重放。

源码依据：[S10] [S11]

## 20. Git worktree：创建、重新打开与安全清理

这是 **Git 仓库** 的 workflow，不是 jj 的 workspace 管理。先列出现状：

```bash
herdr worktree list --cwd "$PROJECT"
```

需要隔离的 Git 分支 checkout 时：

```bash
herdr worktree create --cwd "$PROJECT" \
  --branch feature/herdr-review --label "isolated-review" --no-focus
```

现有 worktree 可按真实路径重新打开：

```bash
herdr worktree open --cwd "$PROJECT" \
  --path "/absolute/path/to/existing-worktree" --no-focus
```

只是关闭 Herdr 工作区用 `workspace close`。确实要删除 checkout、且已检查并保存所有改动时，才对对应 Herdr workspace ID 执行：

```bash
# 此命令删除 checkout；先确认 ID 及未提交内容。
herdr worktree remove --workspace "$worktree_workspace_id"
```

不要把 `--force` 当成默认参数。`--trust-repository` 也只对已审核的仓库显式使用。

源码依据：[S07]

## 21. 继续用 jj 管版本，让 Herdr 只管理终端

Herdr 的 `worktree` 子命令不会变成 `jj workspace`。对于已经准备好的 jj 工作目录，直接创建普通 Herdr workspace：

```bash
JJ_DIR="/absolute/path/to/existing-jj-workspace"
herdr workspace create --cwd "$JJ_DIR" --label "jj-review" --no-focus
```

进入该目录的终端后，版本控制仍由你熟悉的 jj 工作流完成。Herdr 负责终端布局、Agent 启停交互和可观察性，不接管 revision 管理。

多个 Herdr workspace 指向同一个 jj 工作目录也不等于独立 working copy。需要并行写代码时，先按你安装的 jj 版本建立并检查独立 workspace，再将各目录传给 Herdr；不要用 Git worktree 命令代替 jj 的隔离设计。

源码依据：[S06] [S07]

## 22. 先禁用关联本地插件，再审查和调用动作

把下面路径与 ID 替换成自己已审核的插件：

```bash
herdr plugin link "/absolute/path/to/my-plugin" --disabled
herdr plugin list --json
herdr plugin config-dir my-plugin
```

先读插件 manifest、入口脚本及配置。`config-dir` 会确保相关用户目录存在，不能视为完全无副作用的路径查询。

确认后：

```bash
herdr plugin enable my-plugin
herdr plugin action list --plugin my-plugin
```

只调用真实列出的动作；例如你确有 `refresh`：

```bash
herdr plugin action invoke refresh --plugin my-plugin
herdr plugin log list --plugin my-plugin --limit 50
```

`my-plugin` / `refresh` 是模板占位，不声称这是上游内置插件。不要安装未知来源时默认加 `--yes`。

源码依据：[S09]

## 23. 打开带百分比尺寸的插件 popup

前提：已有启用的插件及真实 entrypoint。将 `my-plugin`、`dashboard` 换成插件中实际存在的 ID。

```bash
herdr plugin pane open \
  --plugin my-plugin \
  --entrypoint dashboard \
  --placement popup \
  --width 80% --height 70% \
  --workspace "$workspace_id" \
  --no-focus
```

这些 popup/尺寸参数来自 v0.9.3 实际解析器，不是从该版本 spec 的枚举里推出来的。可能不会出现在补全中。

`plugin pane open` 默认会聚焦，因此示例显式写 `--no-focus`。拿到真实 plugin pane ID 后才执行：

```bash
herdr plugin pane focus "$plugin_pane_id"
# 不再使用这个插件窗格时：
herdr plugin pane close "$plugin_pane_id"
```

不要把目标 workspace 的 ID 当成插件 pane ID。

源码依据：[S01] [S09]

## 24. 导出 schema / snapshot，并为自动化建立检查边界

schema 是当前二进制内置文档：

```bash
herdr api schema
herdr api schema --output herdr-api.schema.json
```

不要把 `--output` 与 `--json` 一起使用。实时状态则来自 server：

```bash
if herdr api snapshot > snapshot.json 2> snapshot-error.txt; then
  jq . snapshot.json
else
  cat snapshot-error.txt >&2
fi
```

接入程序应明确：请求目标机器与 session、对象 ID、超时、退出码、返回类型、是否可以重试。`pane run` / `agent prompt` 属于有副作用的输入提交；连接失败或等待超时后，先查询状态再决定重试。

长期维护这份中文手册时，先运行包内 `audit-help.py` 在已安装的 0.9.3 上导出本机原始帮助。升级到新版本后应重新对照源码；不要静默沿用所有历史别名、默认值和隐藏参数。

源码依据：[S10] [S14] [S15]

[S01]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec.rs#L6-L966
[S02]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/main.rs
[S03]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli.rs
[S04]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/pane.rs
[S05]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/agent.rs
[S06]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/workspace.rs
[S07]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/worktree.rs
[S08]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/tab.rs
[S09]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/plugin.rs
[S10]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/target.rs#L174-L301
[S11]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/machine.rs
[S12]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/spec/completion.rs
[S13]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/server.rs
[S14]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/api.rs
[S15]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/runtime.rs
[S16]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/status.rs
[S17]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/cli/integration.rs
[S18]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/detect/mod.rs
[S19]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/registry.rs
[S20]: https://github.com/herdrdev/herdr/blob/v0.9.3/src/integration/mod.rs
