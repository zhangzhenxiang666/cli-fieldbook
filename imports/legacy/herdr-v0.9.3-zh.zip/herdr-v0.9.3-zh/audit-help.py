#!/usr/bin/env python3
"""Capture Herdr v0.9.3 public help without running operational commands.

Run: uv run --no-project python audit-help.py --binary herdr --output capture
Only the Python standard library is required.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", default="herdr", help="Herdr executable or path")
    parser.add_argument("--output", type=Path, default=Path("help-capture-v0.9.3"),
                        help="New output directory; existing directories are not overwritten")
    parser.add_argument("--timeout", type=float, default=20.0, help="Per-call timeout in seconds")
    args = parser.parse_args()
    if args.timeout <= 0:
        parser.error("--timeout must be positive")
    executable = shutil.which(args.binary)
    if executable is None:
        parser.error(f"Executable not found: {args.binary}")
    env = os.environ.copy()
    env.update(NO_COLOR="1", CLICOLOR="0", TERM="dumb", COLUMNS="100")
    try:
        version = subprocess.run([executable, "--version"], capture_output=True,
                                 text=True, encoding="utf-8", errors="replace",
                                 timeout=args.timeout, env=env, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        print(f"Cannot query version: {exc}", file=sys.stderr)
        return 2
    version_text = (version.stdout + "\n" + version.stderr).strip()
    match = re.search(r"(?<!\d)v?(\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?)", version_text)
    if version.returncode != 0 or match is None or match.group(1) != "0.9.3":
        print("Expected exactly Herdr 0.9.3; refusing to run the inventory.\n"
              + version_text, file=sys.stderr)
        return 2
    inventory_path = Path(__file__).resolve().with_name("commands.json")
    try:
        inventory = json.loads(inventory_path.read_text(encoding="utf-8"))
        paths = [row["path"] for row in inventory["commands"]]
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f"Cannot read command inventory: {exc}", file=sys.stderr)
        return 2
    if len(paths) != 125 or len(set(paths)) != len(paths) or "" not in paths:
        print("Unexpected inventory shape; refusing to proceed.", file=sys.stderr)
        return 2
    for path in paths:
        if path and not all(re.fullmatch(r"[a-z][a-z-]*", token) for token in path.split(" ")):
            print(f"Unsafe command path in inventory: {path!r}", file=sys.stderr)
            return 2
    try:
        args.output.mkdir(parents=True, exist_ok=False)
    except OSError as exc:
        print(f"Use a new output directory: {exc}", file=sys.stderr)
        return 2
    records = []
    combined = []
    for path in paths:
        argv = [executable, *path.split(), "--help"]
        stem = path.replace(" ", "__") or "herdr"
        try:
            completed = subprocess.run(argv, capture_output=True, text=True,
                                       encoding="utf-8", errors="replace",
                                       timeout=args.timeout, env=env, check=False)
            stdout, stderr, code = completed.stdout, completed.stderr, completed.returncode
        except subprocess.TimeoutExpired:
            stdout, stderr, code = "", f"Timed out after {args.timeout}s", None
        except OSError as exc:
            stdout, stderr, code = "", str(exc), None
        (args.output / (stem + ".txt")).write_text(stdout, encoding="utf-8")
        if stderr:
            (args.output / (stem + ".stderr.txt")).write_text(stderr, encoding="utf-8")
        records.append({
            "path": path, "argv": argv, "returncode": code, "has_stdout": bool(stdout),
            "stderr": stderr, "sha256": hashlib.sha256(stdout.encode("utf-8")).hexdigest()
        })
        combined.append("$ " + " ".join(["herdr", *path.split(), "--help"]) + "\n" + stdout)
    (args.output / "all-help-en.txt").write_text("\n\n".join(combined), encoding="utf-8")
    failures = [r for r in records if r["returncode"] != 0 or not r["has_stdout"]]
    report = {"version": version_text, "platform": sys.platform,
              "count": len(records), "failures": len(failures), "records": records}
    (args.output / "capture-report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Captured {len(records)} help nodes to {args.output}; failures: {len(failures)}")
    return 1 if failures else 0

if __name__ == "__main__":
    raise SystemExit(main())
