# jj v0.45.1 中文命令、Revset 与工作流资料包

以 2026-09-17 查证的稳定版 v0.45.1（2026-09-03 发布）为基准。

## 本次补充：Revset 完整参考

**54 个文档函数 + 1 个弃用兼容名 + 8 个默认别名**，包含符号、范围、优先级、字符串/日期模式、日志图形与引用后缀。另增 20 个查询场景。纠正旧手册对 `all:` 的建议：v0.45.1 已不支持该修饰符。

只看本次内容，打开 **revsets-zh.html**；查看全部命令与补篇，打开 **jj-v0.45.1-zh.html**。两者均为单文件，无需开启本地服务器。

## 建议从哪里开始

直接打开 **jj-v0.45.1-zh.html**。它是单文件离线手册，无需安装依赖或访问网络；
可搜索命令、参数和中文解释，按公开 / 隐藏 / 条件编译 / 工作流过滤。
源码链接仅在点击时访问 GitHub。完整展开后可用浏览器自带打印功能。

偏好编辑器阅读时，打开 **jj-v0.45.1-zh.md** 和 **workflows-zh.md**。
偏好终端全文检索时，使用 **jj-v0.45.1-zh.txt**，其中每个命令重复列出全局选项。

## 交付内容

| 文件 | 内容 |
|---|---|
| jj-v0.45.1-zh.html | 全部命令、24 个原工作流、完整 Revset 补篇与 20 个查询场景 |
| jj-v0.45.1-zh.md | 完整中文命令手册、语法速查、默认值 |
| jj-v0.45.1-zh.txt | help 结构文本；各节点含全局选项 |
| workflows-zh.md | 24 个原工作流 + R01–R20 Revset 查询场景 |
| sources-and-coverage.md | 版本、计数口径、源码差异、来源定位 |
| commands.json | 153 个节点的结构化数据；根节点键为空字符串 |
| shared-options.json | 全局项、差异格式共享项、内置默认配置 |
| workflows.json | 工作流结构化数据 |
| export_help.py | 本机英文帮助导出脚本 |
| validation.json | 原交付检查记录及本次修订的验证说明 |
| revsets-zh.html / .md / .txt | 独立 Revset 中文完整参考，三个格式 |
| revsets-functions.json | 54+1 函数签名、参数、边界、示例和源文件定位 |
| revsets-aliases.json | 8 个默认别名的定义与说明 |
| revsets-sections.json | 语言、符号、模式、日志标记等章节 |
| revsets-recipes.json | 20 个查询场景 |
| revsets-validation.json | 本次覆盖、独立 DAG 模型、HTML 与格式验证结果 |
| SHA256SUMS.txt | 包中文件的 SHA-256 校验值 |

## 覆盖与限制

122 个公开节点包含根入口及命令组，其中 107 个为非根叶子命令。
另有 26 个 debug 节点、5 个需要编译 feature 的 bench 节点；合计 153。
不是 153 个公开独立命令，别名也没有重复计数。

保留 help 章节结构、命令/参数拼写与占位符，中文解释经过重述和重排。
**不是本环境实际运行 jj 得到的逐字 help 转录，也不是全部工作流实测报告。**
公开表基于完整官方 CLI reference，源码重点复核；隐藏兼容项只承诺已核实清单。
默认配置、平台和编译 feature 可能造成差异。先读 sources-and-coverage.md。

## 在本机导出原始帮助

先保证 PATH 中已有 jj。脚本仅依赖 Python 标准库，推荐从解压目录运行：

```sh
jj --version

uv run --no-project export_help.py --out raw-help
uv run --no-project export_help.py --include-hidden --include-bench --out raw-help-all
```

默认严格要求版本 0.45.1。比较其他版本时显式添加 `--allow-version-mismatch`；
脚本仍只抓取这份手册已知的命令路径，不会自动发现未来新增命令。

脚本只调用 `--version` 和各条命令路径的 `--help`，在临时空目录中运行，
默认将 `JJ_CONFIG` 指向空设备以避免用户配置别名替换命令。
英文 stdout/stderr 以原始字节分别保存，并附每条命令的退出码。
没有安装 bench feature 时，相应路径失败会被如实记录。

输出目录必须新建或为空，避免覆盖已有捕获。
`--columns 100` 仅提供帮助换行宽度的环境提示；不能保证所有平台/构建完全一致。
此脚本不访问源码、不执行工作流，也不自动翻译帮助。

## 上游

项目及许可属于 The Jujutsu Authors；原项目为 Apache-2.0。
本资料包是非官方中文整理，不包含官方完整源码副本。

[固定版本 release](https://github.com/jj-vcs/jj/releases/tag/v0.45.1) ·
[命令枚举](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/mod.rs) ·
[官方 CLI reference](https://docs.jj-vcs.dev/latest/cli-reference/)
