#!/usr/bin/env python3
"""Capture jj help without running repository-changing commands.

Run with: uv run --no-project export_help.py --include-hidden --include-bench
Requires Python 3.10+ and a separately installed jj binary.
The capture paths come from the bundled commands.json, not live discovery.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

EXPECTED_VERSION = "0.45.1"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--jj", default="jj", help="jj executable name or absolute path")
    parser.add_argument("--database", type=Path,
                        default=Path(__file__).with_name("commands.json"))
    parser.add_argument("--out", type=Path, default=Path("raw-help-v0.45.1"),
                        help="new or empty output directory (never overwrites existing files)")
    parser.add_argument("--include-hidden", action="store_true",
                        help="also capture the known debug command tree")
    parser.add_argument("--include-bench", action="store_true",
                        help="also try feature-gated bench commands")
    parser.add_argument("--allow-version-mismatch", action="store_true",
                        help="capture the known paths even when the installed jj differs")
    parser.add_argument("--keep-user-config", action="store_true",
                        help="retain JJ_CONFIG; user aliases may then change command meanings")
    parser.add_argument("--columns", type=int, default=100,
                        help="COLUMNS environment hint for help wrapping; default: 100")
    parser.add_argument("--timeout", type=float, default=15.0,
                        help="per-command timeout in seconds; default: 15")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.columns < 40 or args.timeout <= 0:
        raise ValueError("--columns must be >= 40 and --timeout must be positive")
    executable = shutil.which(args.jj)
    if not executable:
        raise FileNotFoundError(f"Cannot find jj executable: {args.jj!r}")
    executable = str(Path(executable).resolve())
    data = json.loads(args.database.read_text(encoding="utf-8"))
    if not isinstance(data, dict) or "" not in data:
        raise ValueError("Invalid commands.json: expected an object with the root key ''")
    selected = []
    for path, record in data.items():
        if not isinstance(path, str) or (path and not re.fullmatch(r"[a-z0-9 -]+", path)):
            raise ValueError(f"Unsafe command path in database: {path!r}")
        status = record.get("status")
        if status == "public" or (status == "hidden" and args.include_hidden) or (
            status == "feature-gated" and args.include_bench
        ):
            selected.append((path, status))
    selected.sort(key=lambda item: item[0].split(" ") if item[0] else [])
    env = os.environ.copy()
    env.update({"NO_COLOR": "1", "TERM": "dumb", "COLUMNS": str(args.columns)})
    if not args.keep_user_config:
        env["JJ_CONFIG"] = os.devnull

    output = args.out.resolve()
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        raise FileExistsError(f"Output must be a new or empty directory: {output}")

    # An empty temporary working directory avoids snapshotting a user's repository.
    # --help and --version are the only jj operations this script invokes.
    with tempfile.TemporaryDirectory(prefix="jj-help-export-") as workdir:
        version = subprocess.run(
            [executable, "--version"], cwd=workdir, env=env,
            capture_output=True, timeout=args.timeout, check=False,
        )
        if version.returncode:
            raise RuntimeError(version.stderr.decode("utf-8", errors="replace"))
        version_text = version.stdout.decode("utf-8", errors="replace").strip()
        found = re.search(r"\b(\d+\.\d+\.\d+)(?:[-+][^\s]*)?", version_text)
        actual_version = found.group(1) if found else None
        if actual_version != EXPECTED_VERSION and not args.allow_version_mismatch:
            raise ValueError(
                f"Expected jj {EXPECTED_VERSION}, got {version_text!r}. "
                "Use --allow-version-mismatch only for an intentional comparison."
            )

        output.mkdir(parents=True, exist_ok=True)
        (output / "version.stdout.txt").write_bytes(version.stdout)
        (output / "version.stderr.txt").write_bytes(version.stderr)
        manifest = {
            "captured_at": dt.datetime.now(dt.timezone.utc).isoformat(),
            "expected_version": EXPECTED_VERSION, "actual_version": version_text,
            "binary": executable, "columns_hint": args.columns,
            "user_config_retained": args.keep_user_config,
            "note": "Known paths only; no live discovery, translation or behavioral tests.",
            "commands": [],
        }
        manifest_path = output / "manifest.json"
        for path, status in selected:
            command = [executable, *path.split(), "--help"]
            stem = "jj" + ("__" + path.replace(" ", "__") if path else "")
            item = {"path": path or "jj", "status": status, "argv": command}
            try:
                proc = subprocess.run(
                    command, cwd=workdir, env=env, capture_output=True,
                    timeout=args.timeout, check=False,
                )
                # Save bytes verbatim: no translation, line-ending normalization or stripping.
                stdout_name, stderr_name = stem + ".stdout.txt", stem + ".stderr.txt"
                (output / stdout_name).write_bytes(proc.stdout)
                (output / stderr_name).write_bytes(proc.stderr)
                item.update(returncode=proc.returncode, stdout=stdout_name, stderr=stderr_name)
            except subprocess.TimeoutExpired as exc:
                item.update(error="timeout", timeout_seconds=args.timeout)
                if exc.stdout:
                    (output / (stem + ".partial.stdout.txt")).write_bytes(exc.stdout)
                if exc.stderr:
                    (output / (stem + ".partial.stderr.txt")).write_bytes(exc.stderr)
            manifest["commands"].append(item)
            # Retain progress even if the user interrupts a later capture.
            manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
                                     encoding="utf-8")
            print(f'{item.get("returncode", "TIMEOUT"):>7}  jj {path} --help')
        failed = sum(item.get("returncode") != 0 for item in manifest["commands"])
        print(f"\nCaptured {len(selected)} paths; {failed} failed/unavailable. Output: {output}")
        # Missing feature-gated commands are expected on some binaries, but never hidden.
        return 1 if failed else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(2) from exc
