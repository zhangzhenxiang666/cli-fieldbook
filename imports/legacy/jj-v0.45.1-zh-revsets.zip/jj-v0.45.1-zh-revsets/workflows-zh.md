# Jujutsu v0.45.1 工作流手册

**24 个独立配方 · 2026-09-17 查证 · 对应主手册 v0.45.1**

每节是一个独立场景，不要把全文代码块顺序连起来执行。示例采用 POSIX shell 风格；
大写的 `CHANGE_A`、`BASE`、`GOOD_REV`、`BAD_REV`、`OP_ID` 是需要替换的占位符，
不是 jj 自带关键字。`trunk()` 必须先在本仓库确认能解析为预期主线。

代码中标为“方案 B”“替代方案”或注释掉的命令不是紧接着执行的下一步。
网络写入示例先展示 dry-run；仍需要你检查目标和权限后再决定执行真正写入。

**验证范围：** 命令语法与关键行为根据官方文档及 v0.45.1 源码核对，
未在本环境安装 jj，也未对这些配方跑实际仓库测试。
真实结果受项目结构、编辑器、合并工具、远端策略和个人配置影响。
这些不是保证任意仓库都安全的一键脚本。

## 场景索引

- [01. 初始化：新克隆与接入已有 Git 仓库](#workflow-01)
- [02. 日常开发：理解 @、describe、new 与 commit](#workflow-02)
- [03. 临时插入紧急修复：不依赖 stash](#workflow-03)
- [04. 堆叠提交：回头修正中间的一层](#workflow-04)
- [05. 一次改太多：把功能与重构拆开](#workflow-05)
- [06. 整理碎片：squash、部分 squash 与 absorb](#workflow-06)
- [07. 跟上主线：fetch 后 rebase 当前分支](#workflow-07)
- [08. 精确选择 rebase 的范围与插入位置](#workflow-08)
- [09. 挑选别人的改动：duplicate 而不是移动原提交](#workflow-09)
- [10. 合并分支并解决冲突](#workflow-10)
- [11. 首次发布功能分支：显式管理书签](#workflow-11)
- [12. 持续更新已发布的功能分支](#workflow-12)
- [13. 清理书签：delete、forget 与 untrack 不等价](#workflow-13)
- [14. 只撤销某个文件的修改：restore](#workflow-14)
- [15. 操作做错了：undo、redo 与操作日志恢复](#workflow-15)
- [16. 已发布历史不宜重写：用 revert 生成反向提交](#workflow-16)
- [17. 追踪一个 change 怎样被改写：evolog 与 interdiff](#workflow-17)
- [18. 多个目录并行开发：workspace](#workflow-18)
- [19. 大仓库与跟踪控制：sparse、track、untrack](#workflow-19)
- [20. 批量验证堆叠中的每个提交：run](#workflow-20)
- [21. 自动整理每一层：run 与 fix 的边界](#workflow-21)
- [22. 定位首次引入问题的提交：bisect run](#workflow-22)
- [23. 发布标签与签名：先确定目标，再放宽任何保护](#workflow-23)
- [24. Gerrit 代码评审：upload 与普通 push 分开](#workflow-24)


<a id="workflow-01"></a>
## 01. 初始化：新克隆与接入已有 Git 仓库

**适用场景：** 二选一。新项目从远端克隆；已有 .git 的项目只增加 jj 元数据。以下身份和仓库地址必须替换成你自己的值。

```sh
# 先配置身份（不是 GPG/SSH 签名配置）
jj config set --user user.name "你的名字"
jj config set --user user.email "you@example.com"

# 方案 A：克隆；显式写出并置布局，避免受个人默认配置影响
jj git clone --colocate https://example.com/team/project.git project
cd project

# 方案 B：不要紧接着执行 A；在已有 Git 仓库根目录运行
# jj git init --colocate

jj status
jj log
jj git remote list
```

**执行结果：** 并置布局中 .jj 与 .git 共存。后续主要使用 jj，仍可被需要 .git 的工具识别。

**风险与边界：** v0.45.1 的内置 git.colocate=true；旧教程的默认值可能不同。现有 Git index、工作区和引用应先检查，不要把初始化当作清理修改的命令。额外 workspace 在这一版不支持 colocation。

源码依据：[jj git clone](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/clone.rs) · [jj git init](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/init.rs) · [jj git colocation](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/colocation.rs) · [jj config set](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/config/set.rs)。


<a id="workflow-02"></a>
## 02. 日常开发：理解 @、describe、new 与 commit

**适用场景：** 当前 @ 已经是一个工作副本提交。修改文件后，用 jj 命令观察和记录快照；不用照搬 git add → git commit。

```sh
jj status
jj diff
jj describe -m "feat: add request validation"
jj new

# 更短的替代流程；不要与上面的 describe + new 重复执行
# jj commit -m "feat: add request validation"

jj log -r 'trunk()..@'
```

**执行结果：** describe 为当前 change 写描述；new 创建并切换到新的空孩子。执行完后，上一项工作的 change 是 @-，新工作 change 是 @。

**风险与边界：** new 并不保证替你把既有书签前进。commit 还支持按路径/交互选择，其语义不只是给当前提交改标题。merge 的 @- 可能是多个父提交。

源码依据：[jj status](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/status.rs) · [jj diff](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/diff.rs) · [jj describe](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/describe.rs) · [jj new](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/new.rs) · [jj commit](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/commit.rs) · [docs/working-copy.md](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/working-copy.md)。


<a id="workflow-03"></a>
## 03. 临时插入紧急修复：不依赖 stash

**适用场景：** 当前有未完成的功能，先给它一个清晰描述和稳定 change ID，再切到主线处理紧急修复。

```sh
jj describe -m "wip: request validation"
WIP=$(jj log -r @ --no-graph -T 'change_id ++ "\n"')

jj new 'trunk()' -m "fix: handle missing configuration"
# 编辑文件并测试紧急修复
jj diff
jj new

# 回到原来的工作 change
jj edit "$WIP"
```

**执行结果：** 两项工作成为不同的 change；回到 WIP 时可以继续原来的文件状态。change ID 通常在重写前后保持，commit ID 则会改变。

**风险与边界：** 忽略、未跟踪或无法快照的文件不因此得到保护；不能把 jj 当作整个目录的备份工具。分歧 change ID 需要进一步消歧。

源码依据：[jj describe](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/describe.rs) · [jj log](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/log.rs) · [jj new](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/new.rs) · [jj edit](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/edit.rs) · [docs/working-copy.md](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/working-copy.md) · [docs/revsets.md](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)。


<a id="workflow-04"></a>
## 04. 堆叠提交：回头修正中间的一层

**适用场景：** 已有 A → B → C 的未发布堆叠，在最顶层继续开发时发现 A 中遗漏了修改。CHANGE_A 换成 A 的实际 change ID。

```sh
TOP=$(jj log -r @ --no-graph -T 'change_id ++ "\n"')

# 在 A 上方新建一个临时修复 change
jj new CHANGE_A
# 编辑只属于 A 的修复
jj diff
jj squash --into CHANGE_A

# 继续回到原堆叠顶端
jj edit "$TOP"
jj log -r 'trunk()..@'
```

**执行结果：** 修复压入 A 后，依赖 A 的后代会相应重写；不必先把整个堆叠交互式 rebase 成 Git 的编辑状态。

```text
原来：base -> A -> B -> C
修改：base -> A' -> B' -> C'
A/B/C 的 change ID 通常保持；commit ID 随对象重写而变化。
```

**风险与边界：** 如果 A 或其需重写的后代受 immutable 保护，命令会拒绝。不要习惯性加 --ignore-immutable；先判断是否已经发布以及是否影响他人。

源码依据：[jj new](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/new.rs) · [jj squash](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/squash.rs) · [jj edit](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/edit.rs) · [jj rebase](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/rebase.rs)。


<a id="workflow-05"></a>
## 05. 一次改太多：把功能与重构拆开

**适用场景：** 当前 @ 同时包含两项逻辑工作。先通过交互界面选出第一项；或者用路径选择整个目录。

```sh
jj diff
jj split -i -m "refactor: extract validation helpers"
jj log -r 'trunk()..@'
jj diff

# 路径选择是替代方案，不要紧接着再次拆分
# jj split src/validation/ -m "refactor: extract validation helpers"
```

**执行结果：** 默认选中的部分保留在原 change，余下部分成为它的新孩子。用 --parallel 可创建兄弟提交；指定 -o/-A/-B 时则采用提取到指定位置的语义。

**风险与边界：** 交互式 diff editor 中通常通过调整右侧来表达所选改动，不是简单选择文件保存。书签行为受 split.legacy-bookmark-behavior 控制，拆分后必须检查 bookmark list。

源码依据：[jj split](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/split.rs) · [jj bookmark list](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/list.rs)。


<a id="workflow-06"></a>
## 06. 整理碎片：squash、部分 squash 与 absorb

**适用场景：** squash 用于明确知道修改该归入哪一项工作；absorb 则根据行的历史归属自动分配给可变祖先。

```sh
# 方案 A：把当前修复放入明确目标，可交互选择片段
jj squash --into CHANGE_A -i

# 方案 B：替代方案，让 jj 根据行归属分配
# jj absorb --from @ --into 'mutable()'

jj op show -p
jj status
```

**执行结果：** squash 的 --into 修改已有目标；absorb 仅考虑来源的祖先，不能明确归属的改动留在来源。用 op show -p 审阅这次操作的整体效果。

**风险与边界：** 不要将 squash --onto 与 --into 视为同义：前者是创建新目标提交的实验性模式。absorb 不是语义级 AI 归类，新增/混合改动可能无法自动归位。

源码依据：[jj squash](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/squash.rs) · [jj absorb](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/absorb.rs) · [jj operation show](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/show.rs)。


<a id="workflow-07"></a>
## 07. 跟上主线：fetch 后 rebase 当前分支

**适用场景：** 准备把当前功能分支及后代放到最新主线之上。trunk() 必须在本仓库解析为你预期的主线。

```sh
jj git fetch --remote origin
jj log -r 'trunk() | trunk()..@'
jj rebase -b @ -o 'trunk()'
jj status
jj resolve --list
```

**执行结果：** -b 按相对于目标的分叉关系选择分支；它不是 -s 和 -r 的简单拼写变化。发生冲突时，冲突可以作为提交内容保存在图中，再单独解决。

**风险与边界：** 先看 log 确认范围。多主线、多 merge 或已有独立 change 的仓库，默认 -b @ 不一定就是你脑中的“一个提交”。远端引用缓存先 fetch 更新。

源码依据：[jj git fetch](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/fetch.rs) · [jj rebase](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/rebase.rs) · [jj resolve](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/resolve.rs)。


<a id="workflow-08"></a>
## 08. 精确选择 rebase 的范围与插入位置

**适用场景：** 下面三行是三种替代选择，不是一个应该连续执行的脚本。A、B、C 和 BASE 都需换成真实修订。

```sh
# A 及其全部后代一起移动
jj rebase -s CHANGE_A -o BASE

# 仅提取 A、C；未选中的后代接回原来的位置
# jj rebase -r 'CHANGE_A | CHANGE_C' -o BASE

# 只移动 B，插入到 A 前面
# jj rebase -r CHANGE_B -B CHANGE_A
```

**执行结果：** -s 用于“这一层开始的整段堆叠”，-r 用于“只移动指定集合”，-b 用于“从相对目标的分叉点搬分支”。-o 设父节点，-A/-B 则插入并重接相关边。

**风险与边界：** -b/-s/-r 互斥。-o 与 -A/-B 互斥；-A 与 -B 可组合以约束插入位置。重排有依赖的补丁可能产生冲突。v0.45.1 中 -d 仍是 --onto 的公开短别名。

源码依据：[jj rebase](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/rebase.rs) · [jj arrange](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/arrange.rs) · [jj parallelize](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/parallelize.rs)。


<a id="workflow-09"></a>
## 09. 挑选别人的改动：duplicate 而不是移动原提交

**适用场景：** 想把一个提交的补丁复制到当前主线上，原提交和原分支保持不动。

```sh
jj duplicate CHANGE_A -o 'trunk()'
jj log

# 从上一条命令输出中取得新 change ID 后，才运行这一行
# jj edit NEW_CHANGE_ID
```

**执行结果：** duplicate 会生成新的 change ID；rebase 则是移动/重写原有 change。指定多个修订可以复制一组改动。

**风险与边界：** duplicate 不等于自动切换到新工作 change。源提交可以来自已发布历史，但复制后的补丁仍可能冲突；检查图和内容。

源码依据：[jj duplicate](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/duplicate.rs) · [jj edit](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/edit.rs)。


<a id="workflow-10"></a>
## 10. 合并分支并解决冲突

**适用场景：** feature-a 和 feature-b 是两个已有书签或可解析的修订。new 的多个父修订表示创建 merge change。

```sh
jj new feature-a feature-b -m "merge: integrate feature branches"
jj status
jj resolve --list

# 已配置 merge tool 时，让工具处理冲突
jj resolve

# 或手动编辑冲突文件，然后检查快照
jj status
jj diff
```

**执行结果：** 不需要进入 Git 那种必须立刻完成的全局 merge/rebase 中间状态。冲突可以存在于某个具体提交中，后续再编辑。

**风险与边界：** 默认 push 会防止发送不合适的冲突历史。--allow-conflicts 是放宽保护，不是解决冲突。工具只能帮助编辑，最终内容和测试仍由你确认。

源码依据：[jj new](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/new.rs) · [jj resolve](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/resolve.rs) · [jj git push](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/push.rs) · [docs/conflicts.md](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/conflicts.md)。


<a id="workflow-11"></a>
## 11. 首次发布功能分支：显式管理书签

**适用场景：** 以下从当前 @ 为已完成且非空的工作 change 开始。先 new，确保书签指向完成的 @-，而不是新的空工作 change。

```sh
jj describe -m "feat: add request validation"
jj new
jj bookmark create feature-validation -r @-
jj bookmark list

jj git push --remote origin -b feature-validation --dry-run
# 核对上一步计划后，再推送
jj git push --remote origin -b feature-validation
```

**执行结果：** 书签是对外发布的名称。新建一个本地 change 不等于为远端创建一个分支；这里明确选择一个书签，避免默认推送范围的歧义。

**风险与边界：** 若书签已经存在，改用 bookmark set 或 advance，不要再次 create。merge 的 @- 可能不唯一；这时明确给出完成工作的修订。--dry-run 是 push 的局部选项。

源码依据：[jj describe](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/describe.rs) · [jj new](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/new.rs) · [jj bookmark create](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/create.rs) · [jj bookmark set](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/set.rs) · [jj git push](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/push.rs)。


<a id="workflow-12"></a>
## 12. 持续更新已发布的功能分支

**适用场景：** 当前工作完成后，把既有 feature-validation 书签前进到最新完成的提交，再按预期远端状态推送。

```sh
jj describe -m "feat: extend request validation"
jj new
jj bookmark advance feature-validation --to @-

jj git fetch --remote origin
jj bookmark list -a
jj git push --remote origin -b feature-validation --dry-run
jj git push --remote origin -b feature-validation
```

**执行结果：** 显式提供书签名和 --to 可以避免 bookmark-advance-from 配置选择到其他书签。push 检查远端引用是否与本地已知状态相符。

**风险与边界：** fetch 后出现书签分歧时，应先审查并选择/整合正确历史；不要仅为了消除报错直接使用 --allow-backwards。jj 没有通用 git push --force 对应流程。

源码依据：[jj bookmark advance](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/advance.rs) · [jj bookmark set](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/set.rs) · [jj git fetch](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/fetch.rs) · [jj git push](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/push.rs)。


<a id="workflow-13"></a>
## 13. 清理书签：delete、forget 与 untrack 不等价

**适用场景：** 先决定是希望删除远端分支，还是仅清理本机的命名/跟踪状态。以下只有方案 A 是主动准备远端删除。

```sh
jj bookmark list -a

# 方案 A：删除本地书签，并审阅将同步出去的删除
jj bookmark delete feature-old
jj git push --remote origin --deleted --dry-run
# 确认列表中每一项都应删除后才运行：
# jj git push --remote origin --deleted

# 方案 B：替代方案，只忘记本地书签
# jj bookmark forget feature-old

# 方案 C：替代方案，停止跟踪一个远端书签
# jj bookmark untrack feature-old@origin
```

**执行结果：** delete 表示本地删除意图可通过 push 传播；forget 不表示要把远端分支删掉；untrack 改变跟踪关系。

**风险与边界：** --deleted 可能覆盖多个待删除引用，不只示例中的一个。先审阅 dry-run。forget 后再次 fetch 的结果取决于保留的远端引用与自动跟踪配置。

源码依据：[jj bookmark delete](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/delete.rs) · [jj bookmark forget](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/forget.rs) · [jj bookmark untrack](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/untrack.rs) · [jj git push](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/push.rs)。


<a id="workflow-14"></a>
## 14. 只撤销某个文件的修改：restore

**适用场景：** 当前 @ 是普通单父提交，想把一个文件恢复到父修订内容，而不是撤销整个 jj 操作。

```sh
jj diff -- src/config.rs
jj restore --from @- -- src/config.rs
jj diff -- src/config.rs

# 对指定 change 撤销其相对父树的修改，使用另一种模式：
# jj restore --changes-in CHANGE_A -- src/config.rs
```

**执行结果：** --from 指定来源，--into 指定被重写目标；未指定目标时通常作用于 @。--changes-in 用合并父树作为基线，因此更适合表达“撤销这个 change 的改动”。

**风险与边界：** restore 会覆盖目标路径的修改。这里没有正常可用的 restore -r；v0.45.1 的隐藏 -r 仅用于报错提示。误操作后先检查 op log，不要立刻 gc。

源码依据：[jj restore](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/restore.rs) · [jj diff](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/diff.rs) · [jj operation log](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/log.rs)。


<a id="workflow-15"></a>
## 15. 操作做错了：undo、redo 与操作日志恢复

**适用场景：** 适用于误 rebase、abandon、squash、移动书签等仓库操作。先看操作日志，区分回退到某个状态和只反做某次操作。

```sh
jj op log -n 10

# 刚才那一步做错了
jj undo

# 反悔，重做刚撤销的一步
jj redo

# 更精确地处理：以下是替代方案，先把 OP_ID 换成实际操作 ID
# jj op show OP_ID
# jj op restore OP_ID
# jj op revert OP_ID
```

**执行结果：** restore 恢复到指定操作后的仓库视图；revert 在当前视图上反向应用某次操作，尽量保留别的后续工作。undo/redo 负责最近操作的前后移动。

**风险与边界：** 操作 ID 不是 change ID/commit ID。v0.45.1 的 jj undo 不接受操作 ID。任何本地恢复都不会自动撤回已经发生的远端 push，或恢复未跟踪的外部文件。

源码依据：[jj undo](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/undo.rs) · [jj redo](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/redo.rs) · [jj operation log](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/log.rs) · [jj operation restore](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/restore.rs) · [jj operation revert](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/revert.rs)。


<a id="workflow-16"></a>
## 16. 已发布历史不宜重写：用 revert 生成反向提交

**适用场景：** 已合并的某个提交有问题，需要保留审计历史，新增撤销补丁，而不是 abandon 或重写公共历史。

```sh
jj revert -r BAD_CHANGE -o 'trunk()'
jj log

# 取得新反向 change 的 ID 后检查
# jj show NEW_REVERT_CHANGE
# jj new NEW_REVERT_CHANGE
```

**执行结果：** revert 生成反向补丁对应的新修订。它和 op revert 完全不同：前者反转提交内容，后者反转一次仓库操作。

**风险与边界：** v0.45.1 必须同时指定待反转的 -r 和放置位置 -o/-A/-B。多个源修订按逆拓扑顺序处理，可能出现冲突；创建后不要假设 @ 自动切换。

源码依据：[jj revert](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/revert.rs) · [jj operation revert](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/revert.rs) · [jj show](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/show.rs)。


<a id="workflow-17"></a>
## 17. 追踪一个 change 怎样被改写：evolog 与 interdiff

**适用场景：** 提交图只能展示当前关系，无法直接说明同一个 change 被你 amend、rebase、squash 后怎样演化。

```sh
jj evolog -r @
jj evolog -r @ -p

# OLD_COMMIT 和 NEW_COMMIT 必须是两个具体版本的 commit ID
# jj interdiff --from OLD_COMMIT --to NEW_COMMIT
```

**执行结果：** log 查看提交关系，evolog 查看 change 的演化，op log 查看仓库操作。interdiff 比较两个版本的改动，并处理父基线差异。

**风险与边界：** 要比较旧对象，优先用具体 commit ID；当前 change ID 往往指向最新可见版本。不要把 evolog 当成作者/时间排序的普通日志。

源码依据：[jj evolog](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/evolog.rs) · [jj interdiff](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/interdiff.rs) · [jj log](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/log.rs) · [jj operation log](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/log.rs)。


<a id="workflow-18"></a>
## 18. 多个目录并行开发：workspace

**适用场景：** 为评审、实验或另一项功能开一个目录，共享同一仓库对象和引用，但有独立的 @。

```sh
# 显式以当前 @ 为父，创建名为 review 的新工作区
jj workspace add ../project-review --name review -r @
jj workspace list

cd ../project-review
jj status
jj new 'trunk()'

# 若 jj 明确报告工作区过期，再运行：
# jj workspace update-stale
```

**执行结果：** 额外 workspace 与主工作区共享提交/书签，不等于另一个完全独立 clone。省略 add 的 -r 时，新工作 change 默认与当前工作 change 共享父，而非以当前 @ 为父。

**风险与边界：** workspace forget 只移除管理记录，不删除磁盘目录；删除目录是另一个动作。不要跨工作区并行覆盖同一外部生成文件。v0.45.1 不支持额外 workspace 的 colocation。

源码依据：[jj workspace add](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/workspace/add.rs) · [jj workspace list](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/workspace/list.rs) · [jj workspace update-stale](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/workspace/update_stale.rs) · [jj workspace forget](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/workspace/forget.rs) · [jj git colocation](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/colocation.rs)。


<a id="workflow-19"></a>
## 19. 大仓库与跟踪控制：sparse、track、untrack

**适用场景：** 减少工作目录展开的内容，或处理被忽略/过大的新文件。稀疏检出和是否跟踪文件是两个不同问题。

```sh
jj sparse list
jj sparse set --clear --add src --add Cargo.toml --add Cargo.lock
jj sparse list

# 恢复完整工作目录
# jj sparse reset

# 只有确认应进入版本历史时，才显式跟踪
# jj file track path/to/file
# jj file track --include-ignored path/to/large-or-ignored-file

# 若要停止跟踪，应先配置忽略规则，避免随后自动重新跟踪
# jj file untrack path/to/generated-file
```

**执行结果：** sparse 控制本工作区展开哪些路径，不等于从提交中删除其他目录。track 可以把特定新文件纳入快照；untrack 不等于普通删除文件。

**风险与边界：** file track 的实际解析器要求路径，不能仅输入裸命令。--include-ignored 还会绕过新文件大小限制。任何停止跟踪操作都不会清除旧历史中的密钥，泄密应另行撤销凭据与清理历史。

源码依据：[jj sparse set](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/sparse/set.rs) · [jj sparse reset](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/sparse/reset.rs) · [jj file track](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/file/track.rs) · [jj file untrack](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/file/untrack.rs)。


<a id="workflow-20"></a>
## 20. 批量验证堆叠中的每个提交：run

**适用场景：** Rust 项目希望检查主线到当前工作的每一层，而不是只验证最终合并结果。显式限定 revset，并避免测试产物改写提交。

```sh
jj run -r 'trunk()..@' --root --ignore-changes -- cargo test

# 资源足够、测试彼此独立时，再选择并发：
# jj run -r 'trunk()..@' --root --ignore-changes --jobs 4 -- cargo test
```

**执行结果：** run 在隔离工作副本中执行命令；--root 从项目根运行；--ignore-changes 忽略测试造成的工作树变化，并允许检查不可变提交。

**风险与边界：** 隔离目录不是安全沙箱。外部命令可联网、访问数据库或修改目录外文件。复用目录会保留构建产物，必要时 --clean。CI 不应轻易加 --ignore-errors，因为失败不会按通常方式决定最终退出码。

源码依据：[jj run](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/run.rs)。


<a id="workflow-21"></a>
## 21. 自动整理每一层：run 与 fix 的边界

**适用场景：** 整仓库工具适合 run；按文件从标准输入接收内容并输出替代内容的转换器适合 fix。这里只使用未发布、可重写的修订。

```sh
# 格式化每个修订，并把结果写回相应 change
jj run -r 'trunk()..@ & mutable()' --root -- cargo fmt --all
jj op show -p
jj run -r 'trunk()..@' --root --ignore-changes -- cargo test

# 已配置 fix.tools 时的另一条路径：
# jj fix -s CHANGE_A
```

**执行结果：** 不带 --ignore-changes 的 run 可以把外部程序修改写回提交；fix 依据文件内容调用已配置工具，能按相同路径/内容去重处理。

**风险与边界：** 先审阅选中的修订范围。工具必须值得信任；格式化后仍可能产生冲突或影响后代。--restore-descendants 的“保持后代文件树”不等价于默认重放后代补丁；不要无意识混用。

源码依据：[jj run](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/run.rs) · [jj fix](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/fix.rs) · [jj operation show](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/show.rs)。


<a id="workflow-22"></a>
## 22. 定位首次引入问题的提交：bisect run

**适用场景：** 已知 GOOD_REV 正常、BAD_REV 有问题，且该问题在所选历史上近似单调。建议在单独 workspace 中执行。

```sh
# 先进入专用于排查的工作区；把两个占位符替换为实际修订
jj bisect run --range 'GOOD_REV..BAD_REV' -- cargo test
```

**执行结果：** 范围之外的祖先视为 good，范围的 heads 视为 bad。每次测试会直接把被测提交设为当前工作副本；0 为 good，125 为跳过，127 中止，其余非零为 bad。

**风险与边界：** 这不是 run 的隔离目录模型。测试必须能可靠地表达目标故障，编译失败也会被当成 bad，除非脚本主动返回 125。虽然 Usage 中 COMMAND 带方括号，实际运行必须提供命令或已弃用 --command。

源码依据：[jj bisect run](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bisect/run.rs) · [jj workspace add](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/workspace/add.rs)。


<a id="workflow-23"></a>
## 23. 发布标签与签名：先确定目标，再放宽任何保护

**适用场景：** 发布目标 RELEASE_REV 已通过测试。签名先于打标签，避免标签的不可变保护与历史重写互相冲突；签名后端须预先配置。

```sh
# 可选：已经配置签名后端时
# jj sign -r RELEASE_REV

jj tag set v1.2.3 -r RELEASE_REV
jj tag list
jj git push --remote origin --tag v1.2.3 --dry-run
# 确认目标和计划后：
# jj git push --remote origin --tag v1.2.3
```

**执行结果：** tag 是发布引用，set 默认不允许悄悄移动已有标签。sign/unsign 都会重写提交对象，不是给本地标签附加一段注释。

**风险与边界：** 不要把 --allow-move 当作常规发布选项，也不要把 jj 的提交签名误认为 Git annotated-tag 签名。发布后需要改内容，通常用新版本，而不是重用版本号。

源码依据：[jj tag set](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/tag/set.rs) · [jj tag list](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/tag/list.rs) · [jj git push](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/push.rs) · [jj sign](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/sign.rs) · [jj unsign](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/unsign.rs)。


<a id="workflow-24"></a>
## 24. Gerrit 代码评审：upload 与普通 push 分开

**适用场景：** 仓库使用 Gerrit，review 是已配置远端，main 是实际评审目标分支。当前完成工作在 @-，而 @ 是新的空 change。

```sh
jj gerrit upload --remote review --remote-branch main -r @- --dry-run
# 先核对上传范围和服务端选项：
# jj gerrit upload --remote review --remote-branch main -r @-
```

**执行结果：** gerrit upload 负责 Gerrit 的评审上传语义，并支持 reviewer、cc、topic、label 等服务端选项；它不是所有托管服务通用的创建 PR 命令。

**风险与边界：** 这一命令的 -n 是 --dry-run；不要套到 git push 上。--submit、--skip-validation、隐私和通知选项有服务端权限/配置约束，客户端接受参数不代表服务端一定执行。

源码依据：[jj gerrit upload](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/gerrit/upload.rs) · [jj git push](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/push.rs)。


## 最值得记住的选择表

| 你要做什么 | 首先考虑 | 不要混淆 |
|---|---|---|
| 改当前 change 的描述 | describe | commit 还会创建新工作 change |
| 从已有提交继续写 | new REV | edit REV 是直接编辑那个 change |
| 把修复归入已有工作 | squash --into REV | squash --onto 创建新目标的模式不同 |
| 自动按行归属回填祖先 | absorb | 不保证所有补丁都能归位 |
| 搬动整段后代 | rebase -s | -r 只选指定修订 |
| 复制补丁 | duplicate | rebase 不产生独立的逻辑改动身份 |
| 合并两条线 | new A B | 不要求先清空一个 Git-style 中间状态 |
| 丢弃本地改动内容 | restore | 可能覆盖工作副本，不是“只读查看” |
| 反做已发布提交 | revert | op revert 是反做仓库操作 |
| 撤销刚才操作 | undo / redo | v0.45.1 的 undo 不接受操作 ID |
| 恢复到指定仓库状态 | op restore | 不会自动撤回远端 push |
| 删除远端分支意图 | bookmark delete + push | forget / untrack 的含义不同 |
| 遍历多个提交执行工具 | run | 隔离工作副本不是安全沙箱 |
| 定位坏提交 | bisect run | 会直接切换被测工作副本 |

## 三种“历史”分别回答什么

`jj log`：现在的提交图是怎样的？
`jj evolog`：同一个 change 经历过哪些重写版本？
`jj op log`：仓库状态经过了哪些操作？

遇到异常先分清问题属于哪一层，再选择恢复命令。
对象清理不是第一反应：在需要恢复的阶段，避免运行 `jj op abandon` 和 `jj util gc`。

完整参数、默认值和已核实隐藏兼容项见 `jj-v0.45.1-zh.md`。


---

# 补篇：20 个 Revset 查询场景（R01–R20）

以下场景大部分只演示查询，避免把复杂集合直接交给 destructive 命令。第 14 个包含 `git fetch`，会联网并更新仓库状态，已单独标注。

示例中的 main、feature、origin、src 等名称不保证你的仓库存在；函数筛选到空集合可能是正常结果，不一定是命令失败。引用名、路径、邮箱和固定 ID 都应按仓库实际情况替换。

对即将用于修改操作的表达式，建议先记录并预览：

```sh
REVS='mine() & mutable()'
jj log -r "$REVS"
```

之后再按原工作流手册选择 `rebase`、`squash`、`abandon` 等具体操作。**revset 选中几个提交，不等于操作最终只会创建或重写几个提交对象**；后代重写、书签更新和不可变限制仍由命令决定。两次命令间 `@`、远端引用或仓库视图变化时，动态表达式的结果也可能变化。

## R01 · 查看当前所在的可变提交栈

**场景：** 包含当前工作相关的祖先、后代和域内兄弟分支。

```sh
jj log -r 'reachable(@, mutable())'
```

**注意：** 这是限定域内的双向连通集合；需要只看祖先时改为 ::@ & mutable()。修改命令采用这个集合前先确认没有不想动的兄弟分支。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R02 · 查看当前主线之外的非空改动

**场景：** 只看 @ 已包含而 trunk 尚未包含、且有文件修改的提交。

```sh
jj log -r '(trunk()..@) & ~empty()'
```

**注意：** 主线由 trunk() 的有效配置决定；@ 如果是非空工作提交也会被包括。不是所有仓库里的未发布提交。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R03 · 查我的可变工作

**场景：** 按 author 邮箱筛出自己的可变提交。

```sh
jj log -r 'mine() & mutable()'
```

**注意：** 先核对 user.email。这里只组合作者身份与不可变策略，不包含“是否已经 push”的判断。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R04 · 按代数查看历史，而不是按条数

**场景：** 对比所有父路径与第一父链。

```sh
jj log -r 'ancestors(@, 5)'
jj log -r 'first_ancestors(@, 5)'
```

**注意：** 都包括 @，最多再向前四代。合并图第一条可能远多于五个提交；若只要 committer 时间最新五个，用 latest(::@, 5)。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R05 · 按标题约定查找修复

**场景：** 筛选以 fix: 开头，或以 fix(scope): 开头的标题。

```sh
jj log -r 'subject(regex:"^fix([(][^)]*[)])?:")'
```

**注意：** 使用字符组 [(]、[)] 表示字面括号，避免 shell 与 revset 双层转义。更简单但宽松的选择是 subject(glob:"fix*")。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R06 · 限定一个明确的作者时间区间

**场景：** 查询 +08:00 时区 2026 年 9 月的作者时间。

```sh
jj log -r 'author_date(after:"2026-09-01T00:00:00+08:00") & author_date(before:"2026-10-01T00:00:00+08:00")'
```

**注意：** after 包含下界，before 排除上界。复现报告时优先使用这种绝对边界，不用随执行时间变化的 yesterday。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R07 · 调查最近发生过重写的候选

**场景：** 按 committer 时间看近期提交对象。

```sh
jj log -r 'committer_date(after:"2 days ago") & mutable()'
```

**注意：** 它筛选最近生成的对象，不独立证明每条都经历过重写；新提交也会匹配。与 author_date 对照更有意义。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R08 · 查看某个 Rust 模块的变更历史

**场景：** 把路径锚定到工作区根，不受当前所在子目录影响。

```sh
jj log -r '::@ & files(root-file:"src/http.rs")'
```

**注意：** src/http.rs 是示例路径。只查询该路径上的变更，不能据此断言已跨所有重命名自动追溯旧名字。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R09 · 找出 TODO 是什么时候加进来的

**场景：** 只搜索 src 下 diff 的新增侧。

```sh
jj log -r '::@ & diff_lines_added(substring:"TODO", root:"src")'
```

**注意：** 已有文件中的未变动 TODO 不会匹配。需要同时看添加与删除，改用 diff_lines()。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R10 · 查找某个旧 API 的删除

**场景：** 搜索删除侧，避免被相同文本的新增误导。

```sh
jj log -r '::@ & diff_lines_removed(substring:"old_api", root:"src")'
```

**注意：** old_api 是示例文本，src 是示例目录。匹配的是单行变更文本，不做语义级 Rust 符号解析。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R11 · 只查看当前可变历史里的文件冲突

**场景：** 排除不相关的不可变历史。

```sh
jj log -r 'conflicts() & mutable()'
```

**注意：** 结果反映文件树冲突，不反映书签目标冲突；后者查看 jj bookmark list。可变范围内有冲突的后代也可能被选入。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R12 · 定位 change 分歧

**场景：** 先查看所有分歧版本，再用 ID 或 offset 指定目标。

```sh
jj log -r 'divergent() & mutable()'
```

**注意：** 之后可用 change_id(实际ID) 查看某个分歧集合；用实际ID/0、实际ID/1 或完整 commit ID 精确定位。不要仅凭新旧顺序自动删除某一版本。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R13 · 预览空白草稿候选

**场景：** 找出自己没有说明也没有文件修改、且不是任何工作区当前目标的可变提交。

```sh
jj log -r '(mine() & mutable() & empty() & description("")) ~ working_copies()'
```

**注意：** 这只是审查候选，不等于可安全 abandon。空 merge、被书签引用的提交也可能有用途，清理前仍需核对图关系。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R14 · 看当前历史相对 origin 已知书签的差集

**场景：** 先更新 origin 的本地记录，再比较祖先闭包。

```sh
jj git fetch --remote origin
jj log -r 'remote_bookmarks(remote="origin")..@'
```

**注意：** fetch 会联网并更新仓库视图；本例不是纯只读查询。差集只依据 origin 书签，不代表远端所有对象或标签完全没有这些提交。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R15 · 总览本地引用与工作区边界

**场景：** 集中查看书签、标签和所有工作副本。

```sh
jj log -r 'bookmarks() | tags() | working_copies()'
```

**注意：** 这里仅选引用目标而不是它们全部祖先；日志可能用 ~ 表示被省略的中间历史。需要祖先闭包时写 ::(bookmarks() | tags() | working_copies())。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R16 · 找当前工作与主线的共同基点

**场景：** 找最近公共祖先，而不是凭时间猜分叉点。

```sh
jj log -r 'fork_point(@ | trunk())'
```

**注意：** 复杂交叉合并历史可能有多个最近公共祖先；要交给单目标命令时先检查，不能直接假定唯一。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R17 · 找两个 feature 最早共同进入哪里的历史

**场景：** 寻找共同后代的边界。

```sh
jj log -r 'merge_point(bookmarks(exact:"feature/a") | bookmarks(exact:"feature/b"))'
```

**注意：** 两个书签名是示例，先确认均存在。某个名称不匹配时 bookmarks() 返回空，可能只剩另一个输入；正式脚本应分别加 exactly(..., 1) 断言。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R18 · 兼容 main/master，但不吞掉歧义

**场景：** 按顺序选择存在的远端目标。

```sh
jj log -r 'coalesce(present(main@origin), present(master@origin), root())'
```

**注意：** present() 仅处理缺失，coalesce() 选第一个非空；不是按最新时间选择。main 的冲突或歧义不会被当成无结果自动忽略。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R19 · 从旧 operation 查看当前已经隐藏的提交

**场景：** 查看上一个操作的历史与当前可见历史的差别。

```sh
jj op log
jj --ignore-working-copy log -r 'hidden() & at_operation(@-, all())'
```

**注意：** 第一个参数 @- 是 operation 的父。并发操作历史可能分叉，@- 也可能无法唯一选择；需要稳定复查时用实际 operation ID 替换。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

## R20 · 给脚本的单目标加数量断言

**场景：** 不让一个本应单目标的查询悄悄变成多个目标或空。

```sh
jj log -r 'exactly(bookmarks(exact:"feature"), 1)'
```

**注意：** 示例要求本地 feature 书签存在且只有一个目标；否则故意报错。这比 latest(..., 1) 安全，因为后者会掩盖多目标事实。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。

