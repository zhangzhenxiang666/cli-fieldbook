# Jujutsu v0.45.1 中文命令手册

**版本基准：v0.45.1 · 发布日期：2026-09-03 · 查证日期：2026-09-17**

这是一份基于官方 CLI reference、命令枚举、Rust `clap::Args` 定义、内置配置及相关实现整理的中文说明。
覆盖 **122 个公开命令节点**（含根命令、命令组；其中 107 个非根叶子命令），另列
**26 个隐藏 debug 节点**与 **5 个 bench 条件编译节点**。别名不重复计数，共 153 个节点。

## 阅读范围与可信边界

公开命令的参数表按官方完整 CLI reference 整理，源码复核包括命令树、全局参数、
差异格式参数、默认配置及重点命令的隐藏参数和行为；debug / bench 根据固定版本源码补充。
这不是逐个文件执行自动 AST 审计的报告，也不声称枚举了所有未文档化的兼容参数。
“Hidden / Compatibility Options” 收录的是已核实项目，且区分可用别名、无操作兼容项和报错入口。

保留 `Usage:`、`Commands:`、`Arguments:`、`Options:`、`Diff Formatting Options:`、
`Global Options:` 的 help 结构，命令、参数、占位符不翻译，说明用中文重述。
这不是本环境运行 `jj --help` 后生成的逐字终端转录：中文排版、换行和补充注释经过重排，
部分冗长英文说明合并为中文要点；不保留 ANSI 颜色或终端的逐字节布局。

未在本环境安装/编译 jj，也未在实际仓库逐条执行工作流。源码通过在线官方源文件查阅；
无法建立本地源码克隆，因此不附带“已验证的源码快照”。
遇到帮助文字与解析器/实现不一致的地方，明确列在 `sources-and-coverage.md`。
你的二进制版本、编译 feature、操作系统和个人配置仍可能改变可用性和默认行为。

本手册的 CLI“参数”指命令行位置参数与选项；Revset 已在本次补篇中提供完整语言参考，覆盖 54 个文档函数、1 个弃用兼容名和 8 个默认别名。
TOML 的全部配置键、template 方法和外部工具参数仍不在“完整 CLI 参数”的范围内；Fileset 这里只解释 Revset 涉及的路径参数。

**Revset 补充修订：** 新增完整函数/符号/模式/别名、日志标记及 20 个查询场景；纠正旧 `all:` 建议。独立文件见 [revsets-zh.md](revsets-zh.md)。

## 文件导航

- `jj-v0.45.1-zh.html`：离线搜索，支持命令名、参数、中文含义和工作流。
- `jj-v0.45.1-zh.md`：完整命令手册，全局选项集中说明。
- `jj-v0.45.1-zh.txt`：help 风格文本，每个命令重复全局选项，适合全文检索。
- `workflows-zh.md`：24 个工作流，各自注明适用前提、结果和风险。
- `commands.json` / `shared-options.json`：结构化命令数据与共享选项。
- `sources-and-coverage.md`：来源、覆盖口径、差异和验证限制。
- `export_help.py`：在你本机用已安装的 jj 导出原始英文帮助字节，便于逐项对照。

## 怎么读命令语法

`<ARG>` 表示必填值；`[ARG]` 表示可选项；`...` 表示多个值或可重复。
但有时源码在运行阶段才校验必填，例如 `bisect run` 的 COMMAND，须同时看该命令的注记。
互斥关系不能只凭 Usage 简写猜测。本手册会列出重点互斥关系；最终仍由该版本解析器判定。

`--flag <VALUE>` 的尖括号不是需要输入的字符。shell 命令中的 `CHANGE_A`、`BASE`、
`GOOD_REV` 等是示例占位符，要替换成实际修订。`--` 结束 jj 选项解析，
例如 `jj run -r @ -- cargo test` 把后面的命令参数交给 cargo。

同一个短选项在不同子命令中可能完全不同：
`rebase -b` 是 branch，`git push -b` 是 bookmark，`diff -b` 是 ignore-space-change。
不要从单个命令推导全局短选项。`-r` 也不是全局参数。

## 核心对象与常见误解

| 对象 | 中文含义 | 最重要的区别 |
|---|---|---|
| working-copy commit / `@` | 当前工作区正在编辑的提交 | jj 没有必须经过 Git index 的通用暂存流程 |
| change ID | 一项逻辑改动的标识 | 重写通常保持；有分歧时可能对应多个版本 |
| commit ID | 某个不可变提交对象的标识 | 内容、描述、父关系或签名改变都可能产生新对象 |
| bookmark | 可移动的命名引用 | 是远端 Git 分支交互的重要入口，不等于 change 本身 |
| tag | 发布/标记引用 | 默认不允许任意移动；也影响默认不可变集合 |
| operation ID | 一次仓库状态操作的标识 | 用于 op log / restore / revert，不是提交 ID |
| workspace | 独立目录与自己的 `@` | 与其他 workspace 共享仓库对象和引用 |
| immutable | 默认受重写保护的历史 | `--ignore-immutable` 绕过的是保护，不是“更安全” |

通常运行 jj 命令时会为工作副本制作快照，所以 `status`、`diff` 也不应被理解成
对仓库元数据绝对零写入的命令。`--ignore-working-copy` 只控制工作副本快照/更新，
不是“所有命令只读”。`--no-integrate-operation` 也不是通用 dry-run。

## Revset、Fileset 和 Template 速查

### Revset：选择提交

完整参考已并入本文末尾：[Revset 阅读说明](#revset-intro) · [函数签名](#revset-function-syntax) · [日志标记](#revset-log-markers) · [版本勘误](#revset-migration)。

| 表达式 | 含义 |
|---|---|
| `@` | 当前工作副本提交 |
| `@-` / `@--` | 父 / 父的父；merge 时可能得到多个提交 |
| `@+` | 当前提交的孩子 |
| `::A` | A 及其全部祖先 |
| `A::` | A 及其全部后代，在表达式可见范围内 |
| `A::B` | 同时是 A 的后代和 B 的祖先；包含可满足条件的端点 |
| `A..B` | B 的祖先中排除 A 的祖先，不等价于任意意义的“路径” |
| `A \| B` | 并集 |
| `A & B` | 交集 |
| `A ~ B` | 差集 |
| `mutable()` | 可变集合，具体由配置定义 |
| `trunk()` | 主线 revset alias；先确认本仓库如何解析 |
| `feature@origin` | 远端跟踪引用 |
| `review@` | 名为 review 的工作区的工作副本 |

不是每个接受 revset 的参数都允许多个结果：例如 edit 要求单个目标，rebase 的集合选项可选择多个。
v0.45.1 已移除 `all:` 修饰符。是否允许多个结果由命令参数决定；需要单目标断言时可使用 `exactly(x, 1)`。
表达式请使用 shell 引号，例如 `jj log -r 'trunk()..@'`。

### Fileset：选择路径

`src/` 用于路径/目录范围，`glob:**/*.rs` 是显式 glob，`all()` 表示所有路径。
例如 `jj diff 'glob:**/*.rs'` 将 glob 交给 jj，而不是让 shell 预先展开。
模式的根目录语义、字符串模式和文件集合表达式并不完全相同：
bookmark 名称过滤的 glob 不是路径 fileset，clone/fetch 的 Git 分支模式也不是完整 fileset。

### Template：输出你需要的字段

```sh
jj log --no-graph -r @ -T 'change_id ++ "\n"'
jj log --no-graph -r @ -T 'commit_id ++ "\n"'
jj log -r 'trunk()..@' -T 'change_id.short() ++ " " ++ description.first_line() ++ "\n"'
```

模板的输入对象类型取决于命令：log/show 常见为 Commit，bookmark list 为引用对象，
file annotate 为注释行，operation log 为 Operation；同名 `-T` 不保证接受同一组字段。
用于脚本时应指定模板，不要解析彩色图形日志。文件名可能含空白，也不要盲目把 name-only 接到裸 xargs。

官方语言文档：[revsets](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md) ·
[filesets](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/filesets.md) · [templates](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/templates.md) ·
[working copy](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/working-copy.md)。

<a id="global-options"></a>
## 全局选项

这些选项适用于命令树中的命令。Markdown 为避免每节重复，集中列于此；
TXT 则在每个节点重复。`-h/--help` 由各级 help 提供；`-V/--version` 只列在根入口，
不要假定所有子命令都接受 `-V`。

```text
Global Options:
  -R, --repository <REPOSITORY>
          指定要操作的仓库路径；未指定时，从当前目录向上查找最近的 .jj。

  --ignore-working-copy
          既不为当前工作目录制作快照，也不更新工作目录。读到的 @ 可能落后于磁盘；这不是禁止修改仓
          库历史的只读开关。

  --no-integrate-operation
          正常生成操作，但不将其整合为当前操作头，也不更新工作目录；输出新 operation ID，可用
          --at-op 检查，再用 jj op integrate 整合。这不是通用 dry-run：命令可能拒绝该选项或产生仓
          库外副作用。v0.45.1 的 git push 明确拒绝此选项，须使用 push --dry-run。

  --ignore-immutable
          绕过不可变提交的重写保护；根提交仍不能重写。不会改变 immutable_heads() 或模板中的
          immutable 判断。

  --at-operation <AT_OPERATION>
          以指定操作的仓库状态运行；别名 --at-op。接受无歧义 operation ID 前缀及操作表达式。隐含
          --ignore-working-copy；并不限制命令为只读。

  --debug
          开启调试日志；与隐藏的 jj debug 子命令组不同。

  --color <WHEN>
          控制着色：always 始终、never 从不、auto 自动、debug 输出样式标签用于调试。

  --quiet
          隐藏辅助说明，保留命令主要结果、警告和错误；没有通用 -q 短形式。

  --no-pager
          禁用分页器，直接输出。

  --config <NAME=VALUE>
          为本次调用追加配置，可重复。NAME 使用 TOML 点分键，VALUE 使用 TOML 值；注意 shell 与
          TOML 两层引号。

  --config-file <PATH>
          为本次调用加载额外配置文件，可重复；不会把它等同于 config set/edit 的写入目标 --file。
```

来源：[GlobalArgs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/cli_util.rs)。

## 共享差异格式选项

并非所有命令都支持它们，只有对应命令节出现 `Diff Formatting Options:` 时才适用。

`--summary / --stat / --types / --name-only` 属于互斥的短格式组；
`--git / --color-words` 属于互斥的长格式组。短格式可以与长格式组合，
例如 `jj diff --stat --git`。`--tool` 的冲突规则还取决于它选择的内置/外部格式。
`--ignore-all-space` 与 `--ignore-space-change` 互斥。

`-w/-b` 短形式只在本手册已核实的 `diff`、`interdiff`、`show` 列出；
log/evolog 等不要据此类推。`--tool` 在展示差异和交互编辑命令中的角色也不同。

来源：[DiffFormatArgs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/diff_util.rs)。

## 完整命令树

```text
jj
|-- abandon
|-- absorb
|-- arrange
|-- bisect
|   `-- run
|-- bookmark
|   |-- advance
|   |-- create
|   |-- delete
|   |-- forget
|   |-- list
|   |-- move
|   |-- rename
|   |-- set
|   |-- track
|   `-- untrack
|-- commit
|-- config
|   |-- edit
|   |-- gc
|   |-- get
|   |-- list
|   |-- path
|   |-- set
|   `-- unset
|-- converge
|-- describe
|-- diff
|-- diffedit
|-- duplicate
|-- edit
|-- evolog
|-- file
|   |-- annotate
|   |-- chmod
|   |-- list
|   |-- search
|   |-- show
|   |-- track
|   `-- untrack
|-- fix
|-- gerrit
|   `-- upload
|-- git
|   |-- clone
|   |-- colocation
|   |   |-- disable
|   |   |-- enable
|   |   `-- status
|   |-- export
|   |-- fetch
|   |-- import
|   |-- init
|   |-- push
|   |-- remote
|   |   |-- add
|   |   |-- list
|   |   |-- remove
|   |   |-- rename
|   |   `-- set-url
|   `-- root
|-- help
|-- interdiff
|-- log
|-- metaedit
|-- new
|-- next
|-- operation
|   |-- abandon
|   |-- diff
|   |-- integrate
|   |-- log
|   |-- restore
|   |-- revert
|   `-- show
|-- parallelize
|-- prev
|-- rebase
|-- redo
|-- resolve
|-- restore
|-- revert
|-- root
|-- run
|-- show
|-- sign
|-- simplify-parents
|-- sparse
|   |-- edit
|   |-- list
|   |-- reset
|   `-- set
|-- split
|-- squash
|-- status
|-- tag
|   |-- delete
|   |-- list
|   |-- set
|   |-- track
|   `-- untrack
|-- undo
|-- unsign
|-- util
|   |-- backend
|   |   `-- name
|   |-- completion
|   |-- config-schema
|   |-- exec
|   |-- gc
|   |-- install-man-pages
|   |-- markdown-help
|   `-- snapshot
|-- version
|-- workspace
|   |-- add
|   |-- forget
|   |-- list
|   |-- rename
|   |-- root
|   `-- update-stale
|-- debug [隐藏 / 开发者]
|   |-- copy-detection [隐藏 / 开发者]
|   |-- fileset [隐藏 / 开发者]
|   |-- index [隐藏 / 开发者]
|   |-- index-changed-paths [隐藏 / 开发者]
|   |-- init-simple [隐藏 / 开发者]
|   |-- local-working-copy [隐藏 / 开发者]
|   |-- object [隐藏 / 开发者]
|   |   |-- commit [隐藏 / 开发者]
|   |   |-- file [隐藏 / 开发者]
|   |   |-- operation [隐藏 / 开发者]
|   |   |-- symlink [隐藏 / 开发者]
|   |   |-- tree [隐藏 / 开发者]
|   |   `-- view [隐藏 / 开发者]
|   |-- reindex [隐藏 / 开发者]
|   |-- revset [隐藏 / 开发者]
|   |-- snapshot [隐藏 / 开发者]
|   |-- stacked-table [隐藏 / 开发者]
|   |-- template [隐藏 / 开发者]
|   |-- tree [隐藏 / 开发者]
|   |-- watchman [隐藏 / 开发者]
|   |   |-- query-changed-files [隐藏 / 开发者]
|   |   |-- query-clock [隐藏 / 开发者]
|   |   |-- reset-clock [隐藏 / 开发者]
|   |   `-- status [隐藏 / 开发者]
|   `-- working-copy [隐藏 / 开发者]
`-- bench [条件编译 / 基准测试]
    |-- common-ancestors [条件编译 / 基准测试]
    |-- is-ancestor [条件编译 / 基准测试]
    |-- resolve-prefix [条件编译 / 基准测试]
    `-- revset [条件编译 / 基准测试]
```


## 公开命令逐项参考


<a id="cmd-jj"></a>
### `jj`

类别：公开

```text
Jujutsu：与 Git 兼容的版本控制工具。

Usage: jj [OPTIONS] [COMMAND]

Commands:
  abandon
          放弃一个或多个修订，并把其后代变基到它们的父提交。

  absorb
          把源修订中的修改自动分配到最近修改相应代码行的可变祖先。

  arrange
          交互式调整提交图。

  bisect
          通过二分搜索定位第一个坏修订。

  bookmark
          管理书签：可移动、可与远端同步的提交名称。 别名：b（默认配置别名，可覆盖）

  commit
          更新当前 change 的描述，并在其上创建新的工作副本 change。 别名：ci（默认配置别名，可覆盖）

  config
          读取或修改配置；配置项本身不等于 CLI 参数。

  converge
          把同一 change ID 的多个可见分歧版本收敛成一个版本。

  describe
          修改 change 描述。 别名：desc（默认配置别名，可覆盖）

  diff
          比较两个修订的文件内容，或显示一个修订集合引入的净变化。

  diffedit
          在差异编辑器中修改某个修订的内容。

  duplicate
          复制修订为新的 change，保留原修订。

  edit
          直接把已有修订设为当前工作副本修订。

  evolog
          查看同一个 change 随修改、变基而产生的历史版本。 别名：evolution-log, obslog（隐藏兼容别
          名）

  file
          针对受版本控制文件的读取、搜索和跟踪操作。

  fix
          用已配置的文件转换器修复选定修订及其后代。

  gerrit
          与 Gerrit 代码审查服务交互（需要 git 编译特性）。

  git
          Git 后端、远端和互操作命令（需要 git 编译特性）。

  help
          显示指定命令路径的帮助，或打开关键字文档。

  interdiff
          比较两个修订各自引入的修改，而非简单比较最终文件树。

  log
          显示提交图。

  metaedit
          修改提交元数据，而不直接修改文件内容。

  new
          创建一个空 change，默认切换工作副本来编辑它。

  next
          沿 后继 方向移动工作位置。

  operation
          管理仓库操作历史，而不是提交图。 别名：op

  parallelize
          把指定修订整理为并行的兄弟变化。

  prev
          沿 祖先 方向移动工作位置。

  rebase
          把指定 change 移到新的父修订 / 插入位置。

  redo
          重做最近被 undo 撤销的操作。

  resolve
          使用外部三方合并工具处理冲突文件。

  restore
          把目标修订中的路径内容恢复为来源修订的内容。

  revert
          在指定位置新建反向修改，用来撤销既有提交的效果。

  root
          输出当前工作区根目录，是 jj workspace root 的快捷入口。

  run
          在隔离工作副本中跨多个修订执行外部命令，默认把执行产生的修改写回修订。

  show
          显示修订的元数据和相对父树的补丁。

  sign
          为修订添加密码学签名。

  simplify-parents
          删除冗余父边，不改变修订的文件树。

  sparse
          管理工作副本中实际展开的路径；不删除提交中其他文件。

  split
          把一个修订的修改拆为两部分。

  squash
          把来源修订的修改移动到目标修订。

  status
          显示工作修改、工作修订及其父、文件冲突与书签冲突。 别名：st（默认配置别名）

  tag
          管理本地和远端标签。

  undo
          撤销最近一次操作；连续运行可继续向更早的状态回退。

  unsign
          移除修订的密码学签名。

  util
          生成补全、导出帮助、执行脚本及维护后端等低频命令。

  version
          显示 jj 版本与构建信息。

  workspace
          管理共享同一仓库的多个工作副本。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。

  -V, --version
          显示版本。
```

全局参数见 [Global Options](#global-options)。

**注意：** 未指定子命令时，由 ui.default-command 决定实际执行的命令，内置默认是 log。用户 aliases 可以增加入口，因而不存在跨所有用户配置的有限“全部别名”清单。

源码：[cli/src/commands/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/mod.rs)。


<a id="cmd-abandon"></a>
### `jj abandon`

类别：公开

```text
放弃一个或多个修订，并把其后代变基到它们的父提交。

Usage: jj abandon [OPTIONS] [REVSETS]...

Arguments:
  [REVSETS]...
          要放弃的修订集合；默认 @。也接受 -r 形式。

Options:
  --retain-bookmarks
          不删除指向被放弃修订的书签，而是把它们移到父修订。

  --restore-descendants
          保持子提交的最终文件内容，而不是通常的差异重放行为。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 若放弃了工作副本提交，会创建新的空工作副本提交。放弃不是永久擦除对象；但后续清理可能缩小恢复窗口。

源码：[cli/src/commands/abandon.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/abandon.rs)。


<a id="cmd-absorb"></a>
### `jj absorb`

类别：公开

```text
把源修订中的修改自动分配到最近修改相应代码行的可变祖先。

Usage: jj absorb [OPTIONS] [FILESETS]...

Arguments:
  [FILESETS]...
          只考虑匹配路径中的修改；省略时考虑全部路径。

Options:
  -f, --from <REVSET>
          源修订；默认 @。

  -t, --into <REVSETS>
          允许接收修改的修订；默认 mutable()。只考虑源修订的祖先；别名 --to。

  -i, --interactive
          先交互选择需要吸收的修改块。

  --tool <NAME>
          选择差异编辑器，隐含 --interactive。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 不能无歧义确定归属的修改留在源修订。只有所有修改都已吸收且源修订没有描述时，源修订才会被自动放弃。用 jj op show -p 检查结果。

源码：[cli/src/commands/absorb.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/absorb.rs)。


<a id="cmd-arrange"></a>
### `jj arrange`

类别：公开

```text
交互式调整提交图。

Usage: jj arrange [REVSETS]...

Arguments:
  [REVSETS]...
          要排列的修订；也接受 -r。默认使用 revsets.arrange。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 终端交互界面适合重排提交关系；改变依赖可能引入内容冲突。

源码：[cli/src/commands/arrange.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/arrange.rs)。


<a id="cmd-bisect"></a>
### `jj bisect`

类别：公开

```text
通过二分搜索定位第一个坏修订。

Usage: jj bisect <COMMAND>

Commands:
  run
          执行检测命令，二分定位引入问题的修订。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/bisect/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bisect/mod.rs)。


<a id="cmd-bisect-run"></a>
### `jj bisect run`

类别：公开

```text
执行检测命令，二分定位引入问题的修订。

Usage: jj bisect run [OPTIONS] --range <REVSETS> [COMMAND] [ARGS]...

Arguments:
  [COMMAND]
          检测程序。退出码 0 为 good，125 为跳过，127 为中止；其余非零码为 bad。

  [ARGS]...
          传给检测程序的参数；建议用 -- 隔开 jj 参数和程序参数。

Options:
  -r, --range <REVSETS>
          必填，可重复；取各范围的并集。通常使用 GOOD..BAD。范围顶端假定为坏，范围外的祖先假定为好。

  --find-good
          改为找第一个好修订；反转普通 good/bad 退出码解释，125 和 127 的特殊意义不变。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  --command <COMMAND>
          已弃用的隐藏形式；与位置 COMMAND 互斥。改用 -- 后的位置命令及参数。
```

**注意：** 每次会直接编辑被测修订并切换当前工作副本，不是 jj run 的独立工作目录模型。目标 commit ID 通过 JJ_BISECT_TARGET 提供。要求问题在所选历史上近似单调。 虽然 clap 的 Usage 将 [COMMAND] 显示为可选，但实际执行要求位置命令或旧 --command 至少提供一个；省略会报错。

源码：[cli/src/commands/bisect/run.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bisect/run.rs)。


<a id="cmd-bookmark"></a>
### `jj bookmark`

类别：公开 · 别名：`b（默认配置别名，可覆盖）`

```text
管理书签：可移动、可与远端同步的提交名称。

Usage: jj bookmark <COMMAND>

Commands:
  advance
          把离目标最近的书签向前推进。 别名：a

  create
          创建新书签。 别名：c

  delete
          删除本地书签，并记录待推送到所跟踪远端的删除。 别名：d

  forget
          忘记书签，不把本地删除传播到远端。 别名：f

  list
          列出书签及其目标。 别名：l

  move
          移动已有书签，不创建新书签。 别名：m

  rename
          重命名书签，保持其目标提交不变。 别名：r

  set
          按名称创建或更新书签。 别名：s

  track
          开始跟踪远端书签。 别名：t

  untrack
          停止跟踪远端书签。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/bookmark/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/mod.rs)。


<a id="cmd-bookmark-advance"></a>
### `jj bookmark advance`

类别：公开 · 别名：`a`

```text
把离目标最近的书签向前推进。

Usage: jj bookmark advance [OPTIONS] [NAMES]...

Arguments:
  [NAMES]...
          指定书签名称模式；指定后不使用默认 from revset 选择书签。

Options:
  -t, --to <REVSET>
          目标修订；来自 revsets.bookmark-advance-to，内置默认 @。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 未指定名称时，候选来自 revsets.bookmark-advance-from，内置默认 heads(::to & bookmarks())；to 在该表达式中可用。

源码：[cli/src/commands/bookmark/advance.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/advance.rs)。


<a id="cmd-bookmark-create"></a>
### `jj bookmark create`

类别：公开 · 别名：`c`

```text
创建新书签。

Usage: jj bookmark create [OPTIONS] <NAMES>...

Arguments:
  <NAMES>...
          要创建的书签名称。

Options:
  -r, --revision <REVSET>
          目标修订；默认 @；别名 --to。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/bookmark/create.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/create.rs)。


<a id="cmd-bookmark-delete"></a>
### `jj bookmark delete`

类别：公开 · 别名：`d`

```text
删除本地书签，并记录待推送到所跟踪远端的删除。

Usage: jj bookmark delete <NAMES>...

Arguments:
  <NAMES>...
          要删除的书签名称模式，默认 glob。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 不会同时放弃提交。远端删除要到之后选中该书签的 push 才发生；只想本地忘记请用 bookmark forget。

源码：[cli/src/commands/bookmark/delete.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/delete.rs)。


<a id="cmd-bookmark-forget"></a>
### `jj bookmark forget`

类别：公开 · 别名：`f`

```text
忘记书签，不把本地删除传播到远端。

Usage: jj bookmark forget [OPTIONS] <NAMES>...

Arguments:
  <NAMES>...
          要忘记的书签名称模式，默认 glob。

Options:
  --include-remotes
          同时忘记对应远端书签的本地记录；包括 Git-tracking 记录。远端真实存在时，下次 fetch 可重
          新出现。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 忘记本地书签会取消相应远端跟踪关系；此命令本身不删除远端分支。

源码：[cli/src/commands/bookmark/forget.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/forget.rs)。


<a id="cmd-bookmark-list"></a>
### `jj bookmark list`

类别：公开 · 别名：`l`

```text
列出书签及其目标。

Usage: jj bookmark list [OPTIONS] [NAMES]...

Arguments:
  [NAMES]...
          按本地书签名称模式过滤，默认 glob。

Options:
  -a, --all-remotes
          包括所有跟踪和未跟踪远端书签，也显示与本地同步的目标。

  --remote <REMOTE>
          按远端名称模式过滤，可重复；可与 --tracked、--conflicted 组合。

  -t, --tracked
          只列出已跟踪远端书签，默认不包括本地 Git-tracking 书签。

  -c, --conflicted
          只列出存在目标冲突的书签。

  -r, --revision <REVSETS>
          只列出本地目标落在所给修订集合中的书签，可重复。

  -T, --template <TEMPLATE>
          书签输出模板，类型 CommitRef；默认 templates.bookmark_list。

  --sort <SORT_KEY>
          排序键，可组合；末尾加 - 表示降序。键：name、author-name、author-email、author-date、
          committer-name、committer-email、committer-date，及各自的降序形式。默认
          ui.bookmark-list-sort-keys。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 默认仅在跟踪远端目标与本地不同时附带远端记录；未跟踪远端默认不显示。冲突中 - 是旧目标，+ 是新目标。

源码：[cli/src/commands/bookmark/list.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/list.rs)。


<a id="cmd-bookmark-move"></a>
### `jj bookmark move`

类别：公开 · 别名：`m`

```text
移动已有书签，不创建新书签。

Usage: jj bookmark move [OPTIONS] <NAMES|--from <REVSETS>>

Arguments:
  [NAMES]...
          要移动的书签名称模式；与 --from 同用时，进一步过滤该范围内的书签。

Options:
  -f, --from <REVSETS>
          选择目前指向这些修订的书签，可重复。

  -t, --to <REVSET>
          目标修订；默认 @。

  -B, --allow-backwards
          允许向后或横向移动，不局限于后代方向。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/bookmark/move.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/move.rs)。


<a id="cmd-bookmark-rename"></a>
### `jj bookmark rename`

类别：公开 · 别名：`r`

```text
重命名书签，保持其目标提交不变。

Usage: jj bookmark rename [OPTIONS] <OLD> <NEW>

Arguments:
  <OLD>
          旧名称。

  <NEW>
          新名称。

Options:
  --overwrite-existing
          允许覆盖已经存在的新名称。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/bookmark/rename.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/rename.rs)。


<a id="cmd-bookmark-set"></a>
### `jj bookmark set`

类别：公开 · 别名：`s`

```text
按名称创建或更新书签。

Usage: jj bookmark set [OPTIONS] <NAMES>...

Arguments:
  <NAMES>...
          需要设置的书签名称。

Options:
  -r, --revision <REVSET>
          目标修订；默认 @；别名 --to。

  -B, --allow-backwards
          允许把已有书签向后或横向移动。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 需要严格保证不创建新名称时，用 bookmark move。

源码：[cli/src/commands/bookmark/set.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/set.rs)。


<a id="cmd-bookmark-track"></a>
### `jj bookmark track`

类别：公开 · 别名：`t`

```text
开始跟踪远端书签。

Usage: jj bookmark track [OPTIONS] <BOOKMARK[@REMOTE]>...

Arguments:
  <BOOKMARK[@REMOTE]>...
          BOOKMARK 是名称模式（默认 glob）；BOOKMARK@REMOTE 是精确的远端书签符号。

Options:
  --remote <REMOTE>
          按远端名称模式过滤，可重复。省略时作用于所有名称匹配的远端书签。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 跟踪后，远端书签会导入为同名本地书签，后续 fetch 可更新它。

源码：[cli/src/commands/bookmark/track.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/track.rs)。


<a id="cmd-bookmark-untrack"></a>
### `jj bookmark untrack`

类别：公开

```text
停止跟踪远端书签。

Usage: jj bookmark untrack [OPTIONS] <BOOKMARK[@REMOTE]>...

Arguments:
  <BOOKMARK[@REMOTE]>...
          BOOKMARK 是名称模式（默认 glob）；BOOKMARK@REMOTE 是精确的远端书签符号。

Options:
  --remote <REMOTE>
          按远端名称模式过滤，可重复。省略时作用于所有名称匹配的远端书签。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 停止跟踪不会删除本地书签，也不会删除服务器上的分支。

源码：[cli/src/commands/bookmark/untrack.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bookmark/untrack.rs)。


<a id="cmd-commit"></a>
### `jj commit`

类别：公开 · 别名：`ci（默认配置别名，可覆盖）`

```text
更新当前 change 的描述，并在其上创建新的工作副本 change。

Usage: jj commit [OPTIONS] [FILESETS]...

Arguments:
  [FILESETS]...
          把所选路径的修改留在当前提交，其余修改放到新工作副本提交。

Options:
  -i, --interactive
          交互选择留在当前提交的修改。

  --tool <NAME>
          差异编辑器，隐含 --interactive。

  -m, --message <MESSAGE>
          提交描述；可重复以组成多个段落，不打开编辑器。

  --editor
          即使给了 --message，仍打开编辑器继续修改。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 没有 -r：始终操作 @。不选路径、不用 -i 时近似 describe 后 new。已有书签不会像普通 split 那样自动前移到新的子 change。

源码：[cli/src/commands/commit.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/commit.rs)。


<a id="cmd-config"></a>
### `jj config`

类别：公开

```text
读取或修改配置；配置项本身不等于 CLI 参数。

Usage: jj config <COMMAND>

Commands:
  edit
          用编辑器打开配置文件；文件不存在时创建。 别名：e

  gc
          找出并可选择删除仓库路径已不存在的仓库级配置目录。

  get
          读取一个配置值，不带额外展示格式，适合脚本。 别名：g

  list
          列出配置变量、值及可选来源信息。 别名：l

  path
          输出配置文件路径；文件未必存在。 别名：p

  set
          把配置键写成指定值。 别名：s

  unset
          从指定配置文件移除一个配置键。 别名：u

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/config/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/config/mod.rs)。


<a id="cmd-config-edit"></a>
### `jj config edit`

类别：公开 · 别名：`e`

```text
用编辑器打开配置文件；文件不存在时创建。

Usage: jj config edit <--user|--repo|--workspace|--file <PATH>>

Options:
  --user
          用户级配置。

  --repo
          仓库级配置。

  --workspace
          工作区级配置。

  --file <PATH>
          指定受 jj 识别的配置文件作为写入/编辑目标；不是任意路径。可先用全局 --config-file 加载文
          件。set/edit 可创建尚不存在的合法目标及其父目录。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 必须且只能选一个目标。v0.45 起 --user 使用首先加载的用户配置文件；指定 conf.d 中某个文件时请用 --file。

源码：[cli/src/commands/config/edit.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/config/edit.rs)。


<a id="cmd-config-gc"></a>
### `jj config gc`

类别：公开

```text
找出并可选择删除仓库路径已不存在的仓库级配置目录。

Usage: jj config gc

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 涉及配置目录清理；执行前阅读交互提示，不等于仓库对象的 util gc。

源码：[cli/src/commands/config/gc.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/config/gc.rs)。


<a id="cmd-config-get"></a>
### `jj config get`

类别：公开 · 别名：`g`

```text
读取一个配置值，不带额外展示格式，适合脚本。

Usage: jj config get <NAME>

Arguments:
  <NAME>
          配置键，例如 user.name。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/config/get.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/config/get.rs)。


<a id="cmd-config-list"></a>
### `jj config list`

类别：公开 · 别名：`l`

```text
列出配置变量、值及可选来源信息。

Usage: jj config list [OPTIONS] [NAME]

Arguments:
  [NAME]
          可选的配置键或键前缀。

Options:
  --include-defaults
          把内置默认配置也列出。

  --include-overridden
          保留已经被更高优先级配置覆盖的条目。

  --user
          用户级配置。

  --repo
          仓库级配置。

  --workspace
          工作区级配置。

  -T, --template <TEMPLATE>
          自定义格式。可用 name、value、overridden、source、path；默认 templates.config_list。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 不指定层级时检查合并后的配置；需要定位来源可用 -T builtin_config_list_detailed。

源码：[cli/src/commands/config/list.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/config/list.rs)。


<a id="cmd-config-path"></a>
### `jj config path`

类别：公开 · 别名：`p`

```text
输出配置文件路径；文件未必存在。

Usage: jj config path <--user|--repo|--workspace>

Options:
  --user
          用户级配置。

  --repo
          仓库级配置。

  --workspace
          工作区级配置。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 必须选一个层级。--repo/--workspace 在尚无配置目录时可能创建目录，所以不是绝对无副作用的查询。

源码：[cli/src/commands/config/path.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/config/path.rs)。


<a id="cmd-config-set"></a>
### `jj config set`

类别：公开 · 别名：`s`

```text
把配置键写成指定值。

Usage: jj config set <--user|--repo|--workspace|--file <PATH>> <NAME> <VALUE>

Arguments:
  <NAME>
          配置键，使用 TOML 点分语法。

  <VALUE>
          TOML 表达式；普通字符串可省略 TOML 引号，但 shell 引号仍需正确处理。

Options:
  --user
          用户级配置。

  --repo
          仓库级配置。

  --workspace
          工作区级配置。

  --file <PATH>
          指定受 jj 识别的配置文件作为写入/编辑目标；不是任意路径。可先用全局 --config-file 加载文
          件。set/edit 可创建尚不存在的合法目标及其父目录。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 目标四选一。复杂数组、含引号文本建议用 config edit。

源码：[cli/src/commands/config/set.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/config/set.rs)。


<a id="cmd-config-unset"></a>
### `jj config unset`

类别：公开 · 别名：`u`

```text
从指定配置文件移除一个配置键。

Usage: jj config unset <--user|--repo|--workspace|--file <PATH>> <NAME>

Arguments:
  <NAME>
          要移除的配置键。

Options:
  --user
          用户级配置。

  --repo
          仓库级配置。

  --workspace
          工作区级配置。

  --file <PATH>
          指定受 jj 识别的配置文件作为写入/编辑目标；不是任意路径。可先用全局 --config-file 加载文
          件。set/edit 可创建尚不存在的合法目标及其父目录。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 移除高优先级配置后，低优先级的同名设置可能重新生效。

源码：[cli/src/commands/config/unset.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/config/unset.rs)。


<a id="cmd-converge"></a>
### `jj converge`

类别：公开

```text
把同一 change ID 的多个可见分歧版本收敛成一个版本。

Usage: jj converge [OPTIONS]

Options:
  -r, --revision <REVSETS>
          查找分歧版本的范围，可重复；默认 revsets.converge。

  --no-interactive
          不请求人工协助。无法自动解决时警告并不作修改；不要把退出成功当成所有分歧都已消失。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 只收敛选中集合内的分歧版本；可能仍留有其他版本。会重定位后代及本地书签，结果仍可能有文件冲突。此命令解决 change 分歧，不等于 resolve 解决文件冲突。

源码：[cli/src/commands/converge.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/converge.rs)。


<a id="cmd-describe"></a>
### `jj describe`

类别：公开 · 别名：`desc（默认配置别名，可覆盖）`

```text
修改 change 描述。

Usage: jj describe [OPTIONS] [REVSETS]...

Arguments:
  [REVSETS]...
          要编辑描述的修订；默认 @；支持 -r 形式。

Options:
  -m, --message <MESSAGE>
          直接指定描述，可重复组成段落；多修订共用该描述。

  --stdin
          从标准输入读取描述；多修订共用。

  --editor
          在 --message/--stdin 提供初始文本后仍打开编辑器。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  -r <REVSETS>
          位置修订参数的隐藏便捷写法；可重复并与位置参数合并；不是 --revision 长选项。
```

**注意：** 可一次修改多个修订描述。-m 可重复，按段落连接；--stdin 与 --message 互斥。v0.45.1 没有 describe --author；作者等元数据请使用 metaedit。

源码：[cli/src/commands/describe.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/describe.rs)。


<a id="cmd-diff"></a>
### `jj diff`

类别：公开

```text
比较两个修订的文件内容，或显示一个修订集合引入的净变化。

Usage: jj diff [OPTIONS] [FILESETS]...

Arguments:
  [FILESETS]...
          只显示匹配路径。

Options:
  -r, --revisions <REVSETS>
          显示这些修订合计引入的变化；默认 -r @。集合不能在同一链上留空洞。

  -f, --from <REVSET>
          左侧修订；只指定 --to 时这里默认 @。

  -t, --to <REVSET>
          右侧修订；只指定 --from 时这里默认 @。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。

Diff Formatting Options:
  -s, --summary
          每条路径仅显示新增、修改、删除等状态。

  --stat
          显示变更行数统计和直方图。

  --types
          显示变更前后对象类型：- 不存在，F 普通文件，L 符号链接，C 冲突，G Git 子模块。

  --name-only
          只输出路径；路径可能包含空格，不宜直接接不处理转义的 xargs。

  --git
          使用 Git patch 格式。

  --color-words
          使用主要依靠颜色标记变化的词级差异格式。

  --tool <TOOL>
          使用外部差异显示工具；也可用 :git、:summary、:stat、:types、:name-only、:color-words 选
          择内置格式。不是交互式修改文件。

  --context <CONTEXT>
          指定显示多少行上下文。

  -w, --ignore-all-space
          比较行时忽略空白。

  -b, --ignore-space-change
          比较行时忽略空白数量变化；与 --ignore-all-space 互斥。

  -T, --template <TEMPLATE>
          每个文件差异的模板，类型 TreeDiffEntry。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  --revision <REVSETS>
          --revisions 的隐藏长别名；本命令的公开拼写是复数 --revisions。
```

**注意：** 比较 merge 提交时，-r 的基线是父提交自动合并后的内容。此命令另外支持 -w = --ignore-all-space、-b = --ignore-space-change。 -r 与 --from/--to 互斥；--template 与内置差异格式及 --tool 互斥。

源码：[cli/src/commands/diff.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/diff.rs)。


<a id="cmd-diffedit"></a>
### `jj diffedit`

类别：公开

```text
在差异编辑器中修改某个修订的内容。

Usage: jj diffedit [OPTIONS] [FILESETS]...

Arguments:
  [FILESETS]...
          可编辑路径；未匹配路径不变。

Options:
  -r, --revision <REVSET>
          待修改修订；不指定 --from/--to 时默认 @。

  -f, --from <REVSET>
          左侧比较基线；只给 --to 时默认 @。

  -t, --to <REVSET>
          右侧待修改修订；只给 --from 时默认 @。

  --tool <NAME>
          指定差异编辑器。

  --restore-descendants
          保持后代最终内容，而不是在新父提交上重放后代差异。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 编辑右侧内容。默认后代会随重写而变基，可能冲突。-r 与 --from/--to 是两种选择方式，不要混用。

源码：[cli/src/commands/diffedit.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/diffedit.rs)。


<a id="cmd-duplicate"></a>
### `jj duplicate`

类别：公开

```text
复制修订为新的 change，保留原修订。

Usage: jj duplicate [OPTIONS] [REVSETS]...

Arguments:
  [REVSETS]...
          要复制的修订；默认 @；支持 -r。

Options:
  -o, --onto <REVSETS>
          目标父修订，可重复以形成多父提交；可见长别名 --destination。 可见短别名 -d；源码未标记弃
          用。

  -A, --insert-after <REVSETS>
          插到这些修订之后，并重接其孩子；可重复；别名 --after。

  -B, --insert-before <REVSETS>
          插到这些修订之前，并重接它们；可重复；别名 --before。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  -r <REVSETS>
          位置修订参数的隐藏短选项形式；不能据此使用 --revision。
```

**注意：** 不指定位置时复制到原父提交或新复制的父提交上。复制产生新 change ID；与 rebase 移动原 change 不同。--onto 不能与插入选项同用；--insert-after 与 --insert-before 可以组合界定位置。

源码：[cli/src/commands/duplicate.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/duplicate.rs)。


<a id="cmd-edit"></a>
### `jj edit`

类别：公开

```text
直接把已有修订设为当前工作副本修订。

Usage: jj edit <REVSET|-r <REVSET>>

Arguments:
  <REVSET>
          要编辑的单个修订，必填；支持 -r。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 接下来写文件就是改写该 change；其后代通常跟随变基。增量修复常可用 new + squash，避免直接改历史。

源码：[cli/src/commands/edit.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/edit.rs)。


<a id="cmd-evolog"></a>
### `jj evolog`

类别：公开 · 别名：`evolution-log`, `obslog（隐藏兼容别名）`

```text
查看同一个 change 随修改、变基而产生的历史版本。

Usage: jj evolog [OPTIONS]

Options:
  -r, --revisions <REVSETS>
          追踪这些修订的演化；默认 @。

  -n, --limit <LIMIT>
          限制条数：拓扑排序之后、反转之前应用。

  --reversed
          反向展示，较旧版本在前。

  -G, --no-graph
          输出列表而非关系图。

  -T, --template <TEMPLATE>
          模板类型 CommitEvolutionEntry；默认 templates.evolog。

  -p, --patch
          显示相对上一版本的修改；临时对齐父提交，避免无关基线变化污染差异。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。

Diff Formatting Options:
  -s, --summary
          每条路径仅显示新增、修改、删除等状态。

  --stat
          显示变更行数统计和直方图。

  --types
          显示变更前后对象类型：- 不存在，F 普通文件，L 符号链接，C 冲突，G Git 子模块。

  --name-only
          只输出路径；路径可能包含空格，不宜直接接不处理转义的 xargs。

  --git
          使用 Git patch 格式。

  --color-words
          使用主要依靠颜色标记变化的词级差异格式。

  --tool <TOOL>
          使用外部差异显示工具；也可用 :git、:summary、:stat、:types、:name-only、:color-words 选
          择内置格式。不是交互式修改文件。

  --context <CONTEXT>
          指定显示多少行上下文。

  --ignore-all-space
          比较行时忽略空白。

  --ignore-space-change
          比较行时忽略空白数量变化；与 --ignore-all-space 互斥。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  --revision <REVSETS>
          --revisions 的隐藏长别名；本命令的公开拼写是复数 --revisions。
```

源码：[cli/src/commands/evolog.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/evolog.rs)。


<a id="cmd-file"></a>
### `jj file`

类别：公开

```text
针对受版本控制文件的读取、搜索和跟踪操作。

Usage: jj file <COMMAND>

Commands:
  annotate
          逐行显示目标文件内容来自哪个 change。

  chmod
          设置或移除仓库中文件的可执行位。

  list
          列出修订中的文件。

  search
          在指定修订的文件中按行搜索内容。

  show
          输出修订中文件的内容。

  track
          让指定路径开始被当前工作副本跟踪。

  untrack
          停止跟踪指定路径，但保留磁盘文件。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/file/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/file/mod.rs)。


<a id="cmd-file-annotate"></a>
### `jj file annotate`

类别：公开

```text
逐行显示目标文件内容来自哪个 change。

Usage: jj file annotate [OPTIONS] <PATH>

Arguments:
  <PATH>
          单个文件路径。

Options:
  -r, --revision <REVSET>
          追踪起点修订；省略时使用工作副本。

  -T, --template <TEMPLATE>
          逐行输出模板，类型 AnnotationLine；默认 templates.file_annotate。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/file/annotate.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/file/annotate.rs)。


<a id="cmd-file-chmod"></a>
### `jj file chmod`

类别：公开

```text
设置或移除仓库中文件的可执行位。

Usage: jj file chmod [OPTIONS] <MODE> <FILESETS>...

Arguments:
  <MODE>
          n（别名 normal）为不可执行；x（别名 executable）为可执行。不是 chmod 的 755 等模式。

  <FILESETS>...
          需要改变可执行位的路径。

Options:
  -r, --revision <REVSET>
          待修改修订；默认 @。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 可作用于任意可重写修订，也支持 Windows 和冲突文件。

源码：[cli/src/commands/file/chmod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/file/chmod.rs)。


<a id="cmd-file-list"></a>
### `jj file list`

类别：公开

```text
列出修订中的文件。

Usage: jj file list [OPTIONS] [FILESETS]...

Arguments:
  [FILESETS]...
          只列出匹配路径；省略时列出全部。

Options:
  -r, --revision <REVSET>
          修订；默认 @。

  -T, --template <TEMPLATE>
          文件条目模板，类型 TreeEntry；默认 templates.file_list。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/file/list.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/file/list.rs)。


<a id="cmd-file-search"></a>
### `jj file search`

类别：公开

```text
在指定修订的文件中按行搜索内容。

Usage: jj file search [OPTIONS] --pattern <PATTERN> [FILESETS]...

Arguments:
  [FILESETS]...
          只搜索匹配文件，省略时搜索全部。

Options:
  -r, --revision <REVSET>
          被搜索修订；默认 @。

  -p, --pattern <PATTERN>
          必填。字符串模式 kind:pattern；省略 kind 默认 regex。glob 要匹配整行，包含 foo 可写
          glob:*foo*。

  --name-only
          只输出包含匹配项的文件路径。

  -n, --line-number
          为匹配行增加从 1 开始的行号。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 这是版本内容搜索，不会自动搜索历史中的每一个修订。

源码：[cli/src/commands/file/search.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/file/search.rs)。


<a id="cmd-file-show"></a>
### `jj file show`

类别：公开

```text
输出修订中文件的内容。

Usage: jj file show [OPTIONS] <FILESETS>...

Arguments:
  <FILESETS>...
          要输出的路径，目录会递归遍历。

Options:
  -r, --revision <REVSET>
          内容来源修订；默认 @。

  -T, --template <TEMPLATE>
          文件元数据模板，类型 TreeEntry；默认 templates.file_show。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/file/show.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/file/show.rs)。


<a id="cmd-file-track"></a>
### `jj file track`

类别：公开

```text
让指定路径开始被当前工作副本跟踪。

Usage: jj file track [OPTIONS] <FILESETS>...

Arguments:
  <FILESETS>...
          要开始跟踪的路径。

Options:
  --include-ignored
          显式跟踪匹配路径，即使它们被 .gitignore 忽略或超过 snapshot.max-new-file-size。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** v0.45.1 源码的说明文字声称可省略路径，但实际 clap 声明 required=true。此手册按参数解析器要求写为必填；需要全部文件时使用 jj file track 'all()'。

源码：[cli/src/commands/file/track.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/file/track.rs)。


<a id="cmd-file-untrack"></a>
### `jj file untrack`

类别：公开

```text
停止跟踪指定路径，但保留磁盘文件。

Usage: jj file untrack <FILESETS>...

Arguments:
  <FILESETS>...
          要停止跟踪的路径；必须已经被忽略，否则会被再次自动跟踪。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 先设置 .gitignore 等忽略规则，再执行。不要将其与删除历史中敏感数据混淆。

源码：[cli/src/commands/file/untrack.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/file/untrack.rs)。


<a id="cmd-fix"></a>
### `jj fix`

类别：公开

```text
用已配置的文件转换器修复选定修订及其后代。

Usage: jj fix [OPTIONS] [FILESETS]...

Arguments:
  [FILESETS]...
          只处理这些路径。

Options:
  -s, --source <REVSETS>
          起始修订及其后代；默认 revsets.fix，内置为 reachable(@, mutable())。

  --include-unchanged-files
          也处理未修改文件；不限制路径时可处理整个仓库。

  -a, --all-lines
          处理整文件所有行，而非仅修改行；格式化器不支持行范围时无区别。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 先配置 fix.tools。转换器从标准输入读取内容并输出替代内容，应有确定性；相同路径/内容会去重执行。不是任意仓库级命令的通用运行器，那是 jj run。

源码：[cli/src/commands/fix.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/fix.rs)。


<a id="cmd-gerrit"></a>
### `jj gerrit`

类别：公开

```text
与 Gerrit 代码审查服务交互（需要 git 编译特性）。

Usage: jj gerrit <COMMAND>

Commands:
  upload
          把提交上传为 Gerrit change / patch set。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/gerrit/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/gerrit/mod.rs)。


<a id="cmd-gerrit-upload"></a>
### `jj gerrit upload`

类别：公开

```text
把提交上传为 Gerrit change / patch set。

Usage: jj gerrit upload [OPTIONS]

Options:
  -r, --revision <REVSETS>
          上传这些修订及其可变祖先；可重复。省略时：@ 有描述则选 @，否则选 @-。

  -b, --remote-branch <REMOTE_BRANCH>
          Gerrit 的目标分支；默认读取 gerrit.default-remote-branch。

  --remote <REMOTE>
          远端名称或完整 SSH URL；默认读取 gerrit.default-remote。

  -n, --dry-run
          只显示拟上传的内容，不执行上传。

  --reviewer <REVIEWER>
          请求此审查者；可重复，通常填写邮箱。

  --cc <CC>
          抄送此用户；可重复。

  -l, --label <LABEL>
          设置投票标签，可带分值（如 Code-Review+1）；无分值时为 +1，可重复；服务端可能忽略未知标
          签。

  --topic <TOPIC>
          设置 change 的 topic。

  --hashtag <HASHTAG>
          添加 hashtag；可重复。

  -m, --message <MESSAGE>
          设置新 patch set 的说明，不是修改提交描述。

  --edit
          把本次上传作为 change edit，而非立即发布新 patch set。

  --wip
          标记为 work in progress。

  --ready
          标记为准备好接受审查。

  --private
          设为 private change。

  --remove-private
          取消 private 标记。

  --publish-comments
          发布草稿评论。

  --no-publish-comments
          不发布草稿评论。

  --notify <NOTIFY>
          通知范围：none、owner、owner-reviewers、all；默认 all。

  --submit
          请求直接提交，需服务端允许且具备相应权限；这是高风险操作。

  --skip-validation
          跳过提交验证；必须同时指定 --submit，仍受服务端权限限制。

  --merged
          即使提交已合并，也请求创建 change。

  --ignore-attention-set
          不让此次上传自动调整 attention set。

  --deadline <DEADLINE>
          向 Gerrit 传递请求超时时限，值须符合服务端 deadline 语法。

  --custom <CUSTOM>
          设置 Gerrit 自定义键值参数；可重复。

  -o, --option <OPTION>
          附加 Git push option；可重复。

  --trace <TRACE>
          为服务端诊断启用带指定标识的 trace。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 这是 Gerrit 工作流，不是 GitHub PR 命令。部分参数互斥或受 Gerrit 版本/权限限制。上传时补加 Change-Id trailer 可能使远端提交 ID 与本地不同。

源码：[cli/src/commands/gerrit/upload.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/gerrit/upload.rs)。


<a id="cmd-git"></a>
### `jj git`

类别：公开

```text
Git 后端、远端和互操作命令（需要 git 编译特性）。

Usage: jj git <COMMAND>

Commands:
  clone
          克隆 Git 仓库并初始化 jj 工作区。

  colocation
          管理当前 jj 工作区与 Git 工作区的并置状态。

  export
          把 jj 的引用状态导出到 Git 后端。

  fetch
          获取远端 Git 引用与对象，并导入 jj。

  import
          把 Git 后端的引用变化导入 jj。

  init
          创建使用 Git 后端的 jj 仓库，或接管现有 Git 仓库。

  push
          把本地书签 / 标签更新推送到一个 Git 远端。

  remote
          管理 Git 远端配置。

  root
          输出 Git 后端目录路径。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/git/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/mod.rs)。


<a id="cmd-git-clone"></a>
### `jj git clone`

类别：公开

```text
克隆 Git 仓库并初始化 jj 工作区。

Usage: jj git clone [OPTIONS] <SOURCE> [DESTINATION]

Arguments:
  <SOURCE>
          Git URL 或本地仓库路径；本地路径会规范化为绝对路径。

  [DESTINATION]
          目标目录；默认从源地址末段推导。

Options:
  --remote <REMOTE_NAME>
          初始远端名称；默认 origin。

  --colocate
          使用并置布局：工作区中同时存在 .jj 和 .git；v0.45.1 默认开启，除非 git.colocate=false。

  --no-colocate
          把 Git 后端放在 .jj 中，不在工作区根目录暴露 .git。

  --depth <DEPTH>
          限制克隆历史深度；形成浅克隆。

  -b, --branch <BRANCH>
          只获取匹配分支；可重复。使用 Git 支持的有限 glob（支持 *，不等同完整 fileset/glob）。

  -t, --tag <TAG>
          只获取匹配标签；可重复，模式限制同 --branch。

  --object-hash <OBJECT_HASH>
          Git 对象哈希：sha1 或 sha256；必须与源仓库一致；默认由 git.object-hash 决定（内置 sha1）。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 默认获取远端分支，并以默认分支为工作副本父修订。指定分支过滤时，首个精确匹配分支可影响初始父修订。不要把 sha256 当作可对既有仓库随意切换的设置。

源码：[cli/src/commands/git/clone.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/clone.rs)。


<a id="cmd-git-colocation"></a>
### `jj git colocation`

类别：公开

```text
管理当前 jj 工作区与 Git 工作区的并置状态。

Usage: jj git colocation <COMMAND>

Commands:
  disable
          停用并置，把工作区根目录的 Git 元数据迁入 jj 管理的位置。

  enable
          启用并置，使 Git 工具能够在当前工作区识别 .git。

  status
          查看当前并置状态。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** v0.45.1 仅支持主工作区；额外 workspace 不支持 Git colocation。

源码：[cli/src/commands/git/colocation.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/colocation.rs)。


<a id="cmd-git-colocation-disable"></a>
### `jj git colocation disable`

类别：公开

```text
停用并置，把工作区根目录的 Git 元数据迁入 jj 管理的位置。

Usage: jj git colocation disable

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** v0.45.1 仅支持主工作区；额外 workspace 不支持 Git colocation。

源码：[cli/src/commands/git/colocation.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/colocation.rs)。


<a id="cmd-git-colocation-enable"></a>
### `jj git colocation enable`

类别：公开

```text
启用并置，使 Git 工具能够在当前工作区识别 .git。

Usage: jj git colocation enable

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** v0.45.1 仅支持主工作区；额外 workspace 不支持 Git colocation。

源码：[cli/src/commands/git/colocation.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/colocation.rs)。


<a id="cmd-git-colocation-status"></a>
### `jj git colocation status`

类别：公开

```text
查看当前并置状态。

Usage: jj git colocation status

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** v0.45.1 仅支持主工作区；额外 workspace 不支持 Git colocation。

源码：[cli/src/commands/git/colocation.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/colocation.rs)。


<a id="cmd-git-export"></a>
### `jj git export`

类别：公开

```text
把 jj 的引用状态导出到 Git 后端。

Usage: jj git export

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 并置仓库通常会自动导出；这是同步本地 Git 引用，不是推送到服务器。配合 --ignore-working-copy 可显式控制自动互操作。

源码：[cli/src/commands/git/export.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/export.rs)。


<a id="cmd-git-fetch"></a>
### `jj git fetch`

类别：公开

```text
获取远端 Git 引用与对象，并导入 jj。

Usage: jj git fetch [OPTIONS]

Options:
  -b, --branch <BRANCH>
          要获取的分支模式；可重复；有限 Git glob，不等于完整 revset。

  -t, --tag <TAG>
          要获取的标签模式；可重复。

  --tracked
          只获取已经跟踪的书签和标签。

  --remote <REMOTE>
          从匹配名称的远端获取；可重复；远端名默认支持 glob。

  --all-remotes
          从所有已配置远端获取。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 未指定远端时读取 git.fetch，或使用唯一远端 / origin。默认分支和标签筛选受 remotes.<name> 配置与 Git refspec 影响。fetch 不会自动把你的开发变更 rebase 到最新主干；引用失去可达性后是否 abandon 受 git.abandon-unreachable-commits 控制。

源码：[cli/src/commands/git/fetch.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/fetch.rs)。


<a id="cmd-git-import"></a>
### `jj git import`

类别：公开

```text
把 Git 后端的引用变化导入 jj。

Usage: jj git import

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 并置仓库通常自动导入；这不是网络 fetch。v0.45.1 中非并置仓库不会把 detached Git HEAD 自动当作工作副本导入。

源码：[cli/src/commands/git/import.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/import.rs)。


<a id="cmd-git-init"></a>
### `jj git init`

类别：公开

```text
创建使用 Git 后端的 jj 仓库，或接管现有 Git 仓库。

Usage: jj git init [OPTIONS] [DESTINATION]

Arguments:
  [DESTINATION]
          初始化目录；默认当前目录。

Options:
  --colocate
          创建并置仓库；内置默认 git.colocate=true。

  --no-colocate
          创建非并置仓库，Git 后端保存在 .jj 中。

  --object-hash <OBJECT_HASH>
          sha1 或 sha256；默认读取 git.object-hash（内置 sha1）。

  --git-repo <GIT_REPO>
          使用已存在的 Git 仓库作为后端；与显式 --colocate 冲突；同目录已有 Git 仓库会进入并置路径。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 已有 Git 项目常用 jj git init --colocate。v0.45.1 的实际默认值以参数定义和 misc.toml 为准，不能沿用旧教程中“默认不并置”的结论。

源码：[cli/src/commands/git/init.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/init.rs)。


<a id="cmd-git-push"></a>
### `jj git push`

类别：公开

```text
把本地书签 / 标签更新推送到一个 Git 远端。

Usage: jj git push [OPTIONS]

Options:
  --remote <REMOTE>
          推送目标远端名称；默认 git.push，或唯一远端 / origin。跟踪关系不等于自动决定推送远端。

  -b, --bookmark <BOOKMARK>
          推送匹配书签；可重复，名称默认 glob；新远端引用会建立跟踪。

  -t, --tag <TAG>
          推送匹配标签；可重复，新引用会建立跟踪。

  --all
          推送所有书签和标签，包括新建引用；谨慎使用。

  --tracked
          推送已跟踪的书签和标签。

  --deleted
          只推送已跟踪引用的删除。

  --allow-empty-description
          允许推送描述为空的提交。

  --allow-private
          允许推送匹配 git.private-commits 的提交；默认 private revset 为 none()。

  --allow-conflicts
          允许把冲突提交推送出去；接收端未必能按期望处理。

  -r, --revision <REVSETS>
          推送指向指定修订的引用；可重复；不是凭空为每个修订建立分支。

  -c, --change <REVSETS>
          为指定 change 创建 / 更新自动命名书签并推送；可重复。名称受 templates.git_push_bookmark
          控制。

  --named <NAME=REVISION>
          创建 / 更新明确命名的书签并推送；可重复。

  --dry-run
          显示计划，不实际推送。不要误记为全局选项，也不要假定所有命令都支持它。

  -o, --option <OPTION>
          向 Git 服务端传递 push option；可重复。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  --revisions <REVSETS>
          --revision 的隐藏长别名；不应据此推断所有命令都接受这两个拼写。

  --branch <BOOKMARK>
          --bookmark 的隐藏兼容长别名。
```

**注意：** 默认只选择当前工作相关的已跟踪引用，并不推送所有本地 change。jj 使用预期远端状态检查来保护历史重写，不能照搬 git push --force；先 fetch 再检查差异。--no-integrate-operation 不能替代这里的 --dry-run。 v0.45.1 的实现会直接拒绝全局 --no-integrate-operation。--all 与 --tracked 互斥；显式 -b/-t/-r/-c/--named 选择可互相组合，但不能与 --all、--tracked、--deleted 组合。--deleted 可与 --all 或 --tracked 配合。

源码：[cli/src/commands/git/push.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/push.rs)。


<a id="cmd-git-remote"></a>
### `jj git remote`

类别：公开

```text
管理 Git 远端配置。

Usage: jj git remote <COMMAND>

Commands:
  add
          添加一个命名远端。

  list
          列出已配置远端及地址。

  remove
          移除本地远端配置并忘记对应远端引用。

  rename
          重命名本地远端。

  set-url
          修改远端的获取 / 推送地址。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/git/remote/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/remote/mod.rs)。


<a id="cmd-git-remote-add"></a>
### `jj git remote add`

类别：公开

```text
添加一个命名远端。

Usage: jj git remote add [OPTIONS] <REMOTE> <URL>

Arguments:
  <REMOTE>
          远端名称。

  <URL>
          获取地址。

Options:
  --push-url <PUSH_URL>
          单独指定推送地址。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/git/remote/add.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/remote/add.rs)。


<a id="cmd-git-remote-list"></a>
### `jj git remote list`

类别：公开

```text
列出已配置远端及地址。

Usage: jj git remote list

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/git/remote/list.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/remote/list.rs)。


<a id="cmd-git-remote-remove"></a>
### `jj git remote remove`

类别：公开

```text
移除本地远端配置并忘记对应远端引用。

Usage: jj git remote remove <REMOTE>

Arguments:
  <REMOTE>
          要移除的远端名称。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 不会删除服务器仓库；与向服务器推送引用删除不是同一件事。

源码：[cli/src/commands/git/remote/remove.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/remote/remove.rs)。


<a id="cmd-git-remote-rename"></a>
### `jj git remote rename`

类别：公开

```text
重命名本地远端。

Usage: jj git remote rename <OLD> <NEW>

Arguments:
  <OLD>
          旧名称。

  <NEW>
          新名称。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/git/remote/rename.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/remote/rename.rs)。


<a id="cmd-git-remote-set-url"></a>
### `jj git remote set-url`

类别：公开

```text
修改远端的获取 / 推送地址。

Usage: jj git remote set-url [OPTIONS] <REMOTE> [URL]

Arguments:
  <REMOTE>
          远端名称。

  [URL]
          新的获取地址，是 --fetch 的便捷写法。

Options:
  --push <PUSH>
          设置推送 URL。

  --fetch <FETCH>
          设置获取 URL。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/git/remote/set_url.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/remote/set_url.rs)。


<a id="cmd-git-root"></a>
### `jj git root`

类别：公开

```text
输出 Git 后端目录路径。

Usage: jj git root

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 与 jj root / jj workspace root 不同：这里返回后端 Git 目录，而不是工作区根目录。

源码：[cli/src/commands/git/root.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/git/root.rs)。


<a id="cmd-help"></a>
### `jj help`

类别：公开

```text
显示指定命令路径的帮助，或打开关键字文档。

Usage: jj help [OPTIONS] [COMMAND]...

Arguments:
  [COMMAND]...
          子命令路径，例如 git push；完整写法 jj help git push。

Options:
  -k, --keyword <KEYWORD>
          文档主题：bookmarks、config、filesets、glossary、revsets、templates、tutorial。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** jj <命令> --help 是长帮助；-h 是短帮助。不要假定 jj git help push 也受支持。

源码：[cli/src/commands/help.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/help.rs)。


<a id="cmd-interdiff"></a>
### `jj interdiff`

类别：公开

```text
比较两个修订各自引入的修改，而非简单比较最终文件树。

Usage: jj interdiff [OPTIONS] <--from <REVSET>|--to <REVSET>> [FILESETS]...

Arguments:
  [FILESETS]...
          只比较匹配文件。

Options:
  -f, --from <REVSET>
          旧版本；若只指定 --to，此项默认 @。

  -t, --to <REVSET>
          新版本；若只指定 --from，此项默认 @。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。

Diff Formatting Options:
  -s, --summary
          每条路径仅显示新增、修改、删除等状态。

  --stat
          显示变更行数统计和直方图。

  --types
          显示变更前后对象类型：- 不存在，F 普通文件，L 符号链接，C 冲突，G Git 子模块。

  --name-only
          只输出路径；路径可能包含空格，不宜直接接不处理转义的 xargs。

  --git
          使用 Git patch 格式。

  --color-words
          使用主要依靠颜色标记变化的词级差异格式。

  --tool <TOOL>
          使用外部差异显示工具；也可用 :git、:summary、:stat、:types、:name-only、:color-words 选
          择内置格式。不是交互式修改文件。

  --context <CONTEXT>
          指定显示多少行上下文。

  -w, --ignore-all-space
          比较行时忽略空白。

  -b, --ignore-space-change
          比较行时忽略空白数量变化；与 --ignore-all-space 互斥。
```

全局参数见 [Global Options](#global-options)。

**注意：** 至少指定一个端点。会先对齐父修订再比较补丁，适合审查 rebase 前后的改动是否变化。

源码：[cli/src/commands/interdiff.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/interdiff.rs)。


<a id="cmd-log"></a>
### `jj log`

类别：公开

```text
显示提交图。

Usage: jj log [OPTIONS] [FILESETS]...

Arguments:
  [FILESETS]...
          按路径变化筛选历史。

Options:
  -r, --revision <REVSETS>
          要显示的修订集合；无路径筛选时默认读取 revsets.log。

  -n, --limit <LIMIT>
          最多显示多少个修订。

  --reversed
          反转显示顺序。

  -G, --no-graph
          不显示图形连线。

  -T, --template <TEMPLATE>
          提交输出模板，默认 templates.log。

  -p, --patch
          同时显示每个修订的补丁。

  --count
          输出匹配修订的数量。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。

Diff Formatting Options:
  -s, --summary
          每条路径仅显示新增、修改、删除等状态。

  --stat
          显示变更行数统计和直方图。

  --types
          显示变更前后对象类型：- 不存在，F 普通文件，L 符号链接，C 冲突，G Git 子模块。

  --name-only
          只输出路径；路径可能包含空格，不宜直接接不处理转义的 xargs。

  --git
          使用 Git patch 格式。

  --color-words
          使用主要依靠颜色标记变化的词级差异格式。

  --tool <TOOL>
          使用外部差异显示工具；也可用 :git、:summary、:stat、:types、:name-only、:color-words 选
          择内置格式。不是交互式修改文件。

  --context <CONTEXT>
          指定显示多少行上下文。

  --ignore-all-space
          比较行时忽略空白。

  --ignore-space-change
          比较行时忽略空白数量变化；与 --ignore-all-space 互斥。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  --revisions <REVSETS>
          --revision 的隐藏长别名；不应据此推断所有命令都接受这两个拼写。
```

**注意：** 仅给路径、未给 -r 时，会从 all() 中筛选修改这些路径的修订，而不是继续采用 revsets.log。--count 与图形/补丁/反转/模板及差异格式选项互斥。

源码：[cli/src/commands/log.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/log.rs)。


<a id="cmd-metaedit"></a>
### `jj metaedit`

类别：公开

```text
修改提交元数据，而不直接修改文件内容。

Usage: jj metaedit [OPTIONS] [REVSETS]...

Arguments:
  [REVSETS]...
          目标修订；默认 @；也接受隐藏短选项 -r。

Options:
  --update-change-id
          为修订重新分配 change ID。

  -m, --message <MESSAGE>
          设置提交描述。

  --update-author-timestamp
          把作者时间更新为当前时间。

  --update-author
          把作者姓名 / 邮箱更新为当前用户，保留作者时间。

  --author <AUTHOR>
          指定作者，格式 Name <email>。

  --author-timestamp <AUTHOR_TIMESTAMP>
          指定作者时间，接受 RFC 2822 或 RFC 3339。

  --force-rewrite
          即使元数据没有实质变化也重写提交，更新 committer 信息。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  -r <REVSETS>
          位置修订参数的隐藏短选项形式；不能据此使用 --revision。
```

**注意：** 重写元数据仍会改变 commit ID，并可能重写后代。作者信息和提交者信息不是一回事；提交者覆盖可使用对应 user 配置 / JJ_USER、JJ_EMAIL。 --author 与 --update-author 互斥；--author-timestamp 与 --update-author-timestamp 互斥。

源码：[cli/src/commands/metaedit.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/metaedit.rs)。


<a id="cmd-new"></a>
### `jj new`

类别：公开

```text
创建一个空 change，默认切换工作副本来编辑它。

Usage: jj new [OPTIONS] [REVSETS]...

Arguments:
  [REVSETS]...
          新修订的父集合；默认 @。多个父修订形成 merge；便捷短选项 -o、-r。

Options:
  -m, --message <MESSAGE>
          新 change 的描述；可重复，按段落连接。

  --no-edit
          创建新 change 但不切换工作副本。

  -A, --insert-after <REVSETS>
          插在指定修订之后，并重接其孩子；可重复；别名 --after。

  -B, --insert-before <REVSETS>
          插在指定修订之前；可重复；别名 --before。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  -o <REVSETS>；短别名 -r、-d
          与位置父修订参数合并使用；这是隐藏短选项，不等于存在 --onto / --revision / --destination
          长选项。

  --edit
          隐藏的无操作标志；用于与 --no-edit 配对，二者互斥。
```

**注意：** 位置父集合与 -A/-B 互斥；-A 和 -B 可组合。不带插入选项时，实验性的书签自动前进配置可能影响书签。

源码：[cli/src/commands/new.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/new.rs)。


<a id="cmd-next"></a>
### `jj next`

类别：公开

```text
沿 后继 方向移动工作位置。

Usage: jj next [OPTIONS] [OFFSET]

Arguments:
  [OFFSET]
          移动层数，默认 1；遇到多个候选可能需要交互选择。

Options:
  -e, --edit
          直接编辑目标修订。

  -n, --no-edit
          在目标修订上创建新的空 change。

  --conflict
          沿后继方向寻找冲突修订。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 默认行为受 ui.movement.edit 控制，内置为 false：不是无条件 checkout 目标，而是创建新工作 change。需要确定性切换时用 jj edit <revision>。

源码：[cli/src/commands/next.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/next.rs)。


<a id="cmd-operation"></a>
### `jj operation`

类别：公开 · 别名：`op`

```text
管理仓库操作历史，而不是提交图。

Usage: jj operation <COMMAND>

Commands:
  abandon
          丢弃一段操作历史。

  diff
          比较两次仓库操作的状态差异。

  integrate
          把先前未整合的操作并入当前操作头。

  log
          查看仓库操作日志。

  restore
          把仓库视图恢复到某次操作后的状态。

  revert
          在当前状态上反向应用指定操作的效果。

  show
          显示一项操作的元数据和差异。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/operation/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/mod.rs)。


<a id="cmd-operation-abandon"></a>
### `jj operation abandon`

类别：公开

```text
丢弃一段操作历史。

Usage: jj operation abandon <OPERATION>

Arguments:
  <OPERATION>
          操作 ID 或操作范围；例如 ..<ID> 丢弃该操作及更早祖先历史。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 高风险：缩短恢复历史，之后 GC 可能使对应对象永久不可恢复。这不是撤销操作，应优先使用 undo / op revert / op restore。

源码：[cli/src/commands/operation/abandon.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/abandon.rs)。


<a id="cmd-operation-diff"></a>
### `jj operation diff`

类别：公开

```text
比较两次仓库操作的状态差异。

Usage: jj operation diff [OPTIONS]

Options:
  --operation <OPERATION>
          比较该操作与其父操作；别名 --op。

  -f, --from <FROM>
          起点操作。

  -t, --to <TO>
          终点操作。

  -G, --no-graph
          不画操作差异中的提交图。

  -p, --patch
          显示经父修订对齐后的提交补丁差异。

  --show-changes-in <REVSETS>
          只显示这些修订的 change 差异；默认 revsets.op-diff-changes-in。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。

Diff Formatting Options:
  -s, --summary
          每条路径仅显示新增、修改、删除等状态。

  --stat
          显示变更行数统计和直方图。

  --types
          显示变更前后对象类型：- 不存在，F 普通文件，L 符号链接，C 冲突，G Git 子模块。

  --name-only
          只输出路径；路径可能包含空格，不宜直接接不处理转义的 xargs。

  --git
          使用 Git patch 格式。

  --color-words
          使用主要依靠颜色标记变化的词级差异格式。

  --tool <TOOL>
          使用外部差异显示工具；也可用 :git、:summary、:stat、:types、:name-only、:color-words 选
          择内置格式。不是交互式修改文件。

  --context <CONTEXT>
          指定显示多少行上下文。

  --ignore-all-space
          比较行时忽略空白。

  --ignore-space-change
          比较行时忽略空白数量变化；与 --ignore-all-space 互斥。
```

全局参数见 [Global Options](#global-options)。

**注意：** 比较的是操作前后仓库视图，不是 jj diff 的两个提交树。

源码：[cli/src/commands/operation/diff.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/diff.rs)。


<a id="cmd-operation-integrate"></a>
### `jj operation integrate`

类别：公开

```text
把先前未整合的操作并入当前操作头。

Usage: jj operation integrate <OPERATION>

Arguments:
  <OPERATION>
          待整合操作 ID；已整合时无需重复动作。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 常与 --no-integrate-operation 搭配；相当于把操作产生的仓库变化并回当前状态，不是 push。

源码：[cli/src/commands/operation/integrate.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/integrate.rs)。


<a id="cmd-operation-log"></a>
### `jj operation log`

类别：公开

```text
查看仓库操作日志。

Usage: jj operation log [OPTIONS]

Options:
  -n, --limit <LIMIT>
          最多显示的操作数量。

  --reversed
          反转显示顺序。

  -G, --no-graph
          不画操作图。

  -T, --template <TEMPLATE>
          操作输出模板。

  -d, --op-diff
          显示每个操作造成的仓库状态差异。

  -p, --patch
          显示提交补丁差异；隐含 --op-diff。

  --show-changes-in <REVSETS>
          只显示这些修订的 change 差异；默认 revsets.op-diff-changes-in。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。

Diff Formatting Options:
  -s, --summary
          每条路径仅显示新增、修改、删除等状态。

  --stat
          显示变更行数统计和直方图。

  --types
          显示变更前后对象类型：- 不存在，F 普通文件，L 符号链接，C 冲突，G Git 子模块。

  --name-only
          只输出路径；路径可能包含空格，不宜直接接不处理转义的 xargs。

  --git
          使用 Git patch 格式。

  --color-words
          使用主要依靠颜色标记变化的词级差异格式。

  --tool <TOOL>
          使用外部差异显示工具；也可用 :git、:summary、:stat、:types、:name-only、:color-words 选
          择内置格式。不是交互式修改文件。

  --context <CONTEXT>
          指定显示多少行上下文。

  --ignore-all-space
          比较行时忽略空白。

  --ignore-space-change
          比较行时忽略空白数量变化；与 --ignore-all-space 互斥。
```

全局参数见 [Global Options](#global-options)。

**注意：** 默认也可能先快照工作副本 / 调和并发操作。需要观察已有状态时可用 jj --at-op=@ --ignore-working-copy op log。

源码：[cli/src/commands/operation/log.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/log.rs)。


<a id="cmd-operation-restore"></a>
### `jj operation restore`

类别：公开

```text
把仓库视图恢复到某次操作后的状态。

Usage: jj operation restore [OPTIONS] <OPERATION>

Arguments:
  <OPERATION>
          目标操作 ID / 表达式。

Options:
  --what <WHAT>
          选择恢复部分，可重复：repo（仓库 / 本地引用）、remote-tracking（缓存的远端跟踪状态）；默
          认二者都恢复，属于实验性选项。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 会创建新的操作记录，不会替你撤回已执行的远端 push，也不会保证恢复任意外部文件。仅恢复 repo 可保留对远端当前状态的记忆。

源码：[cli/src/commands/operation/restore.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/restore.rs)。


<a id="cmd-operation-revert"></a>
### `jj operation revert`

类别：公开

```text
在当前状态上反向应用指定操作的效果。

Usage: jj operation revert [OPTIONS] [OPERATION]

Arguments:
  [OPERATION]
          要反向应用的操作；默认 @，即当前操作。

Options:
  --what <WHAT>
          选择恢复部分，可重复：repo（仓库 / 本地引用）、remote-tracking（缓存的远端跟踪状态）；默
          认二者都恢复，属于实验性选项。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 和 restore 不同：revert 试图保留其他后续操作的效果，类似对一次操作做反向补丁。

源码：[cli/src/commands/operation/revert.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/revert.rs)。


<a id="cmd-operation-show"></a>
### `jj operation show`

类别：公开

```text
显示一项操作的元数据和差异。

Usage: jj operation show [OPTIONS] [OPERATION]

Arguments:
  [OPERATION]
          操作 ID；默认 @。

Options:
  -G, --no-graph
          不画图。

  -T, --template <TEMPLATE>
          操作元数据模板。

  -p, --patch
          显示提交补丁差异。

  --no-op-diff
          不显示仓库状态差异。

  --show-changes-in <REVSETS>
          只显示这些修订的 change 差异；默认 revsets.op-diff-changes-in。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。

Diff Formatting Options:
  -s, --summary
          每条路径仅显示新增、修改、删除等状态。

  --stat
          显示变更行数统计和直方图。

  --types
          显示变更前后对象类型：- 不存在，F 普通文件，L 符号链接，C 冲突，G Git 子模块。

  --name-only
          只输出路径；路径可能包含空格，不宜直接接不处理转义的 xargs。

  --git
          使用 Git patch 格式。

  --color-words
          使用主要依靠颜色标记变化的词级差异格式。

  --tool <TOOL>
          使用外部差异显示工具；也可用 :git、:summary、:stat、:types、:name-only、:color-words 选
          择内置格式。不是交互式修改文件。

  --context <CONTEXT>
          指定显示多少行上下文。

  --ignore-all-space
          比较行时忽略空白。

  --ignore-space-change
          比较行时忽略空白数量变化；与 --ignore-all-space 互斥。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/operation/show.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/operation/show.rs)。


<a id="cmd-parallelize"></a>
### `jj parallelize`

类别：公开

```text
把指定修订整理为并行的兄弟变化。

Usage: jj parallelize [REVSETS]...

Arguments:
  [REVSETS]...
          要并行化的修订；也可用隐藏 -r。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 保留集合外所需的依赖关系；选择不连续修订时，可能无法移除中间依赖，结果可能无变化。

源码：[cli/src/commands/parallelize.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/parallelize.rs)。


<a id="cmd-prev"></a>
### `jj prev`

类别：公开

```text
沿 祖先 方向移动工作位置。

Usage: jj prev [OPTIONS] [OFFSET]

Arguments:
  [OFFSET]
          移动层数，默认 1；遇到多个候选可能需要交互选择。

Options:
  -e, --edit
          直接编辑目标修订。

  -n, --no-edit
          在目标修订上创建新的空 change。

  --conflict
          沿祖先方向寻找冲突修订。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 默认行为受 ui.movement.edit 控制，内置为 false：不是无条件 checkout 目标，而是创建新工作 change。需要确定性切换时用 jj edit <revision>。

源码：[cli/src/commands/prev.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/prev.rs)。


<a id="cmd-rebase"></a>
### `jj rebase`

类别：公开

```text
把指定 change 移到新的父修订 / 插入位置。

Usage: jj rebase [OPTIONS] <--onto <REVSETS>|--insert-after <REVSETS>|--insert-before <REVSETS>>

Options:
  -b, --branch <REVSETS>
          移动相对目标分叉出来的整条分支及后代；可重复；未指定 -b/-s/-r 时默认 -b @。

  -s, --source <REVSETS>
          移动指定修订及其所有后代；可重复；每个显式指定的修订都会成为目标的直接孩子。

  -r, --revision <REVSETS>
          只移动选中修订，未选中后代接回旧父位置；保留选中修订间的依赖关系。

  -o, --onto <REVSETS>
          目标父修订，可重复以形成多父提交；可见长别名 --destination。 可见短别名 -d；源码未标弃用。

  -A, --insert-after <REVSETS>
          插到这些修订之后，并重接其孩子；可重复；别名 --after。

  -B, --insert-before <REVSETS>
          插到这些修订之前，并重接它们；可重复；别名 --before。

  --skip-emptied
          重放后才变空的提交会被 abandon；原本就空的提交不删除；具有多个非空父的 merge 不跳过。

  --keep-divergent
          保留 change ID 相同的分歧版本；默认遇到目标侧已有相同改动版本时可能消除重复分歧。

  --simplify-parents
          同时移除冗余父边；效果类似 simplify-parents。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  --revisions <REVSETS>
          --revision 的隐藏长别名。
```

**注意：** -b/-s/-r 选择方式互斥。-o 与插入方式互斥；-A/-B 可组合。-d 是当前源码公开保留的短别名，并非已弃用；本手册示例统一写 -o。

源码：[cli/src/commands/rebase.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/rebase.rs)。


<a id="cmd-redo"></a>
### `jj redo`

类别：公开

```text
重做最近被 undo 撤销的操作。

Usage: jj redo

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 与连续 undo 配合，按撤销 / 重做历史前后移动；恢复指定操作仍使用 op restore。

源码：[cli/src/commands/redo.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/redo.rs)。


<a id="cmd-resolve"></a>
### `jj resolve`

类别：公开

```text
使用外部三方合并工具处理冲突文件。

Usage: jj resolve [OPTIONS] [FILESETS]...

Arguments:
  [FILESETS]...
          只处理匹配路径；省略表示所有可处理冲突。

Options:
  -r, --revision <REVSET>
          要处理的修订；默认 @。

  -l, --list
          只列出冲突，不启动工具。

  --tool <NAME>
          选择三方合并工具；内置 :ours / :theirs 分别采用冲突第 1 / 第 2 侧。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 只支持能表示为三方合并的冲突；也可以直接编辑文件中的冲突标记后运行 jj status，让 jj 快照结果。多父合并中的 ours/theirs 不能简单套用某个远端名。

源码：[cli/src/commands/resolve.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/resolve.rs)。


<a id="cmd-restore"></a>
### `jj restore`

类别：公开

```text
把目标修订中的路径内容恢复为来源修订的内容。

Usage: jj restore [OPTIONS] [FILESETS]...

Arguments:
  [FILESETS]...
          只恢复匹配路径；省略会作用于所有路径。

Options:
  -f, --from <REVSET>
          来源修订；只给 --into 时默认 @。

  -t, --into <REVSET>
          要重写的目标修订；只给 --from 时默认 @；别名 --to。

  -c, --changes-in <REVSET>
          撤销该修订相对合并父树的改动；不能简单把 merge 的父树理解成某一个父。

  -i, --interactive
          交互选择需要恢复的部分。

  --tool <NAME>
          指定 diff editor；隐含 --interactive。

  --restore-descendants
          重写后代时保留其文件树内容，而非继续重放原来的 diff。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  -r, --revision <REVISION>
          【仅用于报错提示，不是可用功能】解析后会主动返回错误，提示改用 --from 或 --changes-in。
          不要把它当成普通 revision 参数。
```

**注意：** 无端点参数时等价于 --changes-in @：恢复到父树，保留该 change 的描述等元数据。会覆盖工作修改；先检查 diff / 操作日志。 --changes-in 与 --from/--into 互斥；此命令没有正常可用的 -r 模式，隐藏 -r 只是迁移报错入口。

源码：[cli/src/commands/restore.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/restore.rs)。


<a id="cmd-revert"></a>
### `jj revert`

类别：公开

```text
在指定位置新建反向修改，用来撤销既有提交的效果。

Usage: jj revert --revision <REVSETS> <--onto <REVSETS>|--insert-after <REVSETS>|--insert-before <REVSETS>>

Options:
  -r, --revision <REVSETS>
          需要逆向应用的修订集合；必填。

  -o, --onto <REVSETS>
          目标父修订，可重复以形成多父提交；可见长别名 --destination。 可见短别名 -d；源码未标记弃
          用。

  -A, --insert-after <REVSETS>
          插到这些修订之后，并重接其孩子；可重复；别名 --after。

  -B, --insert-before <REVSETS>
          插到这些修订之前，并重接它们；可重复；别名 --before。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  --revisions <REVSETS>
          --revision 的隐藏长别名；不应据此推断所有命令都接受这两个拼写。
```

**注意：** 按逆拓扑顺序应用反向修改。不会删除原提交，适合对已经发布的提交做可审查的回退；描述模板为 templates.revert_description。

源码：[cli/src/commands/revert.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/revert.rs)。


<a id="cmd-root"></a>
### `jj root`

类别：公开

```text
输出当前工作区根目录，是 jj workspace root 的快捷入口。

Usage: jj root

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/root.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/root.rs)。


<a id="cmd-run"></a>
### `jj run`

类别：公开

```text
在隔离工作副本中跨多个修订执行外部命令，默认把执行产生的修改写回修订。

Usage: jj run [OPTIONS] <COMMAND> [ARGS]...

Arguments:
  <COMMAND>
          外部可执行程序。

  [ARGS]...
          传给外部程序的参数；用 -- 分隔 jj 参数与程序参数。

Options:
  -r, --revision <REVSETS>
          要处理的修订集合，可重复；省略时使用 revsets.run，内置为 reachable(@, mutable())。

  -j, --jobs <JOBS>
          并发进程数；覆盖 run.jobs，未配置时为 1。

  --root
          从每个隔离工作副本的根目录执行，而非调用 jj run 时对应的子目录。

  --clean
          执行前删除并重建隔离工作副本；默认会复用，以保留构建产物。

  --restore-descendants
          提交修改后，保持后代内容不变，而非重放后代补丁。

  --passthrough
          标准输出 / 错误直接连接终端；仅允许单任务，不继承标准输入。

  --ignore-changes
          丢弃程序产生的文件修改，不重写提交；只读测试通常应带上；允许检查 immutable 提交。

  --ignore-errors
          失败时继续其他修订；失败任务修改不保存，成功任务最终原子应用；外部失败不决定 jj run 的最
          终退出码。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  --revisions <REVSETS>
          --revision 的隐藏长别名；不应据此推断所有命令都接受这两个拼写。

  -x
          隐藏的无操作兼容标志；便于从 git rebase -x 迁移，不用于传递命令。
```

**注意：** 设置 JJ_CHANGE_ID、JJ_COMMIT_ID、JJ_WORKSPACE_ROOT。隔离工作副本不是安全沙箱：外部命令仍可能联网或修改目录外资源。自动化测试慎用 --ignore-errors，以免把失败当成功。 --ignore-changes 与 --restore-descendants 互斥；--passthrough 在 jobs > 1 时会报错。

源码：[cli/src/commands/run.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/run.rs)。


<a id="cmd-show"></a>
### `jj show`

类别：公开

```text
显示修订的元数据和相对父树的补丁。

Usage: jj show [OPTIONS] [REVSETS]...

Arguments:
  [REVSETS]...
          要查看的修订；默认 @；也可用隐藏 -r。

Options:
  --reversed
          较早修订优先。

  -T, --template <TEMPLATE>
          元数据模板。

  --no-patch
          不显示补丁。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。

Diff Formatting Options:
  -s, --summary
          每条路径仅显示新增、修改、删除等状态。

  --stat
          显示变更行数统计和直方图。

  --types
          显示变更前后对象类型：- 不存在，F 普通文件，L 符号链接，C 冲突，G Git 子模块。

  --name-only
          只输出路径；路径可能包含空格，不宜直接接不处理转义的 xargs。

  --git
          使用 Git patch 格式。

  --color-words
          使用主要依靠颜色标记变化的词级差异格式。

  --tool <TOOL>
          使用外部差异显示工具；也可用 :git、:summary、:stat、:types、:name-only、:color-words 选
          择内置格式。不是交互式修改文件。

  --context <CONTEXT>
          指定显示多少行上下文。

  -w, --ignore-all-space
          比较行时忽略空白。

  -b, --ignore-space-change
          比较行时忽略空白数量变化；与 --ignore-all-space 互斥。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  -r <REVISION>
          位置修订参数的隐藏短选项形式；不能据此使用 --revision。
```

**注意：** 本命令还支持 -w = --ignore-all-space、-b = --ignore-space-change。

源码：[cli/src/commands/show.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/show.rs)。


<a id="cmd-sign"></a>
### `jj sign`

类别：公开

```text
为修订添加密码学签名。

Usage: jj sign [OPTIONS]

Options:
  -r, --revision <REVSETS>
          要签名的修订；默认 revsets.sign。

  --key <KEY>
          用于签名的密钥标识。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  --revisions <REVSETS>
          --revision 的隐藏长别名；不应据此推断所有命令都接受这两个拼写。
```

**注意：** 需配置 signing backend。即使已有签名，也会重新签名；硬件令牌可能再次要求交互。签名会重写提交对象。

源码：[cli/src/commands/sign.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/sign.rs)。


<a id="cmd-simplify-parents"></a>
### `jj simplify-parents`

类别：公开

```text
删除冗余父边，不改变修订的文件树。

Usage: jj simplify-parents [OPTIONS]

Options:
  -s, --source <REVSETS>
          处理指定修订及其所有后代；可重复。

  -r, --revision <REVSETS>
          仅处理指定修订；可重复。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 父节点 C 若也是另一个父节点 B 的祖先，则可以移除直接的 C 父边。未给选择器时读取 revsets.simplify-parents，默认 reachable(@, mutable())。

源码：[cli/src/commands/simplify_parents.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/simplify_parents.rs)。


<a id="cmd-sparse"></a>
### `jj sparse`

类别：公开

```text
管理工作副本中实际展开的路径；不删除提交中其他文件。

Usage: jj sparse <COMMAND>

Commands:
  edit
          启动编辑器修改稀疏路径模式。

  list
          列出当前稀疏模式；. 表示整个仓库。

  reset
          恢复为在工作副本展开所有路径。

  set
          增删当前工作副本的稀疏路径模式。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/sparse/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/sparse/mod.rs)。


<a id="cmd-sparse-edit"></a>
### `jj sparse edit`

类别：公开

```text
启动编辑器修改稀疏路径模式。

Usage: jj sparse edit

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/sparse/edit.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/sparse/edit.rs)。


<a id="cmd-sparse-list"></a>
### `jj sparse list`

类别：公开

```text
列出当前稀疏模式；. 表示整个仓库。

Usage: jj sparse list

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/sparse/list.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/sparse/list.rs)。


<a id="cmd-sparse-reset"></a>
### `jj sparse reset`

类别：公开

```text
恢复为在工作副本展开所有路径。

Usage: jj sparse reset

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/sparse/reset.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/sparse/reset.rs)。


<a id="cmd-sparse-set"></a>
### `jj sparse set`

类别：公开

```text
增删当前工作副本的稀疏路径模式。

Usage: jj sparse set [OPTIONS]

Options:
  --add <ADD>
          加入路径模式；可重复。

  --remove <REMOVE>
          移除路径模式；可重复。

  --clear
          先清空模式；常与 --add 组合。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 例如 jj sparse set --clear --add README.md --add lib。不要与 .gitignore 或 snapshot.auto-track 混淆。

源码：[cli/src/commands/sparse/set.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/sparse/set.rs)。


<a id="cmd-split"></a>
### `jj split`

类别：公开

```text
把一个修订的修改拆为两部分。

Usage: jj split [OPTIONS] [FILESETS]...

Arguments:
  [FILESETS]...
          放入“选中部分”的文件集合；未指定文件集合时默认交互选择。

Options:
  -i, --interactive
          交互选择补丁片段。

  --tool <NAME>
          指定 diff editor；隐含交互。

  -r, --revision <REVSET>
          要拆分的修订；默认 @。

  -o, --onto <REVSETS>
          目标父修订，可重复以形成多父提交；可见长别名 --destination。 可见短别名 -d；源码未标记弃
          用。

  -A, --insert-after <REVSETS>
          插到这些修订之后，并重接其孩子；可重复；别名 --after。

  -B, --insert-before <REVSETS>
          插到这些修订之前，并重接它们；可重复；别名 --before。

  -m, --message <MESSAGE>
          为选中部分设置描述；另一部分保留原描述。

  --editor
          使用 --message 后仍启动描述编辑器。

  -p, --parallel
          拆成兄弟修订，而非父子修订。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 默认：选中部分保留在原 change，余下部分成为新孩子。使用 -o/-A/-B 时：选中部分提取为新位置的新 change，余下部分留原位。空提交不能 split。书签行为受 split.legacy-bookmark-behavior 影响（内置 true），拆分后务必检查书签。 --parallel 与 -o/-A/-B 互斥；-o 与 -A/-B 互斥，但 -A 和 -B 可组合。

源码：[cli/src/commands/split.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/split.rs)。


<a id="cmd-squash"></a>
### `jj squash`

类别：公开

```text
把来源修订的修改移动到目标修订。

Usage: jj squash [OPTIONS] [FILESETS]...

Arguments:
  [FILESETS]...
          只移动匹配文件的修改；省略则移动全部修改。

Options:
  -r, --revision <REVSET>
          把该修订压入它的单个父修订；默认 @；与实验性 -o/-A/-B 不兼容。

  -f, --from <REVSETS>
          来源集合；可重复。省略且使用显式目标时默认 @。

  -t, --into <REVSET>
          已有目标修订；默认 @；别名 --to。

  -o, --onto <REVSETS>
          【实验性】目标父修订，可重复以形成多父提交；可见长别名 --destination。 此模式创建新提交，
          不是修改一个既有目标。 可见短别名 -d；源码未标记弃用。

  -A, --insert-after <REVSETS>
          【实验性】插到这些修订之后，并重接其孩子；可重复；别名 --after。 此模式创建新提交，不是
          修改一个既有目标。

  -B, --insert-before <REVSETS>
          【实验性】插到这些修订之前，并重接它们；可重复；别名 --before。 此模式创建新提交，不是修
          改一个既有目标。

  -m, --message <MESSAGE>
          设置合并后的描述，不打开描述编辑器。

  -u, --use-destination-message
          保留目标描述，丢弃来源描述。

  --editor
          即使提供 --message 也打开描述编辑器。

  -i, --interactive
          交互选择补丁片段。

  --tool <NAME>
          指定 diff editor；隐含交互。

  -k, --keep-emptied
          来源被移空后也不 abandon。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 裸命令把 @ 的修改压入 @-；@ 是 merge 时需明确指定目标。来源变空通常会 abandon；如果工作 change 被 abandon，jj 会创建新的空工作 change。 -r 与 --from、--into 和位置选项互斥；--into 与 -o/-A/-B 互斥；-o 与 -A/-B 互斥；-A 和 -B 可组合。--use-destination-message 与 --message 互斥。

源码：[cli/src/commands/squash.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/squash.rs)。


<a id="cmd-status"></a>
### `jj status`

类别：公开 · 别名：`st（默认配置别名）`

```text
显示工作修改、工作修订及其父、文件冲突与书签冲突。

Usage: jj status [FILESETS]...

Arguments:
  [FILESETS]...
          限制文件状态展示范围。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 状态命令通常会先快照工作副本。没有 Git staging area，不存在配套的 jj add。

源码：[cli/src/commands/status.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/status.rs)。


<a id="cmd-tag"></a>
### `jj tag`

类别：公开

```text
管理本地和远端标签。

Usage: jj tag <COMMAND>

Commands:
  delete
          删除本地标签，不 abandon 标签指向的提交。 别名：d

  list
          显示标签与目标。 别名：l

  set
          创建或移动标签。 别名：s

  track
          开始跟踪远端标签。

  untrack
          停止跟踪远端标签。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/tag/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/tag/mod.rs)。


<a id="cmd-tag-delete"></a>
### `jj tag delete`

类别：公开 · 别名：`d`

```text
删除本地标签，不 abandon 标签指向的提交。

Usage: jj tag delete <NAMES>...

Arguments:
  <NAMES>...
          标签名模式，默认 glob。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/tag/delete.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/tag/delete.rs)。


<a id="cmd-tag-list"></a>
### `jj tag list`

类别：公开 · 别名：`l`

```text
显示标签与目标。

Usage: jj tag list [OPTIONS] [NAMES]...

Arguments:
  [NAMES]...
          标签名模式，默认 glob。

Options:
  -a, --all-remotes
          包括所有跟踪和未跟踪远端标签，也显示与本地同步的目标。

  --remote <REMOTE>
          按远端名称模式过滤，可重复；可与 --tracked、--conflicted 组合。

  -t, --tracked
          只列出已跟踪远端标签，默认不包括本地 Git-tracking 标签。

  -c, --conflicted
          只列出存在目标冲突的标签。

  -r, --revision <REVSETS>
          只列出本地目标落在所给修订集合中的标签，可重复。

  -T, --template <TEMPLATE>
          标签输出模板，类型 CommitRef；默认 templates.tag_list。

  --sort <SORT_KEY>
          排序键，可组合；末尾加 - 表示降序。键：name、author-name、author-email、author-date、
          committer-name、committer-email、committer-date，及各自的降序形式。默认
          ui.tag-list-sort-keys。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 默认省略未跟踪的远端标签及与本地同步的远端目标。冲突项用 - / + 表示旧 / 新目标。模板配置 templates.tag_list；排序配置 ui.tag-list-sort-keys。

源码：[cli/src/commands/tag/list.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/tag/list.rs)。


<a id="cmd-tag-set"></a>
### `jj tag set`

类别：公开 · 别名：`s`

```text
创建或移动标签。

Usage: jj tag set [OPTIONS] <NAMES>...

Arguments:
  <NAMES>...
          要设置的标签名称。

Options:
  -r, --revision <REVSET>
          目标修订；默认 @；别名 --to。

  --allow-move
          允许移动已经存在的标签。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 标签移动可能破坏使用者对发布版本的预期；默认不允许无提示移动。

源码：[cli/src/commands/tag/set.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/tag/set.rs)。


<a id="cmd-tag-track"></a>
### `jj tag track`

类别：公开

```text
开始跟踪远端标签。

Usage: jj tag track [OPTIONS] <TAG[@REMOTE]>...

Arguments:
  <TAG[@REMOTE]>...
          TAG 是名称模式（默认 glob）；TAG@REMOTE 精确指定一个远端标签。

Options:
  --remote <REMOTE>
          限定远端名称模式；可重复；未给则作用于匹配名称的所有远端标签。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 跟踪使之后获取的远端变化传播到同名本地标签；停止跟踪不删除服务器标签。

源码：[cli/src/commands/tag/track.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/tag/track.rs)。


<a id="cmd-tag-untrack"></a>
### `jj tag untrack`

类别：公开

```text
停止跟踪远端标签。

Usage: jj tag untrack [OPTIONS] <TAG[@REMOTE]>...

Arguments:
  <TAG[@REMOTE]>...
          TAG 是名称模式（默认 glob）；TAG@REMOTE 精确指定一个远端标签。

Options:
  --remote <REMOTE>
          限定远端名称模式；可重复；未给则作用于匹配名称的所有远端标签。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 跟踪使之后获取的远端变化传播到同名本地标签；停止跟踪不删除服务器标签。

源码：[cli/src/commands/tag/untrack.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/tag/untrack.rs)。


<a id="cmd-undo"></a>
### `jj undo`

类别：公开

```text
撤销最近一次操作；连续运行可继续向更早的状态回退。

Usage: jj undo

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 与 redo 配对。v0.45.1 的 undo 不接受一个操作 ID 作为位置参数；指定操作用 op restore / op revert。

源码：[cli/src/commands/undo.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/undo.rs)。


<a id="cmd-unsign"></a>
### `jj unsign`

类别：公开

```text
移除修订的密码学签名。

Usage: jj unsign [OPTIONS]

Options:
  -r, --revision <REVSETS>
          需要去除签名的修订集合。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**Hidden / Compatibility Options（源码补充，不是普通 help 可见项）**

```text
  --revisions <REVSETS>
          --revision 的隐藏长别名；不应据此推断所有命令都接受这两个拼写。
```

**注意：** 去签名也会重写提交对象；不是修改本地 GPG / SSH 密钥。 源码没有提供与 sign 相同的默认 revset；请明确使用 -r 指定目标，勿假设省略后等价于 @。

源码：[cli/src/commands/unsign.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/unsign.rs)。


<a id="cmd-util"></a>
### `jj util`

类别：公开

```text
生成补全、导出帮助、执行脚本及维护后端等低频命令。

Usage: jj util <COMMAND>

Commands:
  backend
          查询后端信息。

  completion
          向标准输出生成 shell 补全脚本。

  config-schema
          向标准输出打印 jj TOML 配置的 JSON Schema。

  exec
          在 jj 上下文中执行外部程序。

  gc
          执行后端垃圾回收。

  install-man-pages
          把手册页安装到给定目录。

  markdown-help
          向标准输出生成全部公开子命令的 Markdown 帮助。

  snapshot
          显式快照工作副本。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/util/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/util/mod.rs)。


<a id="cmd-util-backend"></a>
### `jj util backend`

类别：公开

```text
查询后端信息。

Usage: jj util backend <COMMAND>

Commands:
  name
          打印当前仓库使用的后端名称。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/util/backend/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/util/backend/mod.rs)。


<a id="cmd-util-backend-name"></a>
### `jj util backend name`

类别：公开

```text
打印当前仓库使用的后端名称。

Usage: jj util backend name

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/util/backend/name.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/util/backend/name.rs)。


<a id="cmd-util-completion"></a>
### `jj util completion`

类别：公开

```text
向标准输出生成 shell 补全脚本。

Usage: jj util completion <SHELL>

Arguments:
  <SHELL>
          bash、elvish、fish、nushell、power-shell、zsh。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 输出的是脚本，不会自动修改 shell 配置。PowerShell 的枚举拼写是 power-shell。

源码：[cli/src/commands/util/completion.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/util/completion.rs)。


<a id="cmd-util-config-schema"></a>
### `jj util config-schema`

类别：公开

```text
向标准输出打印 jj TOML 配置的 JSON Schema。

Usage: jj util config-schema

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/util/config_schema.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/util/config_schema.rs)。


<a id="cmd-util-exec"></a>
### `jj util exec`

类别：公开

```text
在 jj 上下文中执行外部程序。

Usage: jj util exec <COMMAND> [ARGS]...

Arguments:
  <COMMAND>
          外部可执行程序。

  [ARGS]...
          外部参数；建议用 -- 隔开。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 提供 JJ_WORKSPACE_ROOT，常用于自定义 alias；不是安全沙箱，任意脚本可能产生 jj undo 无法恢复的副作用。

源码：[cli/src/commands/util/exec.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/util/exec.rs)。


<a id="cmd-util-gc"></a>
### `jj util gc`

类别：公开

```text
执行后端垃圾回收。

Usage: jj util gc [OPTIONS]

Options:
  --expire <EXPIRE>
          过期阈值；v0.45.1 唯一可显式传入的值为 now。省略时保留最近两周的过时对象 / 操作。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 高风险：通常只有先 op abandon 才能回收旧操作引用的对象。op abandon 与 gc 组合会缩短甚至消除找回误操作的机会。

源码：[cli/src/commands/util/gc.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/util/gc.rs)。


<a id="cmd-util-install-man-pages"></a>
### `jj util install-man-pages`

类别：公开

```text
把手册页安装到给定目录。

Usage: jj util install-man-pages <PATH>

Arguments:
  <PATH>
          目标手册根目录，例如 /usr/share/man；程序会追加 man1 等目录。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 会写入指定路径，系统目录可能需要权限。

源码：[cli/src/commands/util/install_man_pages.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/util/install_man_pages.rs)。


<a id="cmd-util-markdown-help"></a>
### `jj util markdown-help`

类别：公开

```text
向标准输出生成全部公开子命令的 Markdown 帮助。

Usage: jj util markdown-help

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 它使用 clap-markdown，排版及收录范围不完全等于逐个 jj --help；隐藏命令仍需单独检查。

源码：[cli/src/commands/util/markdown_help.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/util/markdown_help.rs)。


<a id="cmd-util-snapshot"></a>
### `jj util snapshot`

类别：公开

```text
显式快照工作副本。

Usage: jj util snapshot

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 绝大部分常规命令会自动快照，因此主要用于脚本中隔离“外部文件改动”和“后续 jj 操作”的操作记录；本命令不输出 operation ID。

源码：[cli/src/commands/util/snapshot.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/util/snapshot.rs)。


<a id="cmd-version"></a>
### `jj version`

类别：公开

```text
显示 jj 版本与构建信息。

Usage: jj version

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/version.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/version.rs)。


<a id="cmd-workspace"></a>
### `jj workspace`

类别：公开

```text
管理共享同一仓库的多个工作副本。

Usage: jj workspace <COMMAND>

Commands:
  add
          创建额外工作区。

  forget
          不再跟踪指定工作区的工作 change。

  list
          列出仓库的工作区。

  rename
          重命名当前工作区。

  root
          输出工作区根目录。

  update-stale
          刷新因其他工作区 / 操作变化而过时的当前工作副本。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/workspace/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/workspace/mod.rs)。


<a id="cmd-workspace-add"></a>
### `jj workspace add`

类别：公开

```text
创建额外工作区。

Usage: jj workspace add [OPTIONS] <DESTINATION>

Arguments:
  <DESTINATION>
          新工作区目录。

Options:
  --name <NAME>
          工作区名称；默认目标目录 basename。

  -r, --revision <REVSETS>
          新工作 change 的父修订，可重复。省略时与当前工作 change 共享父修订，而不是默认以当前 @
          为父。

  -m, --message <MESSAGE>
          新工作 change 的描述。

  --sparse-patterns <SPARSE_PATTERNS>
          copy（默认，复制当前稀疏模式）、full（展开所有文件）、empty（不展开文件）。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 每个工作区有自己的 @ 和稀疏模式，共享提交与引用。v0.45.1 不收录 main 上尚未发布的 workspace add --colocate 新能力。

源码：[cli/src/commands/workspace/add.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/workspace/add.rs)。


<a id="cmd-workspace-forget"></a>
### `jj workspace forget`

类别：公开

```text
不再跟踪指定工作区的工作 change。

Usage: jj workspace forget [WORKSPACES]...

Arguments:
  [WORKSPACES]...
          工作区名称；省略时忘记当前工作区。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 不会删除磁盘目录；目录删除是另一个动作。

源码：[cli/src/commands/workspace/forget.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/workspace/forget.rs)。


<a id="cmd-workspace-list"></a>
### `jj workspace list`

类别：公开

```text
列出仓库的工作区。

Usage: jj workspace list [OPTIONS]

Options:
  -T, --template <TEMPLATE>
          WorkspaceRef 输出模板；默认 templates.workspace_list。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/workspace/list.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/workspace/list.rs)。


<a id="cmd-workspace-rename"></a>
### `jj workspace rename`

类别：公开

```text
重命名当前工作区。

Usage: jj workspace rename <NEW_WORKSPACE_NAME>

Arguments:
  <NEW_WORKSPACE_NAME>
          新的工作区名称。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 改的是工作区标识，不等同重命名磁盘目录。

源码：[cli/src/commands/workspace/rename.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/workspace/rename.rs)。


<a id="cmd-workspace-root"></a>
### `jj workspace root`

类别：公开

```text
输出工作区根目录。

Usage: jj workspace root [OPTIONS]

Options:
  --name <NAME>
          工作区名称；默认当前工作区。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/workspace/root.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/workspace/root.rs)。


<a id="cmd-workspace-update-stale"></a>
### `jj workspace update-stale`

类别：公开

```text
刷新因其他工作区 / 操作变化而过时的当前工作副本。

Usage: jj workspace update-stale

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 多工作区共享仓库，但工作区磁盘文件不是即时同步；先确认没有需要另行保留的编辑内容。

源码：[cli/src/commands/workspace/update_stale.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/workspace/update_stale.rs)。


## 隐藏 debug 命令


<a id="cmd-debug"></a>
### `jj debug`

类别：隐藏 / 开发者

```text
面向开发者的底层诊断工具；顶层 help 隐藏。

Usage: jj debug <COMMAND>

Commands:
  copy-detection
          显示修订相对其父中检测出的文件复制记录。

  fileset
          解析 fileset 并显示内部表达式与 matcher。

  index
          显示提交索引和 changed-path 索引统计。

  index-changed-paths
          构建 changed-path 索引。

  init-simple
          初始化概念验证用的 simple 后端仓库。

  local-working-copy
          显示本地磁盘工作副本的操作、树及逐文件缓存状态。

  object
          按底层对象 ID 读取存储对象。

  reindex
          重建提交索引。

  revset
          解析、优化并求值 revset，显示各阶段以及完整 commit ID。

  snapshot
          【已弃用】显式触发工作副本快照。

  stacked-table
          显示堆叠表的分层统计。

  template
          解析模板并打印语法树。

  tree
          递归列出 tree 的内部条目。

  watchman
          诊断 Watchman 文件监视集成。

  working-copy
          显示工作副本实现类型、操作和树；使用 no-snapshot helper。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/debug/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/mod.rs)。


<a id="cmd-debug-copy-detection"></a>
### `jj debug copy-detection`

类别：隐藏 / 开发者

```text
显示修订相对其父中检测出的文件复制记录。

Usage: jj debug copy-detection [REVSET]

Arguments:
  [REVSET]
          要检查的单个修订；默认 @。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。

源码：[cli/src/commands/debug/copy_detection.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/copy_detection.rs)。


<a id="cmd-debug-fileset"></a>
### `jj debug fileset`

类别：隐藏 / 开发者

```text
解析 fileset 并显示内部表达式与 matcher。

Usage: jj debug fileset <PATH>

Arguments:
  <PATH>
          fileset 表达式，不只是字面路径；建议加引号。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。

源码：[cli/src/commands/debug/fileset.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/fileset.rs)。


<a id="cmd-debug-index"></a>
### `jj debug index`

类别：隐藏 / 开发者

```text
显示提交索引和 changed-path 索引统计。

Usage: jj debug index

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。

源码：[cli/src/commands/debug/index.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/index.rs)。


<a id="cmd-debug-index-changed-paths"></a>
### `jj debug index-changed-paths`

类别：隐藏 / 开发者

```text
构建 changed-path 索引。

Usage: jj debug index-changed-paths [OPTIONS]

Options:
  -n, --limit <LIMIT>
          最多索引多少个修订；默认 u32::MAX，即 4294967295。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。会写索引，需要支持的默认索引后端。

源码：[cli/src/commands/debug/index_changed_paths.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/index_changed_paths.rs)。


<a id="cmd-debug-init-simple"></a>
### `jj debug init-simple`

类别：隐藏 / 开发者

```text
初始化概念验证用的 simple 后端仓库。

Usage: jj debug init-simple [DESTINATION]

Arguments:
  [DESTINATION]
          目标目录，默认 .。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。不支持 clone / fetch / push；不是日常 Git 项目的初始化方式。拒绝 --no-integrate-operation、--ignore-working-copy、--at-op。

源码：[cli/src/commands/debug/init_simple.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/init_simple.rs)。


<a id="cmd-debug-local-working-copy"></a>
### `jj debug local-working-copy`

类别：隐藏 / 开发者

```text
显示本地磁盘工作副本的操作、树及逐文件缓存状态。

Usage: jj debug local-working-copy

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。要求标准 local-disk working copy；加载 helper 时可能快照。

源码：[cli/src/commands/debug/local_working_copy.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/local_working_copy.rs)。


<a id="cmd-debug-object"></a>
### `jj debug object`

类别：隐藏 / 开发者

```text
按底层对象 ID 读取存储对象。

Usage: jj debug object <COMMAND>

Commands:
  commit
          打印提交对象内部结构。

  file
          输出文件对象内容。

  operation
          打印操作对象内部结构。

  symlink
          输出符号链接目标。

  tree
          打印指定目录的 tree 对象。

  view
          打印仓库 view 对象。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/debug/object.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/object.rs)。


<a id="cmd-debug-object-commit"></a>
### `jj debug object commit`

类别：隐藏 / 开发者

```text
打印提交对象内部结构。

Usage: jj debug object commit <ID>

Arguments:
  <ID>
          完整十六进制对象 ID；不是普通 revset 或可任意缩写的 change ID。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。

源码：[cli/src/commands/debug/object.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/object.rs)。


<a id="cmd-debug-object-file"></a>
### `jj debug object file`

类别：隐藏 / 开发者

```text
输出文件对象内容。

Usage: jj debug object file [OPTIONS] <PATH> [ID]

Arguments:
  <PATH>
          仓库内部路径；不是任意本机绝对路径。

  [ID]
          完整十六进制对象 ID；与 -r 二选一。

Options:
  -r, --revision <REVISION>
          从指定修订中按给定路径查找对象；与 ID 互斥。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。file/tree 在解析器中要求 ID 或 -r。symlink 的参数声明未标 required，但执行分支会读取其中之一；实际调用同样必须明确给出 ID 或 -r。

源码：[cli/src/commands/debug/object.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/object.rs)。


<a id="cmd-debug-object-operation"></a>
### `jj debug object operation`

类别：隐藏 / 开发者

```text
打印操作对象内部结构。

Usage: jj debug object operation <ID>

Arguments:
  <ID>
          完整十六进制对象 ID；不是普通 revset 或可任意缩写的 change ID。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。

源码：[cli/src/commands/debug/object.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/object.rs)。


<a id="cmd-debug-object-symlink"></a>
### `jj debug object symlink`

类别：隐藏 / 开发者

```text
输出符号链接目标。

Usage: jj debug object symlink [OPTIONS] <PATH> [ID]

Arguments:
  <PATH>
          仓库内部路径；不是任意本机绝对路径。

  [ID]
          完整十六进制对象 ID；与 -r 二选一。

Options:
  -r, --revision <REVISION>
          从指定修订中按给定路径查找对象；与 ID 互斥。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。file/tree 在解析器中要求 ID 或 -r。symlink 的参数声明未标 required，但执行分支会读取其中之一；实际调用同样必须明确给出 ID 或 -r。

源码：[cli/src/commands/debug/object.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/object.rs)。


<a id="cmd-debug-object-tree"></a>
### `jj debug object tree`

类别：隐藏 / 开发者

```text
打印指定目录的 tree 对象。

Usage: jj debug object tree [OPTIONS] <DIR> [ID]

Arguments:
  <DIR>
          仓库内部路径；不是任意本机绝对路径。

  [ID]
          完整十六进制对象 ID；与 -r 二选一。

Options:
  -r, --revision <REVISION>
          从指定修订中按给定路径查找对象；与 ID 互斥。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。file/tree 在解析器中要求 ID 或 -r。symlink 的参数声明未标 required，但执行分支会读取其中之一；实际调用同样必须明确给出 ID 或 -r。

源码：[cli/src/commands/debug/object.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/object.rs)。


<a id="cmd-debug-object-view"></a>
### `jj debug object view`

类别：隐藏 / 开发者

```text
打印仓库 view 对象。

Usage: jj debug object view [OPTIONS] [ID]

Arguments:
  [ID]
          完整十六进制 view ID；与 --op 二选一，必须提供其一。

Options:
  --op <OP>
          使用该操作引用的 view；这里接受操作表达式。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。

源码：[cli/src/commands/debug/object.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/object.rs)。


<a id="cmd-debug-reindex"></a>
### `jj debug reindex`

类别：隐藏 / 开发者

```text
重建提交索引。

Usage: jj debug reindex

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。会重新初始化并写入索引；遇到疑似损坏时先备份，不要当作常规整理命令。

源码：[cli/src/commands/debug/reindex.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/reindex.rs)。


<a id="cmd-debug-revset"></a>
### `jj debug revset`

类别：隐藏 / 开发者

```text
解析、优化并求值 revset，显示各阶段以及完整 commit ID。

Usage: jj debug revset [OPTIONS] <REVISION>

Arguments:
  <REVISION>
          revset 表达式。

Options:
  --no-resolve
          不解析符号、不求值；可只观察解析 / 优化结构。

  --no-optimize
          不改写为优化后的表达式。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。

源码：[cli/src/commands/debug/revset.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/revset.rs)。


<a id="cmd-debug-snapshot"></a>
### `jj debug snapshot`

类别：隐藏 / 开发者

```text
【已弃用】显式触发工作副本快照。

Usage: jj debug snapshot

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。v0.45.1 源码仍保留入口并发出弃用警告；替代命令为 jj util snapshot。

源码：[cli/src/commands/debug/snapshot.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/snapshot.rs)。


<a id="cmd-debug-stacked-table"></a>
### `jj debug stacked-table`

类别：隐藏 / 开发者

```text
显示堆叠表的分层统计。

Usage: jj debug stacked-table --key-size <KEY_SIZE> <DIR>

Arguments:
  <DIR>
          table store 目录。

Options:
  -n, --key-size <KEY_SIZE>
          键长度，单位字节；必填。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。

源码：[cli/src/commands/debug/stacked_table.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/stacked_table.rs)。


<a id="cmd-debug-template"></a>
### `jj debug template`

类别：隐藏 / 开发者

```text
解析模板并打印语法树。

Usage: jj debug template <TEMPLATE>

Arguments:
  <TEMPLATE>
          模板表达式；此命令是解析诊断，不是对提交执行模板渲染。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。

源码：[cli/src/commands/debug/template.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/template.rs)。


<a id="cmd-debug-tree"></a>
### `jj debug tree`

类别：隐藏 / 开发者

```text
递归列出 tree 的内部条目。

Usage: jj debug tree [OPTIONS] [FILESETS]...

Arguments:
  [FILESETS]...
          路径筛选。

Options:
  -r, --revision <REVSET>
          从该修订取树；默认 @；与 --id 互斥。

  --id <ID>
          直接指定完整十六进制 tree ID。

  --dir <DIR>
          指定该 tree 对应的目录；必须同时指定 --id；默认根目录。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。

源码：[cli/src/commands/debug/tree.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/tree.rs)。


<a id="cmd-debug-watchman"></a>
### `jj debug watchman`

类别：隐藏 / 开发者

```text
诊断 Watchman 文件监视集成。

Usage: jj debug watchman <COMMAND>

Commands:
  query-changed-files
          查询 Watchman 报告的变化文件。

  query-clock
          查询 Watchman 时钟。

  reset-clock
          清空保存的 Watchman 时钟状态。

  status
          检查配置、Watchman 安装及快照触发器。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/debug/watchman.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/watchman.rs)。


<a id="cmd-debug-watchman-query-changed-files"></a>
### `jj debug watchman query-changed-files`

类别：隐藏 / 开发者

```text
查询 Watchman 报告的变化文件。

Usage: jj debug watchman query-changed-files

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。命令枚举仍存在，但二进制未编译 watchman 特性时执行会报错；reset-clock 会修改工作副本状态。

源码：[cli/src/commands/debug/watchman.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/watchman.rs)。


<a id="cmd-debug-watchman-query-clock"></a>
### `jj debug watchman query-clock`

类别：隐藏 / 开发者

```text
查询 Watchman 时钟。

Usage: jj debug watchman query-clock

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。命令枚举仍存在，但二进制未编译 watchman 特性时执行会报错；reset-clock 会修改工作副本状态。

源码：[cli/src/commands/debug/watchman.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/watchman.rs)。


<a id="cmd-debug-watchman-reset-clock"></a>
### `jj debug watchman reset-clock`

类别：隐藏 / 开发者

```text
清空保存的 Watchman 时钟状态。

Usage: jj debug watchman reset-clock

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。命令枚举仍存在，但二进制未编译 watchman 特性时执行会报错；reset-clock 会修改工作副本状态。

源码：[cli/src/commands/debug/watchman.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/watchman.rs)。


<a id="cmd-debug-watchman-status"></a>
### `jj debug watchman status`

类别：隐藏 / 开发者

```text
检查配置、Watchman 安装及快照触发器。

Usage: jj debug watchman status

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。命令枚举仍存在，但二进制未编译 watchman 特性时执行会报错；reset-clock 会修改工作副本状态。

源码：[cli/src/commands/debug/watchman.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/watchman.rs)。


<a id="cmd-debug-working-copy"></a>
### `jj debug working-copy`

类别：隐藏 / 开发者

```text
显示工作副本实现类型、操作和树；使用 no-snapshot helper。

Usage: jj debug working-copy

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 开发者诊断接口，输出不保证稳定，不建议作为生产脚本协议。

源码：[cli/src/commands/debug/working_copy.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/debug/working_copy.rs)。


## bench：需要编译 feature 的隐藏命令


<a id="cmd-bench"></a>
### `jj bench`

类别：条件编译 / 基准测试

```text
内部基准测试；隐藏命令，且必须编译 bench 特性。

Usage: jj bench <COMMAND>

Commands:
  common-ancestors
          测试查找两个提交共同祖先的性能。

  is-ancestor
          测试祖先关系判断的性能。

  resolve-prefix
          测试 commit ID 前缀解析的性能。

  revset
          测试 revset 遍历 / 求值性能。

Options:
  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

源码：[cli/src/commands/bench/mod.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bench/mod.rs)。


<a id="cmd-bench-common-ancestors"></a>
### `jj bench common-ancestors`

类别：条件编译 / 基准测试

```text
测试查找两个提交共同祖先的性能。

Usage: jj bench common-ancestors [OPTIONS] <REVISION1> <REVISION2>

Arguments:
  <REVISION1>
          第一个修订。

  <REVISION2>
          第二个修订。

Options:
  -s, --save-baseline <SAVE_BASELINE>
          把结果保存到该基线名；默认 base；与 --baseline 互斥。

  -b, --baseline <BASELINE>
          与已保存的基线比较；与 --save-baseline 互斥。

  --sample-size <SAMPLE_SIZE>
          采样次数；默认 100，最小 10。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 必须使用启用 bench 特性的构建；常规发布二进制不应假定提供此命令。

源码：[cli/src/commands/bench/common_ancestors.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bench/common_ancestors.rs)。


<a id="cmd-bench-is-ancestor"></a>
### `jj bench is-ancestor`

类别：条件编译 / 基准测试

```text
测试祖先关系判断的性能。

Usage: jj bench is-ancestor [OPTIONS] <ANCESTOR> <DESCENDANT>

Arguments:
  <ANCESTOR>
          候选祖先修订。

  <DESCENDANT>
          候选后代修订。

Options:
  -s, --save-baseline <SAVE_BASELINE>
          把结果保存到该基线名；默认 base；与 --baseline 互斥。

  -b, --baseline <BASELINE>
          与已保存的基线比较；与 --save-baseline 互斥。

  --sample-size <SAMPLE_SIZE>
          采样次数；默认 100，最小 10。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 必须使用启用 bench 特性的构建；常规发布二进制不应假定提供此命令。

源码：[cli/src/commands/bench/is_ancestor.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bench/is_ancestor.rs)。


<a id="cmd-bench-resolve-prefix"></a>
### `jj bench resolve-prefix`

类别：条件编译 / 基准测试

```text
测试 commit ID 前缀解析的性能。

Usage: jj bench resolve-prefix [OPTIONS] <PREFIX>

Arguments:
  <PREFIX>
          十六进制 commit ID 前缀，不是 change ID。

Options:
  -s, --save-baseline <SAVE_BASELINE>
          把结果保存到该基线名；默认 base；与 --baseline 互斥。

  -b, --baseline <BASELINE>
          与已保存的基线比较；与 --save-baseline 互斥。

  --sample-size <SAMPLE_SIZE>
          采样次数；默认 100，最小 10。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 必须使用启用 bench 特性的构建；常规发布二进制不应假定提供此命令。

源码：[cli/src/commands/bench/resolve_prefix.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bench/resolve_prefix.rs)。


<a id="cmd-bench-revset"></a>
### `jj bench revset`

类别：条件编译 / 基准测试

```text
测试 revset 遍历 / 求值性能。

Usage: jj bench revset [OPTIONS] <REVISIONS|--file <FILE>>

Arguments:
  [REVISIONS]...
          一个或多个 revset；与 --file 二选一，必须提供一个来源。

Options:
  -f, --file <FILE>
          逐行读取 revset；忽略空行及以 # 开头的行。

  -s, --save-baseline <SAVE_BASELINE>
          把结果保存到该基线名；默认 base；与 --baseline 互斥。

  -b, --baseline <BASELINE>
          与已保存的基线比较；与 --save-baseline 互斥。

  --sample-size <SAMPLE_SIZE>
          采样次数；默认 100，最小 10。

  -h, --help
          显示帮助；-h 为短帮助，--help 为长帮助。
```

全局参数见 [Global Options](#global-options)。

**注意：** 需要 bench 特性；测试数据会影响性能统计，请勿直接用结果比较不同配置的环境。

源码：[cli/src/commands/bench/revset.rs](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commands/bench/revset.rs)。


## 内置默认值不等于你的有效配置

下表是该版本的内置值。用户、仓库、工作区和本次调用配置都可能改变有效结果。

| 配置键 | 内置值 | 解读 |
|---|---|---|
| `ui.default-command` | `log` | 裸 jj 的默认命令。 |
| `git.colocate` | `true` | Git 初始化/克隆的并置默认值，可被个人配置覆盖。 |
| `git.object-hash` | `sha1` | 不是对已有仓库任意切换哈希算法。 |
| `revsets.run` | `reachable(@, mutable())` | 不是固定的 @ 或所有仓库历史。 |
| `revsets.fix` | `reachable(@, mutable())` | fix 从所选起点继续处理后代。 |
| `revsets.sign` | `reachable(@, mutable())` | sign 默认范围与 unsign 不应混为一谈。 |
| `revsets.arrange` | `reachable(@, mutable())` | 交互重排的默认集合。 |
| `revsets.simplify-parents` | `reachable(@, mutable())` | 父边简化默认起点。 |
| `revsets.converge` | `mutable() & divergent()` | 默认处理可变分歧。 |
| `revsets.bookmark-advance-to` | `@` | advance 默认目标。 |
| `revsets.bookmark-advance-from` | `heads(::to & bookmarks())` | 未给名称时寻找最近书签；表达式可访问 to。 |
| `split.legacy-bookmark-behavior` | `true` | 默认拆分后的书签前进语义，拆分后检查。 |

通过下面的命令确认实际生效值，而不是只记住表格：

```sh
jj config get revsets.run
jj config get git.colocate
jj config list --include-defaults
jj config list --include-overridden
```

来源：[revsets.toml](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml) ·
[misc.toml](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/misc.toml)。

## 别名的三个层级

命令别名如 `operation → op` 来自命令枚举；`bookmark → b`、`describe → desc`、
`commit → ci`、`status → st` 是内置配置中的别名，用户配置可以覆盖。
第三类是参数兼容别名，例如 rebase 的 `--destination` 与 `-d`。
别把“命令别名”“参数别名”“同名参数的不同语义”混成一类。

每节的 Hidden / Compatibility Options 只列已核实兼容项。
`restore -r` 属于专门返回错误的入口，`run -x` 属于无操作兼容项，
它们虽然能出现在解析定义里，却不能当作普通功能宣传。

## 安全边界

历史重写前先确认选中范围；发布前检查书签与 push --dry-run；
恢复问题先看 op log，不要急于 op abandon 或 util gc。
任何 jj 撤销机制都不保证撤销网络请求、外部脚本副作用、未跟踪文件删除或泄露的凭据。
调试和基准测试命令不是稳定脚本 API；某些隐藏命令还会重建索引或改变工作副本状态。

工作流、源码差异和验证记录见同目录的 `workflows-zh.md` 与 `sources-and-coverage.md`。


---

# jj v0.45.1 Revset 中文完整参考

**固定版本：v0.45.1 · 查证日期：2026-09-17 · Revset 补充修订版**

## 导航

[可见、隐藏与搜索域](#revset-hidden) | [提交符号、工作区与 change offset](#revset-symbols) | [全部运算符与优先级](#revset-operators) | [函数签名、默认值与参数类型](#revset-function-syntax) | [字符串模式与逻辑组合](#revset-string-patterns) | [日期边界、时区与可复现查询](#revset-date-patterns) | [自定义符号、函数与模式别名](#revset-aliases) | [日志图形、引用后缀与状态标签](#revset-log-markers) | [旧教程迁移与上一版勘误](#revset-migration) | [20 个可组合的查询场景](#revset-recipes-intro) | [固定版本源码、覆盖口径与验证限制](#revset-sources)

### 函数索引

| 分类 | 函数 |
|---|---|
| 图遍历 | [`parents()`](#revset-fn-parents)、[`children()`](#revset-fn-children)、[`ancestors()`](#revset-fn-ancestors)、[`descendants()`](#revset-fn-descendants)、[`first_parent()`](#revset-fn-first_parent)、[`first_ancestors()`](#revset-fn-first_ancestors)、[`reachable()`](#revset-fn-reachable)、[`connected()`](#revset-fn-connected) |
| 集合与选择 | [`all()`](#revset-fn-all)、[`none()`](#revset-fn-none)、[`visible_heads()`](#revset-fn-visible_heads)、[`root()`](#revset-fn-root)、[`heads()`](#revset-fn-heads)、[`roots()`](#revset-fn-roots)、[`latest()`](#revset-fn-latest)、[`fork_point()`](#revset-fn-fork_point)、[`merge_point()`](#revset-fn-merge_point)、[`bisect()`](#revset-fn-bisect)、[`exactly()`](#revset-fn-exactly)、[`working_copies()`](#revset-fn-working_copies) |
| ID 与引用 | [`change_id()`](#revset-fn-change_id)、[`commit_id()`](#revset-fn-commit_id)、[`bookmarks()`](#revset-fn-bookmarks)、[`remote_bookmarks()`](#revset-fn-remote_bookmarks)、[`tracked_remote_bookmarks()`](#revset-fn-tracked_remote_bookmarks)、[`untracked_remote_bookmarks()`](#revset-fn-untracked_remote_bookmarks)、[`tags()`](#revset-fn-tags)、[`remote_tags()`](#revset-fn-remote_tags)、[`tracked_remote_tags()`](#revset-fn-tracked_remote_tags)、[`untracked_remote_tags()`](#revset-fn-untracked_remote_tags) |
| 结构与状态 | [`merges()`](#revset-fn-merges)、[`forks()`](#revset-fn-forks)、[`signed()`](#revset-fn-signed)、[`empty()`](#revset-fn-empty)、[`conflicts()`](#revset-fn-conflicts)、[`divergent()`](#revset-fn-divergent) |
| 元数据过滤 | [`description()`](#revset-fn-description)、[`subject()`](#revset-fn-subject)、[`author()`](#revset-fn-author)、[`author_name()`](#revset-fn-author_name)、[`author_email()`](#revset-fn-author_email)、[`author_date()`](#revset-fn-author_date)、[`mine()`](#revset-fn-mine)、[`committer()`](#revset-fn-committer)、[`committer_name()`](#revset-fn-committer_name)、[`committer_email()`](#revset-fn-committer_email)、[`committer_date()`](#revset-fn-committer_date) |
| 内容与路径 | [`files()`](#revset-fn-files)、[`diff_lines()`](#revset-fn-diff_lines)、[`diff_lines_added()`](#revset-fn-diff_lines_added)、[`diff_lines_removed()`](#revset-fn-diff_lines_removed) |
| 容错与历史 | [`present()`](#revset-fn-present)、[`coalesce()`](#revset-fn-coalesce)、[`at_operation()`](#revset-fn-at_operation) |
| 弃用兼容入口 | [`diff_contains()`](#revset-fn-diff_contains) |

### 默认别名索引

[`trunk()`](#revset-alias-trunk)、[`builtin_log()`](#revset-alias-builtin_log)、[`builtin_immutable_heads()`](#revset-alias-builtin_immutable_heads)、[`immutable_heads()`](#revset-alias-immutable_heads)、[`immutable()`](#revset-alias-immutable)、[`mutable()`](#revset-alias-mutable)、[`visible()`](#revset-alias-visible)、[`hidden()`](#revset-alias-hidden)

<a id="revset-intro"></a>

## Revsets / 阅读说明与类型边界

本补篇固定到 **jj v0.45.1**，查证日期 **2026-09-17**。保留官方参考的章节顺序、函数名、签名及语法拼写；解释改为中文，并加上源码校对、边界条件和实际场景。它是结构化中文参考，不是对 `jj help` 的逐字终端转录。

覆盖 **54 个官方文档函数 + 1 个仍注册的弃用兼容名 `diff_contains()` + 8 个默认 revset 别名**。函数与别名分开计数：`trunk()`、`mutable()` 不是 Rust 内置函数；`root()`、`ancestors()` 才是。本参考只覆盖上游默认实现，不包含自定义编译扩展或用户自定义别名。

| 所在位置 | 输入的是什么 | 例子 |
|---|---|---|
| `jj log -r '…'` | revset：提交集合表达式 | `mine() & mutable()` |
| `files(…)` 的实参 | fileset：路径集合表达式 | `root:"src" ~ root:"src/generated"` |
| `description(…)` 的实参 | 字符串模式 | `substring:"TODO"` |
| `author_date(…)` 的实参 | 日期模式 | `after:"2026-09-01"` |
| `at_operation(op, x)` 的第一个实参 | operation 选择表达式 | `@-` |
| `jj log -T '…'` | template：格式化输出语言 | 不属于 revset |
| `jj log` 图形中的 `◆`、`×` | 输出标记 | 不能作为提交表达式输入 |

Revset 是“返回一组提交”的语言，不是顺序执行脚本。集合中的元素是提交对象，同一目标重复出现会去重。表达式选中了哪些提交，与最终命令是否会重写其后代，是两个问题。

单提交命令仍要求恰好一个结果；集合参数按各命令自身声明处理。**v0.45.1 不支持 `all:` 修饰符**。需要验证唯一性时用 `exactly(x, 1)`，但不能用它绕开命令本身的限制。

所有查询示例都可以先用 `jj log -r '表达式'` 预览。普通 `jj log` 可能快照当前磁盘改动；`jj --ignore-working-copy log ...` 可避免这一步，但也因此看不到尚未快照的改动。

验证范围：根据固定 tag 的官方文档、Rust 注册表、解析器、默认配置与日志模板核对。未安装/编译该版本 jj，未把示例标成实际仓库运行通过。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs) · [`lib/src/revset_parser.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset_parser.rs) · [`CHANGELOG.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/CHANGELOG.md)


<a id="revset-hidden"></a>

## Hidden revisions / 可见、隐藏与搜索域

通常只搜索当前视图的**可见提交**及其祖先。被重写或 abandon 的旧版本可能仍存在于仓库对象中，但不自动参与普通查询。

显式引用隐藏 commit ID、`change_id/offset`、相关远端符号，或者使用 `at_operation()`，可把对应历史带入搜索范围。隐藏提交的祖先也会参与 `all()`、`~x`、`x..` 等运算。因此这些集合不是脱离表达式上下文的固定全集。

```text
all()        当前表达式的搜索域
visible()    ::visible_heads()，当前视图的可见提交
hidden()     ~visible()，搜索域中不属于当前可见历史的提交
```

`hidden()` 单独查询通常为空，**不等于“列出所有曾经出现过的提交”**。`all()` 也不能用来保证遍历所有旧版本或垃圾回收后已不存在的对象。

下面两组表达式展示“显式引入”和“限定结果”的区别。将 `COMMIT_ID` 换成真实的隐藏提交 ID：

```sh
# 明确查询某个旧对象
jj log -r 'commit_id(COMMIT_ID)'

# 只留下该对象的祖先中目前隐藏的部分
jj log -r 'hidden() & ::commit_id(COMMIT_ID)'

# 在上一个 operation 的视图中看全部当时可见历史
jj --ignore-working-copy log -r 'at_operation(@-, all())'

# 从该操作历史中挑出现在隐藏的提交
jj --ignore-working-copy log -r 'hidden() & at_operation(@-, all())'
```

`at_operation(op, x)` 对搜索域的扩展不局限于 x 的最终结果；它会带入该 operation 当时可见的历史。最终要哪些元素，仍要用交集、差集等明确限制。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#hidden-revisions) · [`docs/glossary.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/glossary.md#visible-commits) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs)


<a id="revset-symbols"></a>

## Symbols / 提交符号、工作区与 change offset

| 符号 | 含义 | 注意事项 |
|---|---|---|
| `@` | 当前 workspace 的工作副本提交 | 不是“当前 bookmark” |
| `review@` | 名为 review 的 workspace 的工作副本提交 | 名字只是示例，工作区必须存在 |
| `main` | 名为 main 的标签或书签等符号 | 先匹配标签，再匹配书签，最后匹配 ID |
| `main@origin` | 本地记录的 origin 远端标签或书签目标 | 不是实时远端查询；标签优先 |
| `main@git` | 特殊 Git 跟踪引用 | `git` 不是必须存在于网络上的 remote |
| 完整 commit ID / 唯一前缀 | 指向特定提交对象 | 前缀不唯一会报错 |
| 完整 change ID / 唯一前缀 | 指向该 change 的可见提交 | 分歧导致多目标时，裸符号报错 |
| `xyz/0`、`xyz/1` | 同一 change 的版本偏移 | 最新为 0；1 是之前的版本，不是父提交 |
| `"x-"` | 名字本身为 x- 的符号 | 不加表达式内引号时，`x-` 表示 x 的父 |

`xyz` 仅是 change ID 的示意，请替换成日志中的真实 ID。offset 会随着版本演进变化，**不是持久稳定的对象标识**；需要记录精确快照时保存完整 commit ID。

### Priority / 符号解析优先级

同名时按 **标签 → 书签 → commit/change ID** 解析。脚本中需要去歧义时使用函数：

```sh
jj log -r 'tags(exact:"release")'
jj log -r 'bookmarks(exact:"release")'
jj log -r 'commit_id(COMMIT_ID)'
jj log -r 'change_id(CHANGE_ID)'
```

最后两条中的大写词是待替换占位符，不是可直接使用的合法 ID。

“默认日志缩写多少位”不是 revset 语法保证。以当前仓库实际能唯一解析的前缀为准；已有 ID 前缀以后也可能因为新增对象而不再唯一。

### Quoting / 两层引号

```sh
# 外层单引号防 shell 把 |、&、* 等解释为管道或通配符
jj log -r 'mine() & (trunk()..@)'

# 外层交给 shell，内层保留给 revset 解析器
jj log -r '"x-"'

# 字符串模式与内容在 revset 内用双引号
jj log -r 'subject(substring:"fix parser")'
```

名字包含空格、运算符样字符时要特别注意。`x-y` 可能是一个书签名字；不要把它当作集合差集。`\` 换行写法因 shell 而异，本手册使用单行 POSIX shell 示例。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#symbols) · [`docs/glossary.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/glossary.md#change-offset) · [`lib/src/revset.pest`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.pest)


<a id="revset-operators"></a>

## Operators / 全部运算符与优先级

下面从**结合最紧到最松**排列。`x`、`y`、`z` 可为任意 revset，而不仅是单个 ID。

| 优先级 | 语法 | 中文含义 / 等价关系 |
|---|---|---|
| 1 | `f(x)` | 函数调用 |
| 2 | `x-`、`x+` | 直接父、直接子；可连续使用 `x--`、`x++` |
| 3 | `p:x` | 字符串/日期模式，或名为 p 的模式别名 |
| 4 | `::x` | x 与全部祖先；`ancestors(x)` |
| 4 | `x::` | x 与全部后代；`descendants(x)` |
| 4 | `x::y` | x 的后代 ∩ y 的祖先；`x:: & ::y` |
| 4 | `..x` | x 的祖先去掉虚拟根；`root()..x` |
| 4 | `x..` | 搜索域中不属于 x 祖先的提交；`~::x` |
| 4 | `x..y` | y 的祖先减去 x 的祖先；`::y ~ ::x` |
| 4 | `::` | `all()`，受搜索域扩展规则影响 |
| 4 | `..` | 搜索域去掉虚拟根；`~root()` |
| 5 | `~x` | 补集；搜索域中不属于 x 的提交 |
| 6 | `x & y` | 交集 |
| 6 | `x ~ y` | 差集 |
| 7 | `x \| y` | 并集 |

同优先级的中缀集合运算**从左到右**。括号可以改变顺序：

```text
x | y & z       = x | (y & z)
x ~ y & z       = (x ~ y) & z
x ~ (y & z)     需要显式括号，不能省略
~x::            = ~(x::)
(@ | trunk())-  先取集合，再取各自父提交
```

范围运算叠加要用括号明确层级，不要写含混的 `A::B::C`。`p:x` 只在相应模式/别名上下文成立；`A:B` **不是**有效的简写 DAG 范围。

### 区分“所有祖先”“精确第 N 代”“前 N 代”

```text
@---                恰好沿三条父边可到达的提交
parents(@, 3)       与 @--- 等价
ancestors(@, 3)     @ + 直接父 + 再上一代，不是 @ 的第三代父
first_parent(@, 3)  恰好沿第一父链三步
first_ancestors(@)  沿第一父链一直回溯，并包括 @
```

merge 情况下 `@-`、`@--` 可能返回多个结果。`@+` 是子提交关系，不是操作历史里的“下一次命令”，也不是撤销/重做。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#operators) · [`lib/src/revset_parser.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset_parser.rs) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L776-L839)


<a id="revset-ranges"></a>

## Examples / 用同一张图分清 :: 与 ..

以下字母代表提交，不代表顺序编号。图从下往上推进，D 有 B、C 两个父：

```text
      D
     / \
    B   C
     \ /
      A
      |
    root()
```

| 表达式 | 结果集合 | 理由 |
|---|---|---|
| `D-` | `{B, C}` | 合并的两个直接父 |
| `D--` | `{A}` | 两条父路径最后去重 |
| `::B` | `{root(), A, B}` | 包含自身的祖先 |
| `..B` | `{A, B}` | 相同祖先但排除虚拟根 |
| `B::` | `{B, D}` | 从 B 向后走 |
| `B..` | `{C, D}` | 排除 B 的全部祖先，不是只向后走 |
| `B::D` | `{B, D}` | 在 B 的后代与 D 的祖先交集中 |
| `B..D` | `{C, D}` | D 的祖先减去 B 的祖先 |
| `B::C` | `{}` | B 不是 C 的祖先 |
| `B..C` | `{C}` | 不要求 B、C 存在祖先关系 |
| `D..` | `{}` | 这张图所有提交都是 D 的祖先 |
| `(B \| C)..` | `{D}` | 同时排除两组祖先 |
| `B.. \| C..` | `{B, C, D}` | 与上一行不同 |

集合顺序不重要。核心区别：

```text
B::D  ——“沿着 B 到 D 的祖先关系，取路径上的提交”
B..D  ——“D 已包含，而 B 还没有包含的提交”
```

因此，整理主线以外的历史时常用 `trunk()..@`；但不要把它解释为“主线与 @ 之间的一条直线”。

还有一个常见代数陷阱：

```text
(A | B).. = A.. & B..
(A | B).. != A.. | B..
```

这是从祖先并集取补集所产生的交集关系。此页结果已用独立的小型 DAG 集合模型检查，但这不是执行 jj 二进制的结果。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#operators)


<a id="revset-function-syntax"></a>

## Functions / 函数签名、默认值与参数类型

后文每个条目保留 `Signature / Arguments / Returns / Examples / Notes / Source` 字段，中文说明不改参数名和语法。

签名中的 `[arg]` 表示**可选实参**，输入时不要带方括号。`revsets...` 表示可变数量实参。绝大多数函数是位置参数，不能照着 Rust/Python 的习惯给任何参数加名字。

```text
ancestors(@, 3)          正确
ancestors(@, depth=3)    不支持这种命名实参
exactly(@, 1)            正确
exactly(@, count=1)      不支持这种命名实参
```

远端引用家族明确支持第二个参数的 `remote=`：

```text
remote_bookmarks()
remote_bookmarks("main")
remote_bookmarks("main", "origin")
remote_bookmarks("main", remote="origin")
remote_bookmarks(remote="origin")
```

`remote_tags()` 及四个 tracked/untracked 函数同理。不支持随意造出 `name=` 参数。

### 参数不是同一种语言

```text
ancestors(mine() & mutable(), 3)       第一参数是提交集合
bookmarks(glob:"feature/*")           第一参数是字符串匹配条件
files(root:"src" ~ root:"src/tmp")     第一参数是路径集合
author_date(after:"2026-09-01")        第一参数是日期边界
at_operation(@-, @)                  第一参数是 operation，第二个是 commit revset
```

`files(all())` 的 `all()` 属于 fileset，表示所有路径；最外层的 `all()` 属于 revset，表示搜索域里的全部提交。不要用“函数同名”推断二者类型相同。

### 默认值速记

| 家族 | 省略可选参数的行为 | 0 的行为 |
|---|---|---|
| parents / children / first_parent | depth=1 | 返回来源 x |
| ancestors / descendants / first_ancestors | 不限深度 | 返回空集合 |
| latest | count=1 | 返回空集合 |
| bookmarks / tags | 匹配全部本地对应引用 | 不适用 |
| remote_* / tracked_* / untracked_* | 全部默认远端范围，排除特殊 git | 不适用 |
| diff_lines / added / removed | 搜索全部修改文件 | 不适用 |

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L776-L1164) · [`lib/src/dsl_util.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/dsl_util.rs#L139-L198)


<a id="revset-fn-parents"></a>

## parents(x, [depth])

**取恰好指定代数的父提交。**

**Signature / 签名**

```text
parents(x, [depth])
```

**Arguments / 参数：** x：任意 revset；depth：可选非负整数，默认 1。

**Returns / 返回：** 距离来源恰好 depth 条父边所能到达的提交集合。

**Examples / 示例**

```sh
jj log -r 'parents(@, 2)'
```

**Notes / 注意：** depth=0 返回 x；parents(x, 3) 等价于 x---。合并提交有多个父，结果不保证只有一个；不同长度路径可能到达同一提交。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L777) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-children"></a>

## children(x, [depth])

**取恰好指定代数的子提交。**

**Signature / 签名**

```text
children(x, [depth])
```

**Arguments / 参数：** x：来源集合；depth：可选非负整数，默认 1。

**Returns / 返回：** 距离来源恰好 depth 条子边所能到达的集合。

**Examples / 示例**

```sh
jj log -r 'children(@-, 1)'
```

**Notes / 注意：** depth=0 返回 x；children(x, 3) 等价于 x+++。不是“向后查看任意三代”，也不保证只有一个子提交。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L787) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-ancestors"></a>

## ancestors(x, [depth])

**取自身及祖先，可限定包含多少代。**

**Signature / 签名**

```text
ancestors(x, [depth])
```

**Arguments / 参数：** x：来源集合；depth：可选非负整数；省略时沿所有父边不限深度。

**Returns / 返回：** 遍历代数落在 0 <= generation < depth 内的提交；省略 depth 时返回 ::x。

**Examples / 示例**

```sh
jj log -r 'ancestors(@, 5)'
```

**Notes / 注意：** 与 parents 的计数方式不同：ancestors(x, 0) 为空；depth=1 只有 x；depth=2 包含 x 和直接父。合并历史每代可有多个提交。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L797) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-descendants"></a>

## descendants(x, [depth])

**取自身及后代，可限定包含多少代。**

**Signature / 签名**

```text
descendants(x, [depth])
```

**Arguments / 参数：** x：来源集合；depth：可选非负整数；省略时不限深度。

**Returns / 返回：** 遍历代数在 [0, depth) 内的提交；省略 depth 时等价于 x::。

**Examples / 示例**

```sh
jj log -r 'descendants(trunk(), 2)'
```

**Notes / 注意：** depth=0 为空，depth=1 只有 x，depth=2 再包含直接子。搜索范围仍受可见性与显式隐藏提交扩展规则影响。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L808) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-first_parent"></a>

## first_parent(x, [depth])

**每一层只沿第一个父提交前进。**

**Signature / 签名**

```text
first_parent(x, [depth])
```

**Arguments / 参数：** x：来源集合；depth：可选非负整数，默认 1。

**Returns / 返回：** 沿第一父链前进恰好 depth 步后的集合。

**Examples / 示例**

```sh
jj log -r 'first_parent(@, 2)'
```

**Notes / 注意：** 在合并处忽略第二及后续父；depth=0 返回 x。输入有多个提交时仍可能有多个结果。第一父由提交父顺序决定，不是按提交时间挑选。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L819) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-first_ancestors"></a>

## first_ancestors(x, [depth])

**包含自身，沿第一父链查看祖先。**

**Signature / 签名**

```text
first_ancestors(x, [depth])
```

**Arguments / 参数：** x：来源集合；depth：可选非负整数，省略时不限深度。

**Returns / 返回：** 自身和各层第一父；有限 depth 使用 [0, depth) 的代数范围。

**Examples / 示例**

```sh
jj log -r 'first_ancestors(@, 10)'
```

**Notes / 注意：** depth=1 仅来源，depth=2 加直接第一父。适合看主线的第一父历史，不代表所有真正参与合并的提交都被显示。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L829) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-reachable"></a>

## reachable(srcs, domain)

**在限定集合内，沿父边和子边双向找连通提交。**

**Signature / 签名**

```text
reachable(srcs, domain)
```

**Arguments / 参数：** srcs：起点 revset；domain：允许途经的 revset；均必填。

**Returns / 返回：** 从 srcs 出发且整条路径都在 domain 内的所有提交。

**Examples / 示例**

```sh
jj log -r 'reachable(@, mutable())'
```

**Notes / 注意：** 不在 domain 内的起点被忽略；路径不能穿过域外提交再回来。会包含相关兄弟分支，不等于只取祖先或后代。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L845) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-connected"></a>

## connected(x)

**填补所选提交之间的祖先—后代路径。**

**Signature / 签名**

```text
connected(x)
```

**Arguments / 参数：** x：任意 revset，必填。

**Returns / 返回：** x::x，即同时属于 x 后代和 x 祖先的提交。

**Examples / 示例**

```sh
jj log -r 'connected(trunk() | @)'
```

**Notes / 注意：** 名称容易误导：它不是整张无向图的连通分量，也不会仅因两个提交共享祖先就把公共祖先补进来。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L840) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-all"></a>

## all()

**返回当前搜索域内的所有提交。**

**Signature / 签名**

```text
all()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 当前可见提交，以及在表达式中显式引入的隐藏提交及其祖先等扩展范围。

**Examples / 示例**

```sh
jj log -r 'all()'
```

**Notes / 注意：** 不是对象库中所有历史 commit 的枚举。等价于 ::；与已移除的 all: 修饰符无关。at_operation() 还会扩展搜索域。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L855) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-none"></a>

## none()

**返回空集合。**

**Signature / 签名**

```text
none()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 零个提交。

**Examples / 示例**

```sh
jj log -r 'none()'
```

**Notes / 注意：** 适合作为别名或回退分支。它不是 root()；root() 有一个虚拟提交。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L851) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-change_id"></a>

## change_id(prefix)

**按 change ID 前缀查找提交。**

**Signature / 签名**

```text
change_id(prefix)
```

**Arguments / 参数：** prefix：合法 change ID 的完整值或前缀，不是 glob 模式。

**Returns / 返回：** 匹配该 change 的提交；分歧状态可返回多个版本。

**Examples / 示例**

```sh
jj log -r 'change_id(CHANGE_ID)'  # 将 CHANGE_ID 换成实际 change ID
```

**Notes / 注意：** 前缀对应多个不同 change 时报歧义错误；合法但无匹配的前缀返回空集合。裸 change ID 符号与此函数不同：裸符号不能直接解析为多个分歧版本。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L881) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-commit_id"></a>

## commit_id(prefix)

**按 commit ID 前缀精确定位提交对象。**

**Signature / 签名**

```text
commit_id(prefix)
```

**Arguments / 参数：** prefix：合法十六进制 commit ID 的完整值或前缀，不是 glob 模式。

**Returns / 返回：** 唯一匹配的提交，或者空集合。

**Examples / 示例**

```sh
jj log -r 'commit_id(COMMIT_ID)'  # 将 COMMIT_ID 换成实际 commit ID
```

**Notes / 注意：** 歧义前缀报错；合法但无匹配的前缀不报“未知符号”。可避免同名标签/书签抢先解析，并可显式引入隐藏提交。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L890) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-bookmarks"></a>

## bookmarks([pattern])

**选择本地书签指向的提交。**

**Signature / 签名**

```text
bookmarks([pattern])
```

**Arguments / 参数：** pattern：可选字符串模式，默认匹配全部本地书签名。

**Returns / 返回：** 匹配书签的目标集合；冲突书签包含其所有可能目标。

**Examples / 示例**

```sh
jj log -r 'bookmarks(glob:"feature/*")'
```

**Notes / 注意：** 返回提交，不返回书签名字。多个书签指向同一提交会去重。不会自动包含其祖先；需要 ::bookmarks() 时应显式加祖先运算符。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L899) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-remote_bookmarks"></a>

## remote_bookmarks([name_pattern], [[remote=]remote_pattern])

**选择全部远端书签的目标。**

**Signature / 签名**

```text
remote_bookmarks([name_pattern], [[remote=]remote_pattern])
```

**Arguments / 参数：** name_pattern：可选书签/标签名字符串模式；remote_pattern：可选远端名字符串模式，可用 remote= 指定。两者省略时匹配默认范围。

**Returns / 返回：** 名称与远端模式均匹配、且满足全部条件的目标提交集合。

**Examples / 示例**

```sh
jj log -r 'remote_bookmarks(remote="origin")'
```

**Notes / 注意：** 默认不包含特殊 git 跟踪引用；明确 remote="git" 只选这些引用，remote="*" 才把它们也包括进来。仅查询本地已知远端状态，不会联网 fetch。 “跟踪”是引用关系状态，不等于已发布/未发布的提交分类；冲突引用可产生多个目标。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L908) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-tracked_remote_bookmarks"></a>

## tracked_remote_bookmarks([name_pattern], [[remote=]remote_pattern])

**选择已跟踪远端书签的目标。**

**Signature / 签名**

```text
tracked_remote_bookmarks([name_pattern], [[remote=]remote_pattern])
```

**Arguments / 参数：** name_pattern：可选书签/标签名字符串模式；remote_pattern：可选远端名字符串模式，可用 remote= 指定。两者省略时匹配默认范围。

**Returns / 返回：** 名称与远端模式均匹配、且满足已跟踪条件的目标提交集合。

**Examples / 示例**

```sh
jj log -r 'tracked_remote_bookmarks("feature/*", remote="origin")'
```

**Notes / 注意：** 默认不包含特殊 git 跟踪引用；明确 remote="git" 只选这些引用，remote="*" 才把它们也包括进来。仅查询本地已知远端状态，不会联网 fetch。 “跟踪”是引用关系状态，不等于已发布/未发布的提交分类；冲突引用可产生多个目标。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L913) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-untracked_remote_bookmarks"></a>

## untracked_remote_bookmarks([name_pattern], [[remote=]remote_pattern])

**选择未跟踪远端书签的目标。**

**Signature / 签名**

```text
untracked_remote_bookmarks([name_pattern], [[remote=]remote_pattern])
```

**Arguments / 参数：** name_pattern：可选书签/标签名字符串模式；remote_pattern：可选远端名字符串模式，可用 remote= 指定。两者省略时匹配默认范围。

**Returns / 返回：** 名称与远端模式均匹配、且满足未跟踪条件的目标提交集合。

**Examples / 示例**

```sh
jj log -r 'untracked_remote_bookmarks(remote="origin")'
```

**Notes / 注意：** 默认不包含特殊 git 跟踪引用；明确 remote="git" 只选这些引用，remote="*" 才把它们也包括进来。仅查询本地已知远端状态，不会联网 fetch。 “跟踪”是引用关系状态，不等于已发布/未发布的提交分类；冲突引用可产生多个目标。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L921) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-tags"></a>

## tags([pattern])

**选择本地标签指向的提交。**

**Signature / 签名**

```text
tags([pattern])
```

**Arguments / 参数：** pattern：可选标签名字符串模式；省略表示全部标签。

**Returns / 返回：** 匹配标签的目标集合；冲突标签包含其所有可能目标。

**Examples / 示例**

```sh
jj log -r 'tags(glob:"v0.45*")'
```

**Notes / 注意：** 选择的是标签目标提交而非注解标签对象。与 bookmarks() 分开查询，能避开裸符号“标签优先”的名称冲突。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L929) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-remote_tags"></a>

## remote_tags([name_pattern], [[remote=]remote_pattern])

**选择全部远端标签的目标。**

**Signature / 签名**

```text
remote_tags([name_pattern], [[remote=]remote_pattern])
```

**Arguments / 参数：** name_pattern：可选书签/标签名字符串模式；remote_pattern：可选远端名字符串模式，可用 remote= 指定。两者省略时匹配默认范围。

**Returns / 返回：** 名称与远端模式均匹配、且满足全部条件的远端标签目标集合。

**Examples / 示例**

```sh
jj log -r 'remote_tags("v*", remote="origin")'
```

**Notes / 注意：** 默认不包含特殊 git 跟踪引用；明确 remote="git" 只选这些引用，remote="*" 才把它们也包括进来。仅查询本地已知远端状态，不会联网 fetch。 参数解析与 remote_bookmarks() 共用；目标集合会去重。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L938) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-tracked_remote_tags"></a>

## tracked_remote_tags([name_pattern], [[remote=]remote_pattern])

**选择已跟踪远端标签的目标。**

**Signature / 签名**

```text
tracked_remote_tags([name_pattern], [[remote=]remote_pattern])
```

**Arguments / 参数：** name_pattern：可选书签/标签名字符串模式；remote_pattern：可选远端名字符串模式，可用 remote= 指定。两者省略时匹配默认范围。

**Returns / 返回：** 名称与远端模式均匹配、且满足已跟踪条件的远端标签目标集合。

**Examples / 示例**

```sh
jj log -r 'tracked_remote_tags(remote="origin")'
```

**Notes / 注意：** 默认不包含特殊 git 跟踪引用；明确 remote="git" 只选这些引用，remote="*" 才把它们也包括进来。仅查询本地已知远端状态，不会联网 fetch。 参数解析与 remote_bookmarks() 共用；目标集合会去重。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L943) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-untracked_remote_tags"></a>

## untracked_remote_tags([name_pattern], [[remote=]remote_pattern])

**选择未跟踪远端标签的目标。**

**Signature / 签名**

```text
untracked_remote_tags([name_pattern], [[remote=]remote_pattern])
```

**Arguments / 参数：** name_pattern：可选书签/标签名字符串模式；remote_pattern：可选远端名字符串模式，可用 remote= 指定。两者省略时匹配默认范围。

**Returns / 返回：** 名称与远端模式均匹配、且满足未跟踪条件的远端标签目标集合。

**Examples / 示例**

```sh
jj log -r 'untracked_remote_tags(remote="origin")'
```

**Notes / 注意：** 默认不包含特殊 git 跟踪引用；明确 remote="git" 只选这些引用，remote="*" 才把它们也包括进来。仅查询本地已知远端状态，不会联网 fetch。 参数解析与 remote_bookmarks() 共用；目标集合会去重。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L948) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-visible_heads"></a>

## visible_heads()

**返回当前视图的可见顶端提交。**

**Signature / 签名**

```text
visible_heads()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 可见历史的 heads。

**Examples / 示例**

```sh
jj log -r 'visible_heads()'
```

**Notes / 注意：** 没有引入隐藏提交时等价于 heads(all())；引入隐藏历史后两者不一定相等。别把它理解成所有书签目标。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L873) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-root"></a>

## root()

**选择所有提交共同的虚拟根。**

**Signature / 签名**

```text
root()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 恰好一个虚拟根提交。

**Examples / 示例**

```sh
jj log -r 'root()'
```

**Notes / 注意：** 不是某个项目第一条真实提交；root() 不应被重写。..x 会排除它，::x 会包括它。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L877) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-heads"></a>

## heads(x)

**保留集合内没有其他所选后代的提交。**

**Signature / 签名**

```text
heads(x)
```

**Arguments / 参数：** x：待筛选的 revset。

**Returns / 返回：** x 中不属于 x 内其他提交的严格祖先的元素。

**Examples / 示例**

```sh
jj log -r 'heads(mine() & mutable())'
```

**Notes / 注意：** 考察完整祖先关系，哪怕中间提交不在 x 中。不是仅检查直接子是否在 x；也不是按时间取最新。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L863) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-roots"></a>

## roots(x)

**保留集合内没有其他所选祖先的提交。**

**Signature / 签名**

```text
roots(x)
```

**Arguments / 参数：** x：待筛选的 revset。

**Returns / 返回：** x 中不属于 x 内其他提交的严格后代的元素。

**Examples / 示例**

```sh
jj log -r 'roots(trunk()..@)'
```

**Notes / 注意：** 考察完整祖先关系；roots(x) 与 root() 完全不同，前者可能有多个结果或为空。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L868) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-latest"></a>

## latest(x, [count])

**按 committer 时间取最新的若干提交。**

**Signature / 签名**

```text
latest(x, [count])
```

**Arguments / 参数：** x：候选 revset；count：可选非负整数，默认 1。

**Returns / 返回：** 最多 count 个提交；候选不足时返回实际数量。

**Examples / 示例**

```sh
jj log -r 'latest(mine(), 5)'
```

**Notes / 注意：** 不是 author 时间，也不等于拓扑 heads；重写后 committer 时间可能改变。count=0 为空；不能用它代替 exactly() 验证唯一性。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L953) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-fork_point"></a>

## fork_point(x)

**查找全部候选的最近公共祖先。**

**Signature / 签名**

```text
fork_point(x)
```

**Arguments / 参数：** x：候选提交集合。

**Returns / 返回：** 共同祖先中不再有其他共同祖先作为后代的那些提交。

**Examples / 示例**

```sh
jj log -r 'fork_point(@ | trunk())'
```

**Notes / 注意：** 复杂合并历史可能得到多个“最近”公共祖先。单个候选返回自身，空集返回空；不是按日期找分叉点。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L963) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-merge_point"></a>

## merge_point(x)

**查找全部候选的最早公共后代。**

**Signature / 签名**

```text
merge_point(x)
```

**Arguments / 参数：** x：候选提交集合。

**Returns / 返回：** 共同后代中不再有其他共同后代作为祖先的那些提交。

**Examples / 示例**

```sh
jj log -r 'merge_point(bookmarks("feature/a") | bookmarks("feature/b"))'
```

**Notes / 注意：** 单个候选返回自身；可能没有共同后代，也可能有多个最小公共后代。不是“找所有 merge commit”。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L968) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-bisect"></a>

## bisect(x)

**从候选集合中挑选大致居中的二分点。**

**Signature / 签名**

```text
bisect(x)
```

**Arguments / 参数：** x：希望缩小定位范围的候选集合。

**Returns / 返回：** 使其后代约占输入集合一半的候选提交。

**Examples / 示例**

```sh
jj log -r 'bisect(trunk()..@)'
```

**Notes / 注意：** 这是选择函数，不会运行测试、移动工作区或记录 good/bad。官方说明其对非线性历史的处理仍有局限；实际自动定位参见 jj bisect run。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L973) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-exactly"></a>

## exactly(x, count)

**断言 revset 的结果数量。**

**Signature / 签名**

```text
exactly(x, count)
```

**Arguments / 参数：** x：要验证的集合；count：必填非负整数。

**Returns / 返回：** 数量恰好为 count 时原样返回 x，否则报错。

**Examples / 示例**

```sh
jj log -r 'exactly(bookmarks(exact:"feature"), 1)'
```

**Notes / 注意：** 不是截断，也不是随机挑选。exactly(x, 1) 可保护脚本中的单目标操作；count=0 可断言没有结果。不能写 count=1 这个命名实参。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L978) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-merges"></a>

## merges()

**选择有多个父提交的合并提交。**

**Signature / 签名**

```text
merges()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 父提交数量大于 1 的提交。

**Examples / 示例**

```sh
jj log -r 'merges() & ::@'
```

**Notes / 注意：** 合并提交可以 empty()，也可以 conflicts()；结构与内容状态是不同维度。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L984) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-forks"></a>

## forks()

**选择有多个子提交的分叉点。**

**Signature / 签名**

```text
forks()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 子提交数量大于 1 的提交。

**Examples / 示例**

```sh
jj log -r 'forks() & mutable()'
```

**Notes / 注意：** 这是结构过滤器，不等于 fork_point(x)，也不等于托管平台上的 fork 仓库。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L990) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-description"></a>

## description(pattern)

**按完整提交说明筛选。**

**Signature / 签名**

```text
description(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式，默认按 glob 解释。

**Returns / 返回：** 完整 description 匹配模式的提交。

**Examples / 示例**

```sh
jj log -r 'description(substring:"validation")'
```

**Notes / 注意：** 非空说明通常以换行结尾；description(exact:"fix") 不等于只匹配标题 fix。查包含词使用 substring:"fix"；没有说明用 description("")。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L994) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-subject"></a>

## subject(pattern)

**按说明的第一行筛选。**

**Signature / 签名**

```text
subject(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式，默认 glob。

**Returns / 返回：** 说明第一行（不含换行符）匹配的提交。

**Examples / 示例**

```sh
jj log -r 'subject(glob:"fix:*")'
```

**Notes / 注意：** 适合 Conventional Commits 标题筛选；与 description() 对正文及末尾换行的行为不同。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1000) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-author"></a>

## author(pattern)

**按原作者的姓名或邮箱筛选。**

**Signature / 签名**

```text
author(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式，默认 glob。

**Returns / 返回：** author_name(pattern) | author_email(pattern)。

**Examples / 示例**

```sh
jj log -r 'author(substring-i:"alice")'
```

**Notes / 注意：** 姓名与邮箱分别匹配，不把它们先拼成 Name <email>。多个重写者不改变“按 author 过滤”的含义。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1006) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-author_name"></a>

## author_name(pattern)

**只匹配作者姓名。**

**Signature / 签名**

```text
author_name(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式。

**Returns / 返回：** author.name 匹配的提交。

**Examples / 示例**

```sh
jj log -r 'author_name(exact:"Alice Example")'
```

**Notes / 注意：** 默认 glob，不默认做子串匹配；同名作者不是可靠的身份认证。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1014) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-author_email"></a>

## author_email(pattern)

**只匹配作者邮箱。**

**Signature / 签名**

```text
author_email(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式。

**Returns / 返回：** author.email 匹配的提交。

**Examples / 示例**

```sh
jj log -r 'author_email(glob:"*@example.com")'
```

**Notes / 注意：** 可用 exact-i 做忽略大小写的完全匹配；元数据邮箱本身不证明签名可信。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1020) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-author_date"></a>

## author_date(pattern)

**按作者时间筛选。**

**Signature / 签名**

```text
author_date(pattern)
```

**Arguments / 参数：** pattern：必填日期模式，仅 after: 或 before:。

**Returns / 返回：** 作者时间满足日期边界的提交。

**Examples / 示例**

```sh
jj log -r 'author_date(after:"2026-09-01T00:00:00+08:00")'
```

**Notes / 注意：** after 为大于等于，before 为严格小于；要限定时间区间，用两个 author_date() 的交集。作者时间不等于重写时间。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1026) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-mine"></a>

## mine()

**选择作者邮箱等于当前配置邮箱的提交。**

**Signature / 签名**

```text
mine()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 等价于 author_email(exact-i:<当前 user.email>)。

**Examples / 示例**

```sh
jj log -r 'mine() & mutable()'
```

**Notes / 注意：** 不是“所有经我 rebase/提交过的内容”，不按 committer 身份判断；实际结果取决于当前 user.email 配置。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1038) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-committer"></a>

## committer(pattern)

**按提交者姓名或邮箱筛选。**

**Signature / 签名**

```text
committer(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式，默认 glob。

**Returns / 返回：** committer_name(pattern) | committer_email(pattern)。

**Examples / 示例**

```sh
jj log -r 'committer(substring-i:"alice")'
```

**Notes / 注意：** committer 记录生成当前提交对象的提交者，与最初 author 可能不同；重写会形成新的提交对象。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1047) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-committer_name"></a>

## committer_name(pattern)

**只匹配提交者姓名。**

**Signature / 签名**

```text
committer_name(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式。

**Returns / 返回：** committer.name 匹配的提交。

**Examples / 示例**

```sh
jj log -r 'committer_name(exact:"Alice Example")'
```

**Notes / 注意：** 不要与 author_name() 混用；默认 glob。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1055) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-committer_email"></a>

## committer_email(pattern)

**只匹配提交者邮箱。**

**Signature / 签名**

```text
committer_email(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式。

**Returns / 返回：** committer.email 匹配的提交。

**Examples / 示例**

```sh
jj log -r 'committer_email(glob:"*@example.com")'
```

**Notes / 注意：** 适合调查由特定账号或自动化系统生成的提交对象，不保证它们的作者也是该账号。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1061) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-committer_date"></a>

## committer_date(pattern)

**按提交者时间筛选。**

**Signature / 签名**

```text
committer_date(pattern)
```

**Arguments / 参数：** pattern：必填日期模式 after: 或 before:。

**Returns / 返回：** committer 时间满足边界的提交。

**Examples / 示例**

```sh
jj log -r 'committer_date(after:"2 days ago")'
```

**Notes / 注意：** 这是 latest() 使用的时间维度。相对时间按命令执行时刻和日期上下文解析；需复现时用含时区的绝对时间。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1067) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-signed"></a>

## signed()

**选择带有密码学签名的提交。**

**Signature / 签名**

```text
signed()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 具有签名数据的提交。

**Examples / 示例**

```sh
jj log -r 'signed() & ::@'
```

**Notes / 注意：** 不等于签名已验证、密钥可信或作者身份真实。签名状态需查看签名验证结果。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1033) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-empty"></a>

## empty()

**选择没有文件改动的提交。**

**Signature / 签名**

```text
empty()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 相对父提交合并基准没有文件变化的提交。

**Examples / 示例**

```sh
jj log -r 'empty() & mutable()'
```

**Notes / 注意：** 包括虚拟 root()，以及没有用户修改的自动合并提交。不是“没有提交说明”，后者是 description("")；也不等于没有子提交。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1074) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-files"></a>

## files(expression)

**按被修改的文件路径筛选提交。**

**Signature / 签名**

```text
files(expression)
```

**Arguments / 参数：** expression：必填 fileset 表达式，不是另一个 revset。

**Returns / 返回：** 修改了至少一条匹配路径的提交。

**Examples / 示例**

```sh
jj log -r 'files(root:"src") & ::@'
```

**Notes / 注意：** 默认路径相对 jj 启动目录；目录匹配其子树。files(".") 的点要加引号。root: / root-file: 可避免依赖当前目录；这不是搜索快照中是否存在某文件。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1078) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-diff_lines"></a>

## diff_lines(text, [files])

**按 diff 的新增或删除行搜索。**

**Signature / 签名**

```text
diff_lines(text, [files])
```

**Arguments / 参数：** text：必填字符串模式，逐行匹配；files：可选 fileset 表达式，默认所有修改文件。

**Returns / 返回：** 在所选文件 diff 的新增或删除侧至少有一行满足模式的提交。

**Examples / 示例**

```sh
jj log -r 'diff_lines(substring:"TODO", root:"src")'
```

**Notes / 注意：** 查的是变更行，不是当前文件全部内容。默认字符串模式仍是 glob；用 substring: 可明确搜索词。v0.45.1 省略 files 时不会自动沿用命令行路径过滤；大仓库建议先限定 revset 和 paths。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1089) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-diff_lines_added"></a>

## diff_lines_added(text, [files])

**只在新增侧的 diff 行搜索。**

**Signature / 签名**

```text
diff_lines_added(text, [files])
```

**Arguments / 参数：** text：必填字符串模式，逐行匹配；files：可选 fileset 表达式，默认所有修改文件。

**Returns / 返回：** 在所选文件 diff 的新增侧至少有一行满足模式的提交。

**Examples / 示例**

```sh
jj log -r 'diff_lines_added(substring:"TODO", root:"src")'
```

**Notes / 注意：** 查的是变更行，不是当前文件全部内容。默认字符串模式仍是 glob；用 substring: 可明确搜索词。v0.45.1 省略 files 时不会自动沿用命令行路径过滤；大仓库建议先限定 revset 和 paths。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1107) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-diff_lines_removed"></a>

## diff_lines_removed(text, [files])

**只在删除侧的 diff 行搜索。**

**Signature / 签名**

```text
diff_lines_removed(text, [files])
```

**Arguments / 参数：** text：必填字符串模式，逐行匹配；files：可选 fileset 表达式，默认所有修改文件。

**Returns / 返回：** 在所选文件 diff 的删除侧至少有一行满足模式的提交。

**Examples / 示例**

```sh
jj log -r 'diff_lines_removed(substring:"deprecated", root:"src")'
```

**Notes / 注意：** 查的是变更行，不是当前文件全部内容。默认字符串模式仍是 glob；用 substring: 可明确搜索词。v0.45.1 省略 files 时不会自动沿用命令行路径过滤；大仓库建议先限定 revset 和 paths。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1118) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-conflicts"></a>

## conflicts()

**选择文件树中带有冲突的提交。**

**Signature / 签名**

```text
conflicts()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 存在文件冲突的提交。

**Examples / 示例**

```sh
jj log -r 'conflicts() & mutable()'
```

**Notes / 注意：** 不是书签目标冲突，也不是同一 change 的分歧版本；后者用 divergent()。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1131) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-divergent"></a>

## divergent()

**选择属于分歧 change 的可见提交。**

**Signature / 签名**

```text
divergent()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 同一 change ID 有多个可见提交版本时的相关提交。

**Examples / 示例**

```sh
jj log -r 'divergent() & mutable()'
```

**Notes / 注意：** 与文件冲突独立。裸 change ID 可能无法唯一解析；用 change_id(prefix) 取集合，用具体 commit ID 或 change offset 定位版本。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1135) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-present"></a>

## present(x)

**把缺失的提交符号转为空集合。**

**Signature / 签名**

```text
present(x)
```

**Arguments / 参数：** x：要解析的 revset。

**Returns / 返回：** 正常时返回 x；x 中出现无法找到的提交符号时整个表达式结果为空。

**Examples / 示例**

```sh
jj log -r 'present(main@origin) | present(master@origin)'
```

**Notes / 注意：** 不是通用 try/catch：语法错误、歧义等仍会失败。present(main | missing) 会整体为空，不是保留 main；分别容错应写 present(main) | present(missing)。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1139) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-coalesce"></a>

## coalesce(revsets...)

**选择第一个非空结果集合。**

**Signature / 签名**

```text
coalesce(revsets...)
```

**Arguments / 参数：** revsets...：零个或多个 revset 实参，按顺序考虑。

**Returns / 返回：** 首个非空集合；全空或没有实参时返回 none()。

**Examples / 示例**

```sh
jj log -r 'coalesce(present(main@origin), present(master@origin), root())'
```

**Notes / 注意：** 并不是未知符号错误的兜底器；各实参必须能被解析和解析引用。可能缺失的名字要各自放进 present()；也不把多个非空集合合并。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1156) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-working_copies"></a>

## working_copies()

**选择仓库所有工作区的工作副本提交。**

**Signature / 签名**

```text
working_copies()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 当前仓库各 workspace 记录的工作副本目标集合。

**Examples / 示例**

```sh
jj log -r 'working_copies()'
```

**Notes / 注意：** 与只选当前工作区的 @ 不同。读取其他工作区记录不会替它们扫描和快照未保存到仓库视图的磁盘改动。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L859) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-at_operation"></a>

## at_operation(op, x)

**在指定操作记录的仓库视图中计算 revset。**

**Signature / 签名**

```text
at_operation(op, x)
```

**Arguments / 参数：** op：必填操作 ID 或操作选择表达式（如 @-）；x：在该操作视图中计算的 revset。

**Returns / 返回：** 旧操作视图下 x 的结果，并把该操作可见的历史引入本表达式搜索域。

**Examples / 示例**

```sh
jj --ignore-working-copy log -r 'at_operation(@-, @)'
```

**Notes / 注意：** 第一个参数中的 @- 是上一个 operation，不是工作提交的父；第二个参数中的 @ 才是该视图的工作副本提交。只查询，不等于 op restore。普通命令的自动快照可能新增操作；核对时可用 --ignore-working-copy 或固定 operation ID。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1144) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-diff_contains"></a>

## diff_contains(text, [files])

**diff_lines() 的弃用兼容名称。**

> **状态：弃用兼容名；新代码使用 `diff_lines()`。**

**Signature / 签名**

```text
diff_contains(text, [files])
```

**Arguments / 参数：** text、files：与 diff_lines(text, [files]) 相同。

**Returns / 返回：** 与 diff_lines() 相同。

**Examples / 示例**

```sh
jj log -r 'diff_lines(substring:"TODO", root:"src")'  # 使用新名称
```

**Notes / 注意：** v0.45.1 源码仍注册它，并发出弃用警告；新用法改为 diff_lines()。源码的移除 TODO 不是已移除的证据。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1129) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-string-patterns"></a>

## String patterns / 字符串模式与逻辑组合

v0.45.1 默认把 `"text"` 解释成 **glob 模式**，不是默认子串搜索。四种模式都支持追加 `-i` 忽略大小写，共八种拼写：

| 精确写法 | 忽略大小写写法 | 含义 / 例子 |
|---|---|---|
| `exact:"text"` | `exact-i:"text"` | 整个字符串相等 |
| `glob:"pattern"` | `glob-i:"pattern"` | shell 风格通配匹配，如 `"fix:*"` |
| `regex:"pattern"` | `regex-i:"pattern"` | 正则子串匹配；需要整串时自行用 `^`、`$` |
| `substring:"text"` | `substring-i:"text"` | 原样子串匹配，不把特殊字符当正则 |

glob 常用 `*` 匹配任意串、`?` 匹配单字符、`[abc]` 匹配字符组、`{foo,bar}` 匹配备选。这里匹配的是**字符串**，不是 shell 展开，也不要直接套用 fileset 中 `*`/`**` 的路径分隔规则。

```sh
# 含有 fix 的说明
jj log -r 'description(substring:"fix")'

# 以 fix: 开头的标题
jj log -r 'subject(glob:"fix:*")'

# 标题恰好等于 fix parser
jj log -r 'subject(exact:"fix parser")'

# 完整说明通常有末尾换行；这里显式匹配换行
jj log -r 'description(exact:"fix parser\n")'
```

### 字符串条件也可做逻辑组合

```sh
jj log -r 'bookmarks(glob:"feature/*" ~ glob:"feature/wip-*")'
jj log -r 'author_email(exact:"a@example.com" | exact:"b@example.com")'
```

这里函数括号里面的 `|` / `~` 合并的是“名字是否匹配”的条件；函数外面合并的才是提交集合。

一个提交可能有多个书签，所以：

```text
bookmarks(~glob:"ci/*")
```

表示“至少有一个不叫 ci/* 的书签指向它”，**不等于** `bookmarks() ~ bookmarks(glob:"ci/*")`。后者会排除任何带 ci/* 书签的目标，即使它同时还有另一个普通书签。

### 不要串用三种冒号

`glob:"fix*"` 是字符串模式；`root:"src"` 是 fileset 模式；`after:"yesterday"` 是日期模式。冒号本身不是通用的 revset 范围运算符。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#string-patterns) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1209-L1245) · [`docs/filesets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/filesets.md#file-patterns)


<a id="revset-date-patterns"></a>

## Date patterns / 日期边界、时区与可复现查询

| 模式 | 边界 |
|---|---|
| `after:"时间"` | 大于等于给定时刻，包含边界 |
| `before:"时间"` | 严格小于给定时刻，不包含边界 |

支持日期、日期时间、含时区时间和相对时间，如 `"2026-09-01"`、`"2026-09-01T09:00:00+08:00"`、`"2 days ago"`、`"yesterday 10:30"`。无时区值按日期解析上下文处理，通常是本机时区；相对时间也取决于执行时刻。

查询新加坡时间 2026 年 9 月的作者时间：

```sh
jj log -r 'author_date(after:"2026-09-01T00:00:00+08:00") & author_date(before:"2026-10-01T00:00:00+08:00")'
```

这是 `[9 月 1 日 00:00, 10 月 1 日 00:00)` 半开区间，不会在月末最后一毫秒上遗漏或重复。

查询最近两天生成或重写的提交对象：

```sh
jj log -r 'committer_date(after:"2 days ago")'
```

`author_date` 记录最初创作时间，`committer_date` 随提交对象重写而更新。`latest()` 使用后者；不要把最近 rebase 的提交误认为最近才开始编写的提交。

日期模式不是任意字符串 glob，也不要写 `author_date(after:"..." & before:"...")`。区间用两个日期函数的交集表达。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#date-patterns) · [`lib/src/time_util.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/time_util.rs#L26-L178) · [`docs/glossary.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/glossary.md#committer-date)


<a id="revset-aliases"></a>

## Aliases / 自定义符号、函数与模式别名

别名定义在 `[revset-aliases]` 中，可以是普通符号、带参数函数或 `名称:值` 的模式。

```toml
[revset-aliases]
# 符号别名：只定义在你的配置中，不是 jj 自带 HEAD
HEAD = '@-'

# 函数别名：当前所在的可变连通栈
'stack()' = 'reachable(@, mutable())'

# 同名自定义别名可按实参数量重载
'user()' = 'user("me@example.com")'
'user(x)' = 'author(x) | committer(x)'

# 模式别名
'grep:x' = 'description(regex:x)'

# 附加 doc 供补全等功能显示
'pending()' = { definition = '(trunk()..@) & ~empty()', doc = '当前主线之外、并且有文件改动的提交' }
```

以上邮箱是示例，按自己的账号替换。编辑已有配置时合并到已有 `[revset-aliases]` 表，不要在同一个 TOML 文档里重复声明该表。

```sh
jj config edit --user
jj config list revset-aliases

jj log -r 'stack()'
jj log -r 'user("alice@example.com")'
jj log -r 'grep:"(?i)fix|bug"'
jj log -r 'pending()'
```

别名函数虽可按参数数量重载，但**覆盖内置函数按名字生效**：不要指望自定义 `ancestors(x)` 后，内置 `ancestors(x, depth)` 还能与它共存。别名也不是运行 shell 命令的宏。

### Alias descriptions / 另一种附带说明的写法

```toml
[revset-aliases]
'stack()'.definition = 'reachable(@, mutable())'
'stack()'.doc = '当前工作提交所在的可变连通栈'
```

这是前面写法的替代方案，不要同时重复定义同一个键。

### 修改不可变边界的示例

假设你已有本地 `release/*` 书签，希望把它们及其祖先也保护起来：

```toml
[revset-aliases]
'immutable_heads()' = 'builtin_immutable_heads() | bookmarks(glob:"release/*")'
```

不要通过重定义 `immutable()` 或 `mutable()` 修改写保护；这两个别名主要用于查询。也不要为了消掉错误直接移除所有保护，先检查自己覆盖了哪些来源。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#aliases) · [`cli/src/config/revsets.toml`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml) · [`cli/src/revset_util.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/revset_util.rs)


<a id="revset-default-config"></a>

## Built-in Aliases / 默认定义与命令选择范围

八个默认别名逐条列在本章后面的“别名”条目。它们来自固定版本的 `cli/src/config/revsets.toml`，可以被用户级、仓库级配置覆盖；下面不是在假定你的实际配置一定仍为默认值。

默认配置还包含 **11 个 `[revsets]` 键**。这些键是“命令未显式给出选择时从哪取值”，不是新增 revset 函数：

| 配置键 | v0.45.1 默认表达式 |
|---|---|
| `revsets.arrange` | `reachable(@, mutable())` |
| `revsets.converge` | `mutable() & divergent()` |
| `revsets.fix` | `reachable(@, mutable())` |
| `revsets.run` | `reachable(@, mutable())` |
| `revsets.simplify-parents` | `reachable(@, mutable())` |
| `revsets.log` | `builtin_log()` |
| `revsets.log-graph-prioritize` | `present(@)` |
| `revsets.op-diff-changes-in` | `mutable() \| immutable_heads()` |
| `revsets.sign` | `reachable(@, mutable())` |
| `revsets.bookmark-advance-to` | `@` |
| `revsets.bookmark-advance-from` | `heads(::to & bookmarks())` |

最后一项的 `to` 是 bookmark advance 求值时提供的上下文符号，**不是任何命令里都存在的全局 revset 符号**。`log-graph-prioritize` 用来影响图的优先展示分支，不是另一份全部筛选条件。

检查自己的有效配置：

```sh
jj config list revsets
jj config list revset-aliases
jj log -r 'trunk()'
jj log -r 'immutable_heads()'
```

没有加 `-r` 的命令受自身默认表达式和配置影响；复制教程前要区分“这个函数的含义”和“这个命令默认把什么传给函数”。

**Source / 来源：** [`cli/src/config/revsets.toml`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml) · [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#built-in-aliases)


<a id="revset-alias-trunk"></a>

## trunk()

**主线目标；仓库初始化时通常会写入更具体的覆盖定义。**

**Default / 默认定义**

```text
latest(remote_bookmarks(exact:"main", exact:"origin") | remote_bookmarks(exact:"master", exact:"origin") | remote_bookmarks(exact:"trunk", exact:"origin") | remote_bookmarks(exact:"main", exact:"upstream") | remote_bookmarks(exact:"master", exact:"upstream") | remote_bookmarks(exact:"trunk", exact:"upstream") | root())
```

**Notes / 注意：** 这里只列全局兜底。它对 main/master/trunk 与 origin/upstream 的候选取 committer 时间最新者，不按名字先后决定优先级；无候选时回到 root()。自定义后应始终恰好返回一个提交。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-builtin_log"></a>

## builtin_log()

**默认日志筛选逻辑。**

**Default / 默认定义**

```text
present(@) | ancestors(immutable_heads().., 2) | trunk()
```

**Notes / 注意：** 它是 [revsets].log 的默认值来源；ancestors(..., 2) 表示集合自身加一代祖先，不是只显示两个提交。jj log 显式传 -r 或路径时不能一概假定仍套此默认。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-builtin_immutable_heads"></a>

## builtin_immutable_heads()

**上游提供的不可变边界默认集合。**

**Default / 默认定义**

```text
trunk() | tags() | untracked_remote_bookmarks() | untracked_remote_tags()
```

**Notes / 注意：** 推荐保留该基准；需要扩展保护范围时覆盖 immutable_heads()，并可引用此基准。未跟踪远端引用默认纳入保护边界。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-immutable_heads"></a>

## immutable_heads()

**确定不可变集合边界的配置入口。**

**Default / 默认定义**

```text
builtin_immutable_heads()
```

**Notes / 注意：** 表示不可变集合的边界 heads，不是“从所有不可变提交中随便挑出一部分”。jj 将其祖先和 root() 视为不可变；不存在的可选符号可用 present() 包住，防止多个命令因解析失败而无法使用。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-immutable"></a>

## immutable()

**查询按默认规则应视为不可变的集合。**

**Default / 默认定义**

```text
::(immutable_heads() | root())
```

**Notes / 注意：** 不要覆盖它来改变写保护；只改查询别名不会改变 jj 内部真正的不可变检查。要改保护策略，用 immutable_heads()。root() 不能作为普通提交重写。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-mutable"></a>

## mutable()

**查询可变提交集合。**

**Default / 默认定义**

```text
~immutable()
```

**Notes / 注意：** 在当前搜索域内取不可变集合的补集。mutable 不等于尚未 push，也不等于属于当前用户；mine() 与 remote_bookmarks() 是不同维度。不要覆盖此别名来尝试绕过写保护。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-visible"></a>

## visible()

**当前视图的可见历史。**

**Default / 默认定义**

```text
::visible_heads()
```

**Notes / 注意：** 不显式引入隐藏历史时与 all() 相同；引入后 all() 可能更大，因此 visible() 可用于明确限制当前可见提交。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-hidden"></a>

## hidden()

**当前搜索域中相对于当前视图隐藏的提交。**

**Default / 默认定义**

```text
~visible()
```

**Notes / 注意：** 单独计算通常为空；它不是遍历对象库全部旧版本的函数。需要先显式引入旧 commit、change offset 或 operation 历史。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-connectivity"></a>

## Examples / reachable、connected、heads、roots 的区别

继续使用有合并和分叉的历史：

```text
E
| D
|/|
B C
|/
A
|
root()
```

D 的父是 B、C；E 的父是 B。

| 表达式 | 结果 | 意义 |
|---|---|---|
| `reachable(E, A..)` | `{E, D, C, B}` | 可以经 B 到 D，再到 C，所有节点仍在 A.. 内 |
| `reachable(E, B..)` | `{E}` | E 唯一相邻父 B 不在域内，不能跨过去 |
| `reachable(C, B..)` | `{D, C}` | C 与 D 在限定域内连通 |
| `reachable(A, A..)` | `{}` | 起点 A 不在域里 |
| `connected(E \| A)` | `{E, B, A}` | 只填 E 与 A 之间的祖先路径 |
| `connected(D \| A)` | `{D, C, B, A}` | D 到 A 的两条路径都填上 |
| `connected(B \| C)` | `{B, C}` | 不会因为共享祖先而补入 A |
| `heads(E \| B)` | `{E}` | B 是 E 的祖先 |
| `heads(E \| C)` | `{E, C}` | 二者互不为祖先 |
| `roots(E \| B)` | `{B}` | 保留所选集合的祖先边界 |
| `fork_point(E \| D)` | `{B}` | 最近公共祖先 |
| `fork_point(E \| C)` | `{A}` | 最近公共祖先 |
| `merge_point(B \| C)` | `{D}` | 最小公共后代 |

“选择当前工作的整组相关提交”常用 `reachable(@, mutable())`。它允许沿父和子双向走，可能把兄弟分支一起选入；若只想要当前提交的祖先线，使用 `::@ & mutable()`。

本页示例同样按独立 DAG 模型做了集合结果检查，不代表实际执行过 jj。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-log-markers"></a>

## Log markers / 日志图形、引用后缀与状态标签

本节说明 **v0.45.1 默认模板**。用户可以覆盖 `templates.log_node`、日志模板或选择 ASCII 图形；显示效果不是永久不变的语法规则。

### 提交图节点

| 默认 Unicode | ASCII 模式 | 含义 |
|---|---|---|
| `@` | `@` | 当前工作副本提交 |
| `◆` | `+` | 不可变提交 |
| `×` | `x` | 带文件冲突的提交（且未先匹配前两类） |
| `○` | `o` | 其他普通提交；它也可能是 merge |
| `~` | `~` | 图中省略了中间历史的占位节点，不是一个提交 |

默认判断顺序是 **当前工作副本 → 不可变 → 文件冲突 → 普通**。因此一个有冲突的当前工作副本仍可能显示 `@`，不可变的冲突提交仍可能显示 `◆`。判断冲突应结合 `(conflict)`、`jj status` 或 `conflicts()`。

`│`、`├`、`╮`、`╯` 等连接线表达父子关系，不是 revset 运算符。图中 `~` 表示省略；表达式里的 `~x` 才是补集。

`jj op log` 中的 `@` 指**当前 operation**，不是当前 commit。两种日志属于不同的 DAG。

### 引用名后缀

| 示例 | 含义 | 不是 |
|---|---|---|
| `feature*` | 本地引用与至少一个被跟踪远端的目标不一致 | shell 通配符、文件脏状态、可直接粘贴的额外名字部分 |
| `feature??` | 该引用的目标存在冲突 | 同一 change 的 divergent 标记 |
| `feature@origin` | origin 的远端跟踪引用 | 自动 fetch 后的实时服务器状态 |
| `review@` | 名为 review 的工作区所处提交 | 远端名为空的 bookmark |

`??` 优先于 `*` 显示；不要把二者再一起附加到书签名。显示在日志里的 `feature*` 通常应以 `feature` 查询，而不是把星号也抄进去。

### 提交状态文字

| 标记 | 含义 | 常用对应查询 |
|---|---|---|
| `(empty)` | 没有文件变更 | `empty()` |
| `(no description set)` | 没有提交说明 | `description("")` |
| `(conflict)` | 文件树中有冲突 | `conflicts()` |
| `(divergent)` | 同一 change 有多个可见版本 | `divergent()` |
| `(hidden)` | 此提交不属于当前可见历史 | 显式引入历史后用 `hidden()` |
| change ID 后的 `/0`、`/1` | 版本偏移，用于区分隐藏或分歧版本 | `CHANGE_ID/0` |

`hidden` 与 `divergent` 的标签显示也有优先关系：隐藏版本不会仅因存在旧版本就造成可见 change 分歧。

### bookmark / tag list 与签名标记

引用列表中的 `(conflicted)` 和缩进的 `-` / `+` 行，表示冲突引用的移除侧/新增侧目标；不是 diff 中删除/新增的文件行，也不是 `x-` / `x+` revset 运算。

列表里的 `(deleted)` 表示本地目标已删除；`(not created yet)` 是相应跟踪远端目标尚不存在。若显示 `ahead by ...` / `behind by ...`，应按该条远端引用相对于本地跟踪目标的方向读，不能把所有列表都当成本地相对远端。

开启签名显示时，默认短签名为 `[✓︎]`（good）、`[?]`（unknown）、`[x]`（其他状态）。这是验证状态展示；`signed()` 只筛选签名存在，不能替代验证和信任策略。

**Source / 来源：** [`cli/src/config/templates.toml`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/templates.toml#L454-L595) · [`cli/src/commit_templater.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commit_templater.rs#L1515-L1678) · [`cli/src/config/templates.toml`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/templates.toml#L361-L412)


<a id="revset-migration"></a>

## Version notes / 旧教程迁移与上一版勘误

| 旧写法或常见误解 | v0.45.1 的状态 / 应如何写 |
|---|---|
| `all:表达式` | 已移除；0.38.0 起不再支持。直接传合法集合表达式，是否允许多目标由该命令参数决定 |
| `all()` | 仍是合法的全部集合函数，与上一行无关 |
| `diff_contains(text, files)` | 仍注册，但会发弃用警告；改用 `diff_lines(text, files)` |
| `git_head()` | 0.43.0 已移除，不应写进本版函数清单 |
| `git_refs()` | 0.43.0 已移除；按意图使用 bookmarks/tags/remote_* 等，不存在对所有场景都等价的机械替换 |
| `refs/heads/main` 的 Git 风格符号解析 | 0.43.0 已移除这一特殊解析；用本地 `main` 或显式 `bookmarks(exact:"main")` 等 |
| `x^` | 不是当前父提交语法；改用 `x-` |
| `x:y`、`:x`、`x:` | 不是有效 DAG 范围；按含义改成 `x::y`、`::x`、`x::` |
| `x + y` / `x - y` | 不是并集/差集；用 `x \| y` / `x ~ y` |
| `HEAD~3` | 不要套 Git 祖先语法；如想当前工作提交往前三代，用 `@---` 或 `parents(@, 3)` |
| `A...B` | 不要当成 jj 的内置对称差；用 `(A..B) \| (B..A)` |
| `description("fix")` | 默认 glob，并非“包含 fix”；明确用 `description(substring:"fix")` |
| 以 `mutable()` 判断“未推送” | 不可靠；它是不可变策略的补集，不是远端状态 |
| 以 `signed()` 判断“可信签名” | 不可靠；它仅判断签名存在 |

共置 Git 工作区里，某些旧 `git_head()` 用途可以通过 `first_parent(@)` 表达，但不要把它当成适用于所有仓库状态的一对一替换。`HEAD` 也不是本参考承诺始终存在的内置别名；官方别名示例中的 HEAD 是用户自己配置的。

### 此次纠正上一份手册的内容

原 Revset 速查曾建议部分多修订操作可使用 `all:`。该建议不适用于固定的 v0.45.1，已从更新版 Markdown 和 HTML 中删除；TXT 也已追加相应版本警告。

函数注册表里的 `diff_contains` 仍映射到 `diff_lines`，尽管注释有 “Remove in jj 0.44+” 的 TODO。清单按**实际注册代码**而不是 TODO 的计划日期判断。

不是看到解析器里有一个 token 就说明语法可用：`^`、单冒号旧范围、二元 `+`/`-` 等在源码中可能只是为了给出更友好的迁移错误。

**Source / 来源：** [`CHANGELOG.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/CHANGELOG.md) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1088-L1129) · [`lib/src/revset.pest`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.pest) · [`lib/src/revset_parser.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset_parser.rs)


<a id="revset-recipes-intro"></a>

## Examples / 20 个可组合的查询场景

以下场景大部分只演示查询，避免把复杂集合直接交给 destructive 命令。第 14 个包含 `git fetch`，会联网并更新仓库状态，已单独标注。

示例中的 main、feature、origin、src 等名称不保证你的仓库存在；函数筛选到空集合可能是正常结果，不一定是命令失败。引用名、路径、邮箱和固定 ID 都应按仓库实际情况替换。

对即将用于修改操作的表达式，建议先记录并预览：

```sh
REVS='mine() & mutable()'
jj log -r "$REVS"
```

之后再按原工作流手册选择 `rebase`、`squash`、`abandon` 等具体操作。**revset 选中几个提交，不等于操作最终只会创建或重写几个提交对象**；后代重写、书签更新和不可变限制仍由命令决定。两次命令间 `@`、远端引用或仓库视图变化时，动态表达式的结果也可能变化。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md) · [`docs/glossary.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/glossary.md#rewrite)


<a id="revset-recipe-01"></a>

## R01 · 查看当前所在的可变提交栈

**场景：** 包含当前工作相关的祖先、后代和域内兄弟分支。

```sh
jj log -r 'reachable(@, mutable())'
```

**注意：** 这是限定域内的双向连通集合；需要只看祖先时改为 ::@ & mutable()。修改命令采用这个集合前先确认没有不想动的兄弟分支。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-02"></a>

## R02 · 查看当前主线之外的非空改动

**场景：** 只看 @ 已包含而 trunk 尚未包含、且有文件修改的提交。

```sh
jj log -r '(trunk()..@) & ~empty()'
```

**注意：** 主线由 trunk() 的有效配置决定；@ 如果是非空工作提交也会被包括。不是所有仓库里的未发布提交。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-03"></a>

## R03 · 查我的可变工作

**场景：** 按 author 邮箱筛出自己的可变提交。

```sh
jj log -r 'mine() & mutable()'
```

**注意：** 先核对 user.email。这里只组合作者身份与不可变策略，不包含“是否已经 push”的判断。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-04"></a>

## R04 · 按代数查看历史，而不是按条数

**场景：** 对比所有父路径与第一父链。

```sh
jj log -r 'ancestors(@, 5)'
jj log -r 'first_ancestors(@, 5)'
```

**注意：** 都包括 @，最多再向前四代。合并图第一条可能远多于五个提交；若只要 committer 时间最新五个，用 latest(::@, 5)。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-05"></a>

## R05 · 按标题约定查找修复

**场景：** 筛选以 fix: 开头，或以 fix(scope): 开头的标题。

```sh
jj log -r 'subject(regex:"^fix([(][^)]*[)])?:")'
```

**注意：** 使用字符组 [(]、[)] 表示字面括号，避免 shell 与 revset 双层转义。更简单但宽松的选择是 subject(glob:"fix*")。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-06"></a>

## R06 · 限定一个明确的作者时间区间

**场景：** 查询 +08:00 时区 2026 年 9 月的作者时间。

```sh
jj log -r 'author_date(after:"2026-09-01T00:00:00+08:00") & author_date(before:"2026-10-01T00:00:00+08:00")'
```

**注意：** after 包含下界，before 排除上界。复现报告时优先使用这种绝对边界，不用随执行时间变化的 yesterday。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-07"></a>

## R07 · 调查最近发生过重写的候选

**场景：** 按 committer 时间看近期提交对象。

```sh
jj log -r 'committer_date(after:"2 days ago") & mutable()'
```

**注意：** 它筛选最近生成的对象，不独立证明每条都经历过重写；新提交也会匹配。与 author_date 对照更有意义。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-08"></a>

## R08 · 查看某个 Rust 模块的变更历史

**场景：** 把路径锚定到工作区根，不受当前所在子目录影响。

```sh
jj log -r '::@ & files(root-file:"src/http.rs")'
```

**注意：** src/http.rs 是示例路径。只查询该路径上的变更，不能据此断言已跨所有重命名自动追溯旧名字。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-09"></a>

## R09 · 找出 TODO 是什么时候加进来的

**场景：** 只搜索 src 下 diff 的新增侧。

```sh
jj log -r '::@ & diff_lines_added(substring:"TODO", root:"src")'
```

**注意：** 已有文件中的未变动 TODO 不会匹配。需要同时看添加与删除，改用 diff_lines()。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-10"></a>

## R10 · 查找某个旧 API 的删除

**场景：** 搜索删除侧，避免被相同文本的新增误导。

```sh
jj log -r '::@ & diff_lines_removed(substring:"old_api", root:"src")'
```

**注意：** old_api 是示例文本，src 是示例目录。匹配的是单行变更文本，不做语义级 Rust 符号解析。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-11"></a>

## R11 · 只查看当前可变历史里的文件冲突

**场景：** 排除不相关的不可变历史。

```sh
jj log -r 'conflicts() & mutable()'
```

**注意：** 结果反映文件树冲突，不反映书签目标冲突；后者查看 jj bookmark list。可变范围内有冲突的后代也可能被选入。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-12"></a>

## R12 · 定位 change 分歧

**场景：** 先查看所有分歧版本，再用 ID 或 offset 指定目标。

```sh
jj log -r 'divergent() & mutable()'
```

**注意：** 之后可用 change_id(实际ID) 查看某个分歧集合；用实际ID/0、实际ID/1 或完整 commit ID 精确定位。不要仅凭新旧顺序自动删除某一版本。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-13"></a>

## R13 · 预览空白草稿候选

**场景：** 找出自己没有说明也没有文件修改、且不是任何工作区当前目标的可变提交。

```sh
jj log -r '(mine() & mutable() & empty() & description("")) ~ working_copies()'
```

**注意：** 这只是审查候选，不等于可安全 abandon。空 merge、被书签引用的提交也可能有用途，清理前仍需核对图关系。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-14"></a>

## R14 · 看当前历史相对 origin 已知书签的差集

**场景：** 先更新 origin 的本地记录，再比较祖先闭包。

```sh
jj git fetch --remote origin
jj log -r 'remote_bookmarks(remote="origin")..@'
```

**注意：** fetch 会联网并更新仓库视图；本例不是纯只读查询。差集只依据 origin 书签，不代表远端所有对象或标签完全没有这些提交。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-15"></a>

## R15 · 总览本地引用与工作区边界

**场景：** 集中查看书签、标签和所有工作副本。

```sh
jj log -r 'bookmarks() | tags() | working_copies()'
```

**注意：** 这里仅选引用目标而不是它们全部祖先；日志可能用 ~ 表示被省略的中间历史。需要祖先闭包时写 ::(bookmarks() | tags() | working_copies())。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-16"></a>

## R16 · 找当前工作与主线的共同基点

**场景：** 找最近公共祖先，而不是凭时间猜分叉点。

```sh
jj log -r 'fork_point(@ | trunk())'
```

**注意：** 复杂交叉合并历史可能有多个最近公共祖先；要交给单目标命令时先检查，不能直接假定唯一。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-17"></a>

## R17 · 找两个 feature 最早共同进入哪里的历史

**场景：** 寻找共同后代的边界。

```sh
jj log -r 'merge_point(bookmarks(exact:"feature/a") | bookmarks(exact:"feature/b"))'
```

**注意：** 两个书签名是示例，先确认均存在。某个名称不匹配时 bookmarks() 返回空，可能只剩另一个输入；正式脚本应分别加 exactly(..., 1) 断言。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-18"></a>

## R18 · 兼容 main/master，但不吞掉歧义

**场景：** 按顺序选择存在的远端目标。

```sh
jj log -r 'coalesce(present(main@origin), present(master@origin), root())'
```

**注意：** present() 仅处理缺失，coalesce() 选第一个非空；不是按最新时间选择。main 的冲突或歧义不会被当成无结果自动忽略。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-19"></a>

## R19 · 从旧 operation 查看当前已经隐藏的提交

**场景：** 查看上一个操作的历史与当前可见历史的差别。

```sh
jj op log
jj --ignore-working-copy log -r 'hidden() & at_operation(@-, all())'
```

**注意：** 第一个参数 @- 是 operation 的父。并发操作历史可能分叉，@- 也可能无法唯一选择；需要稳定复查时用实际 operation ID 替换。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-20"></a>

## R20 · 给脚本的单目标加数量断言

**场景：** 不让一个本应单目标的查询悄悄变成多个目标或空。

```sh
jj log -r 'exactly(bookmarks(exact:"feature"), 1)'
```

**注意：** 示例要求本地 feature 书签存在且只有一个目标；否则故意报错。这比 latest(..., 1) 安全，因为后者会掩盖多目标事实。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-sources"></a>

## Sources / 固定版本源码、覆盖口径与验证限制

**函数清单口径：** `docs/revsets.md` 的 Functions 部分列出 54 个正式文档名称；`lib/src/revset.rs` 的 `BUILTIN_FUNCTION_MAP` 另外保留 `diff_contains`，因此记录 55 个注册名称。弃用别名不是一种新的功能。默认配置中的 8 个 revset 别名单独列出，没有混进 55 的计数。

**交叉校对：** 函数签名与可选参数对照 Rust 注册代码；运算符对照解析器/grammar；日期边界对照 time_util；别名对照固定版本 TOML；显示符号对照模板与 CommitRef formatter；已移除语法对照 CHANGELOG。覆盖清单保存在 `revsets-functions.json`、`revsets-aliases.json` 和 `revsets-validation.json`。

| 源码文件 | 主要用途 |
|---|---|
| `docs/revsets.md` | 官方语言参考、函数签名、符号、示例 |
| `lib/src/revset.rs` | 55 个注册名称、默认值、参数解析和求值 |
| `lib/src/revset_parser.rs` / `lib/src/revset.pest` | 优先级、语法、兼容错误诊断 |
| `lib/src/dsl_util.rs` | 位置实参与命名实参检查 |
| `cli/src/config/revsets.toml` | 8 个默认别名、11 个 revsets 配置键 |
| `cli/src/revset_util.rs` | CLI revset 求值、真正的不可变策略 |
| `lib/src/time_util.rs` | 日期边界、时区解析及测试 |
| `docs/filesets.md` | files()/diff_lines() 的 fileset 实参 |
| `docs/glossary.md` | change offset、可见性、author/committer |
| `cli/src/config/templates.toml` | 日志节点、状态、签名与引用列表显示 |
| `cli/src/commit_templater.rs` | 引用后缀 * / ?? 的具体格式化 |
| `CHANGELOG.md` | all:、git_head()/git_refs() 等移除记录 |

**未做的验证：** 没有在本环境安装或编译 jj，没有在实际仓库执行这些命令，没有保存一个经校验的上游完整源码快照。源码通过在线固定 tag 查阅；不把网页阅读说成本地 AST 全量审计。JSON 覆盖检查比较的是由源码逐项抄录的名称清单，DAG 示例测试使用独立集合模型。

HTML 的搜索、分类、锚点、移动端布局及无外部资源加载检查，属于文档本身的验证，不是 jj 命令行为测试。具体结果查看附带验证记录。

本补篇为非官方中文整理。上游项目归 The Jujutsu Authors 所有，采用 Apache-2.0；此处保留源码链接和来源说明。中文解释与工作示例为本次重述整理，不把可配置默认值宣传成永久不变的规范。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs) · [`lib/src/revset_parser.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset_parser.rs) · [`lib/src/revset.pest`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.pest) · [`lib/src/dsl_util.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/dsl_util.rs) · [`cli/src/config/revsets.toml`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml) · [`cli/src/revset_util.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/revset_util.rs) · [`lib/src/time_util.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/time_util.rs) · [`docs/filesets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/filesets.md) · [`docs/glossary.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/glossary.md) · [`cli/src/config/templates.toml`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/templates.toml) · [`cli/src/commit_templater.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commit_templater.rs) · [`CHANGELOG.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/CHANGELOG.md)


