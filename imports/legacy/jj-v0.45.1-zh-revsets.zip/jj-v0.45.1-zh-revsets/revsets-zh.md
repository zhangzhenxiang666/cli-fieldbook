# jj v0.45.1 Revset 中文完整参考

**固定版本：v0.45.1 · 查证日期：2026-09-17 · Revset 补充修订版**

## 导航

[可见、隐藏与搜索域](#revset-hidden) | [提交符号、工作区与 change offset](#revset-symbols) | [全部运算符与优先级](#revset-operators) | [函数签名、默认值与参数类型](#revset-function-syntax) | [字符串模式与逻辑组合](#revset-string-patterns) | [日期边界、时区与可复现查询](#revset-date-patterns) | [自定义符号、函数与模式别名](#revset-aliases) | [日志图形、引用后缀与状态标签](#revset-log-markers) | [旧教程迁移与上一版勘误](#revset-migration) | [20 个可组合的查询场景](#revset-recipes-intro) | [固定版本源码、覆盖口径与验证限制](#revset-sources)

### 函数索引

| 分类 | 函数 |
|---|---|
| 图遍历 | [`parents()`](#revset-fn-parents)、[`children()`](#revset-fn-children)、[`ancestors()`](#revset-fn-ancestors)、[`descendants()`](#revset-fn-descendants)、[`first_parent()`](#revset-fn-first_parent)、[`first_ancestors()`](#revset-fn-first_ancestors)、[`reachable()`](#revset-fn-reachable)、[`connected()`](#revset-fn-connected) |
| 集合与选择 | [`all()`](#revset-fn-all)、[`none()`](#revset-fn-none)、[`visible_heads()`](#revset-fn-visible_heads)、[`root()`](#revset-fn-root)、[`heads()`](#revset-fn-heads)、[`roots()`](#revset-fn-roots)、[`latest()`](#revset-fn-latest)、[`fork_point()`](#revset-fn-fork_point)、[`merge_point()`](#revset-fn-merge_point)、[`bisect()`](#revset-fn-bisect)、[`exactly()`](#revset-fn-exactly)、[`working_copies()`](#revset-fn-working_copies) |
| ID 与引用 | [`change_id()`](#revset-fn-change_id)、[`commit_id()`](#revset-fn-commit_id)、[`bookmarks()`](#revset-fn-bookmarks)、[`remote_bookmarks()`](#revset-fn-remote_bookmarks)、[`tracked_remote_bookmarks()`](#revset-fn-tracked_remote_bookmarks)、[`untracked_remote_bookmarks()`](#revset-fn-untracked_remote_bookmarks)、[`tags()`](#revset-fn-tags)、[`remote_tags()`](#revset-fn-remote_tags)、[`tracked_remote_tags()`](#revset-fn-tracked_remote_tags)、[`untracked_remote_tags()`](#revset-fn-untracked_remote_tags) |
| 结构与状态 | [`merges()`](#revset-fn-merges)、[`forks()`](#revset-fn-forks)、[`signed()`](#revset-fn-signed)、[`empty()`](#revset-fn-empty)、[`conflicts()`](#revset-fn-conflicts)、[`divergent()`](#revset-fn-divergent) |
| 元数据过滤 | [`description()`](#revset-fn-description)、[`subject()`](#revset-fn-subject)、[`author()`](#revset-fn-author)、[`author_name()`](#revset-fn-author_name)、[`author_email()`](#revset-fn-author_email)、[`author_date()`](#revset-fn-author_date)、[`mine()`](#revset-fn-mine)、[`committer()`](#revset-fn-committer)、[`committer_name()`](#revset-fn-committer_name)、[`committer_email()`](#revset-fn-committer_email)、[`committer_date()`](#revset-fn-committer_date) |
| 内容与路径 | [`files()`](#revset-fn-files)、[`diff_lines()`](#revset-fn-diff_lines)、[`diff_lines_added()`](#revset-fn-diff_lines_added)、[`diff_lines_removed()`](#revset-fn-diff_lines_removed) |
| 容错与历史 | [`present()`](#revset-fn-present)、[`coalesce()`](#revset-fn-coalesce)、[`at_operation()`](#revset-fn-at_operation) |
| 弃用兼容入口 | [`diff_contains()`](#revset-fn-diff_contains) |

### 默认别名索引

[`trunk()`](#revset-alias-trunk)、[`builtin_log()`](#revset-alias-builtin_log)、[`builtin_immutable_heads()`](#revset-alias-builtin_immutable_heads)、[`immutable_heads()`](#revset-alias-immutable_heads)、[`immutable()`](#revset-alias-immutable)、[`mutable()`](#revset-alias-mutable)、[`visible()`](#revset-alias-visible)、[`hidden()`](#revset-alias-hidden)

<a id="revset-intro"></a>

## Revsets / 阅读说明与类型边界

本补篇固定到 **jj v0.45.1**，查证日期 **2026-09-17**。保留官方参考的章节顺序、函数名、签名及语法拼写；解释改为中文，并加上源码校对、边界条件和实际场景。它是结构化中文参考，不是对 `jj help` 的逐字终端转录。

覆盖 **54 个官方文档函数 + 1 个仍注册的弃用兼容名 `diff_contains()` + 8 个默认 revset 别名**。函数与别名分开计数：`trunk()`、`mutable()` 不是 Rust 内置函数；`root()`、`ancestors()` 才是。本参考只覆盖上游默认实现，不包含自定义编译扩展或用户自定义别名。

| 所在位置 | 输入的是什么 | 例子 |
|---|---|---|
| `jj log -r '…'` | revset：提交集合表达式 | `mine() & mutable()` |
| `files(…)` 的实参 | fileset：路径集合表达式 | `root:"src" ~ root:"src/generated"` |
| `description(…)` 的实参 | 字符串模式 | `substring:"TODO"` |
| `author_date(…)` 的实参 | 日期模式 | `after:"2026-09-01"` |
| `at_operation(op, x)` 的第一个实参 | operation 选择表达式 | `@-` |
| `jj log -T '…'` | template：格式化输出语言 | 不属于 revset |
| `jj log` 图形中的 `◆`、`×` | 输出标记 | 不能作为提交表达式输入 |

Revset 是“返回一组提交”的语言，不是顺序执行脚本。集合中的元素是提交对象，同一目标重复出现会去重。表达式选中了哪些提交，与最终命令是否会重写其后代，是两个问题。

单提交命令仍要求恰好一个结果；集合参数按各命令自身声明处理。**v0.45.1 不支持 `all:` 修饰符**。需要验证唯一性时用 `exactly(x, 1)`，但不能用它绕开命令本身的限制。

所有查询示例都可以先用 `jj log -r '表达式'` 预览。普通 `jj log` 可能快照当前磁盘改动；`jj --ignore-working-copy log ...` 可避免这一步，但也因此看不到尚未快照的改动。

验证范围：根据固定 tag 的官方文档、Rust 注册表、解析器、默认配置与日志模板核对。未安装/编译该版本 jj，未把示例标成实际仓库运行通过。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs) · [`lib/src/revset_parser.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset_parser.rs) · [`CHANGELOG.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/CHANGELOG.md)


<a id="revset-hidden"></a>

## Hidden revisions / 可见、隐藏与搜索域

通常只搜索当前视图的**可见提交**及其祖先。被重写或 abandon 的旧版本可能仍存在于仓库对象中，但不自动参与普通查询。

显式引用隐藏 commit ID、`change_id/offset`、相关远端符号，或者使用 `at_operation()`，可把对应历史带入搜索范围。隐藏提交的祖先也会参与 `all()`、`~x`、`x..` 等运算。因此这些集合不是脱离表达式上下文的固定全集。

```text
all()        当前表达式的搜索域
visible()    ::visible_heads()，当前视图的可见提交
hidden()     ~visible()，搜索域中不属于当前可见历史的提交
```

`hidden()` 单独查询通常为空，**不等于“列出所有曾经出现过的提交”**。`all()` 也不能用来保证遍历所有旧版本或垃圾回收后已不存在的对象。

下面两组表达式展示“显式引入”和“限定结果”的区别。将 `COMMIT_ID` 换成真实的隐藏提交 ID：

```sh
# 明确查询某个旧对象
jj log -r 'commit_id(COMMIT_ID)'

# 只留下该对象的祖先中目前隐藏的部分
jj log -r 'hidden() & ::commit_id(COMMIT_ID)'

# 在上一个 operation 的视图中看全部当时可见历史
jj --ignore-working-copy log -r 'at_operation(@-, all())'

# 从该操作历史中挑出现在隐藏的提交
jj --ignore-working-copy log -r 'hidden() & at_operation(@-, all())'
```

`at_operation(op, x)` 对搜索域的扩展不局限于 x 的最终结果；它会带入该 operation 当时可见的历史。最终要哪些元素，仍要用交集、差集等明确限制。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#hidden-revisions) · [`docs/glossary.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/glossary.md#visible-commits) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs)


<a id="revset-symbols"></a>

## Symbols / 提交符号、工作区与 change offset

| 符号 | 含义 | 注意事项 |
|---|---|---|
| `@` | 当前 workspace 的工作副本提交 | 不是“当前 bookmark” |
| `review@` | 名为 review 的 workspace 的工作副本提交 | 名字只是示例，工作区必须存在 |
| `main` | 名为 main 的标签或书签等符号 | 先匹配标签，再匹配书签，最后匹配 ID |
| `main@origin` | 本地记录的 origin 远端标签或书签目标 | 不是实时远端查询；标签优先 |
| `main@git` | 特殊 Git 跟踪引用 | `git` 不是必须存在于网络上的 remote |
| 完整 commit ID / 唯一前缀 | 指向特定提交对象 | 前缀不唯一会报错 |
| 完整 change ID / 唯一前缀 | 指向该 change 的可见提交 | 分歧导致多目标时，裸符号报错 |
| `xyz/0`、`xyz/1` | 同一 change 的版本偏移 | 最新为 0；1 是之前的版本，不是父提交 |
| `"x-"` | 名字本身为 x- 的符号 | 不加表达式内引号时，`x-` 表示 x 的父 |

`xyz` 仅是 change ID 的示意，请替换成日志中的真实 ID。offset 会随着版本演进变化，**不是持久稳定的对象标识**；需要记录精确快照时保存完整 commit ID。

### Priority / 符号解析优先级

同名时按 **标签 → 书签 → commit/change ID** 解析。脚本中需要去歧义时使用函数：

```sh
jj log -r 'tags(exact:"release")'
jj log -r 'bookmarks(exact:"release")'
jj log -r 'commit_id(COMMIT_ID)'
jj log -r 'change_id(CHANGE_ID)'
```

最后两条中的大写词是待替换占位符，不是可直接使用的合法 ID。

“默认日志缩写多少位”不是 revset 语法保证。以当前仓库实际能唯一解析的前缀为准；已有 ID 前缀以后也可能因为新增对象而不再唯一。

### Quoting / 两层引号

```sh
# 外层单引号防 shell 把 |、&、* 等解释为管道或通配符
jj log -r 'mine() & (trunk()..@)'

# 外层交给 shell，内层保留给 revset 解析器
jj log -r '"x-"'

# 字符串模式与内容在 revset 内用双引号
jj log -r 'subject(substring:"fix parser")'
```

名字包含空格、运算符样字符时要特别注意。`x-y` 可能是一个书签名字；不要把它当作集合差集。`\` 换行写法因 shell 而异，本手册使用单行 POSIX shell 示例。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#symbols) · [`docs/glossary.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/glossary.md#change-offset) · [`lib/src/revset.pest`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.pest)


<a id="revset-operators"></a>

## Operators / 全部运算符与优先级

下面从**结合最紧到最松**排列。`x`、`y`、`z` 可为任意 revset，而不仅是单个 ID。

| 优先级 | 语法 | 中文含义 / 等价关系 |
|---|---|---|
| 1 | `f(x)` | 函数调用 |
| 2 | `x-`、`x+` | 直接父、直接子；可连续使用 `x--`、`x++` |
| 3 | `p:x` | 字符串/日期模式，或名为 p 的模式别名 |
| 4 | `::x` | x 与全部祖先；`ancestors(x)` |
| 4 | `x::` | x 与全部后代；`descendants(x)` |
| 4 | `x::y` | x 的后代 ∩ y 的祖先；`x:: & ::y` |
| 4 | `..x` | x 的祖先去掉虚拟根；`root()..x` |
| 4 | `x..` | 搜索域中不属于 x 祖先的提交；`~::x` |
| 4 | `x..y` | y 的祖先减去 x 的祖先；`::y ~ ::x` |
| 4 | `::` | `all()`，受搜索域扩展规则影响 |
| 4 | `..` | 搜索域去掉虚拟根；`~root()` |
| 5 | `~x` | 补集；搜索域中不属于 x 的提交 |
| 6 | `x & y` | 交集 |
| 6 | `x ~ y` | 差集 |
| 7 | `x \| y` | 并集 |

同优先级的中缀集合运算**从左到右**。括号可以改变顺序：

```text
x | y & z       = x | (y & z)
x ~ y & z       = (x ~ y) & z
x ~ (y & z)     需要显式括号，不能省略
~x::            = ~(x::)
(@ | trunk())-  先取集合，再取各自父提交
```

范围运算叠加要用括号明确层级，不要写含混的 `A::B::C`。`p:x` 只在相应模式/别名上下文成立；`A:B` **不是**有效的简写 DAG 范围。

### 区分“所有祖先”“精确第 N 代”“前 N 代”

```text
@---                恰好沿三条父边可到达的提交
parents(@, 3)       与 @--- 等价
ancestors(@, 3)     @ + 直接父 + 再上一代，不是 @ 的第三代父
first_parent(@, 3)  恰好沿第一父链三步
first_ancestors(@)  沿第一父链一直回溯，并包括 @
```

merge 情况下 `@-`、`@--` 可能返回多个结果。`@+` 是子提交关系，不是操作历史里的“下一次命令”，也不是撤销/重做。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#operators) · [`lib/src/revset_parser.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset_parser.rs) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L776-L839)


<a id="revset-ranges"></a>

## Examples / 用同一张图分清 :: 与 ..

以下字母代表提交，不代表顺序编号。图从下往上推进，D 有 B、C 两个父：

```text
      D
     / \
    B   C
     \ /
      A
      |
    root()
```

| 表达式 | 结果集合 | 理由 |
|---|---|---|
| `D-` | `{B, C}` | 合并的两个直接父 |
| `D--` | `{A}` | 两条父路径最后去重 |
| `::B` | `{root(), A, B}` | 包含自身的祖先 |
| `..B` | `{A, B}` | 相同祖先但排除虚拟根 |
| `B::` | `{B, D}` | 从 B 向后走 |
| `B..` | `{C, D}` | 排除 B 的全部祖先，不是只向后走 |
| `B::D` | `{B, D}` | 在 B 的后代与 D 的祖先交集中 |
| `B..D` | `{C, D}` | D 的祖先减去 B 的祖先 |
| `B::C` | `{}` | B 不是 C 的祖先 |
| `B..C` | `{C}` | 不要求 B、C 存在祖先关系 |
| `D..` | `{}` | 这张图所有提交都是 D 的祖先 |
| `(B \| C)..` | `{D}` | 同时排除两组祖先 |
| `B.. \| C..` | `{B, C, D}` | 与上一行不同 |

集合顺序不重要。核心区别：

```text
B::D  ——“沿着 B 到 D 的祖先关系，取路径上的提交”
B..D  ——“D 已包含，而 B 还没有包含的提交”
```

因此，整理主线以外的历史时常用 `trunk()..@`；但不要把它解释为“主线与 @ 之间的一条直线”。

还有一个常见代数陷阱：

```text
(A | B).. = A.. & B..
(A | B).. != A.. | B..
```

这是从祖先并集取补集所产生的交集关系。此页结果已用独立的小型 DAG 集合模型检查，但这不是执行 jj 二进制的结果。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#operators)


<a id="revset-function-syntax"></a>

## Functions / 函数签名、默认值与参数类型

后文每个条目保留 `Signature / Arguments / Returns / Examples / Notes / Source` 字段，中文说明不改参数名和语法。

签名中的 `[arg]` 表示**可选实参**，输入时不要带方括号。`revsets...` 表示可变数量实参。绝大多数函数是位置参数，不能照着 Rust/Python 的习惯给任何参数加名字。

```text
ancestors(@, 3)          正确
ancestors(@, depth=3)    不支持这种命名实参
exactly(@, 1)            正确
exactly(@, count=1)      不支持这种命名实参
```

远端引用家族明确支持第二个参数的 `remote=`：

```text
remote_bookmarks()
remote_bookmarks("main")
remote_bookmarks("main", "origin")
remote_bookmarks("main", remote="origin")
remote_bookmarks(remote="origin")
```

`remote_tags()` 及四个 tracked/untracked 函数同理。不支持随意造出 `name=` 参数。

### 参数不是同一种语言

```text
ancestors(mine() & mutable(), 3)       第一参数是提交集合
bookmarks(glob:"feature/*")           第一参数是字符串匹配条件
files(root:"src" ~ root:"src/tmp")     第一参数是路径集合
author_date(after:"2026-09-01")        第一参数是日期边界
at_operation(@-, @)                  第一参数是 operation，第二个是 commit revset
```

`files(all())` 的 `all()` 属于 fileset，表示所有路径；最外层的 `all()` 属于 revset，表示搜索域里的全部提交。不要用“函数同名”推断二者类型相同。

### 默认值速记

| 家族 | 省略可选参数的行为 | 0 的行为 |
|---|---|---|
| parents / children / first_parent | depth=1 | 返回来源 x |
| ancestors / descendants / first_ancestors | 不限深度 | 返回空集合 |
| latest | count=1 | 返回空集合 |
| bookmarks / tags | 匹配全部本地对应引用 | 不适用 |
| remote_* / tracked_* / untracked_* | 全部默认远端范围，排除特殊 git | 不适用 |
| diff_lines / added / removed | 搜索全部修改文件 | 不适用 |

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L776-L1164) · [`lib/src/dsl_util.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/dsl_util.rs#L139-L198)


<a id="revset-fn-parents"></a>

## parents(x, [depth])

**取恰好指定代数的父提交。**

**Signature / 签名**

```text
parents(x, [depth])
```

**Arguments / 参数：** x：任意 revset；depth：可选非负整数，默认 1。

**Returns / 返回：** 距离来源恰好 depth 条父边所能到达的提交集合。

**Examples / 示例**

```sh
jj log -r 'parents(@, 2)'
```

**Notes / 注意：** depth=0 返回 x；parents(x, 3) 等价于 x---。合并提交有多个父，结果不保证只有一个；不同长度路径可能到达同一提交。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L777) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-children"></a>

## children(x, [depth])

**取恰好指定代数的子提交。**

**Signature / 签名**

```text
children(x, [depth])
```

**Arguments / 参数：** x：来源集合；depth：可选非负整数，默认 1。

**Returns / 返回：** 距离来源恰好 depth 条子边所能到达的集合。

**Examples / 示例**

```sh
jj log -r 'children(@-, 1)'
```

**Notes / 注意：** depth=0 返回 x；children(x, 3) 等价于 x+++。不是“向后查看任意三代”，也不保证只有一个子提交。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L787) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-ancestors"></a>

## ancestors(x, [depth])

**取自身及祖先，可限定包含多少代。**

**Signature / 签名**

```text
ancestors(x, [depth])
```

**Arguments / 参数：** x：来源集合；depth：可选非负整数；省略时沿所有父边不限深度。

**Returns / 返回：** 遍历代数落在 0 <= generation < depth 内的提交；省略 depth 时返回 ::x。

**Examples / 示例**

```sh
jj log -r 'ancestors(@, 5)'
```

**Notes / 注意：** 与 parents 的计数方式不同：ancestors(x, 0) 为空；depth=1 只有 x；depth=2 包含 x 和直接父。合并历史每代可有多个提交。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L797) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-descendants"></a>

## descendants(x, [depth])

**取自身及后代，可限定包含多少代。**

**Signature / 签名**

```text
descendants(x, [depth])
```

**Arguments / 参数：** x：来源集合；depth：可选非负整数；省略时不限深度。

**Returns / 返回：** 遍历代数在 [0, depth) 内的提交；省略 depth 时等价于 x::。

**Examples / 示例**

```sh
jj log -r 'descendants(trunk(), 2)'
```

**Notes / 注意：** depth=0 为空，depth=1 只有 x，depth=2 再包含直接子。搜索范围仍受可见性与显式隐藏提交扩展规则影响。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L808) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-first_parent"></a>

## first_parent(x, [depth])

**每一层只沿第一个父提交前进。**

**Signature / 签名**

```text
first_parent(x, [depth])
```

**Arguments / 参数：** x：来源集合；depth：可选非负整数，默认 1。

**Returns / 返回：** 沿第一父链前进恰好 depth 步后的集合。

**Examples / 示例**

```sh
jj log -r 'first_parent(@, 2)'
```

**Notes / 注意：** 在合并处忽略第二及后续父；depth=0 返回 x。输入有多个提交时仍可能有多个结果。第一父由提交父顺序决定，不是按提交时间挑选。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L819) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-first_ancestors"></a>

## first_ancestors(x, [depth])

**包含自身，沿第一父链查看祖先。**

**Signature / 签名**

```text
first_ancestors(x, [depth])
```

**Arguments / 参数：** x：来源集合；depth：可选非负整数，省略时不限深度。

**Returns / 返回：** 自身和各层第一父；有限 depth 使用 [0, depth) 的代数范围。

**Examples / 示例**

```sh
jj log -r 'first_ancestors(@, 10)'
```

**Notes / 注意：** depth=1 仅来源，depth=2 加直接第一父。适合看主线的第一父历史，不代表所有真正参与合并的提交都被显示。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L829) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-reachable"></a>

## reachable(srcs, domain)

**在限定集合内，沿父边和子边双向找连通提交。**

**Signature / 签名**

```text
reachable(srcs, domain)
```

**Arguments / 参数：** srcs：起点 revset；domain：允许途经的 revset；均必填。

**Returns / 返回：** 从 srcs 出发且整条路径都在 domain 内的所有提交。

**Examples / 示例**

```sh
jj log -r 'reachable(@, mutable())'
```

**Notes / 注意：** 不在 domain 内的起点被忽略；路径不能穿过域外提交再回来。会包含相关兄弟分支，不等于只取祖先或后代。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L845) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-connected"></a>

## connected(x)

**填补所选提交之间的祖先—后代路径。**

**Signature / 签名**

```text
connected(x)
```

**Arguments / 参数：** x：任意 revset，必填。

**Returns / 返回：** x::x，即同时属于 x 后代和 x 祖先的提交。

**Examples / 示例**

```sh
jj log -r 'connected(trunk() | @)'
```

**Notes / 注意：** 名称容易误导：它不是整张无向图的连通分量，也不会仅因两个提交共享祖先就把公共祖先补进来。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L840) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-all"></a>

## all()

**返回当前搜索域内的所有提交。**

**Signature / 签名**

```text
all()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 当前可见提交，以及在表达式中显式引入的隐藏提交及其祖先等扩展范围。

**Examples / 示例**

```sh
jj log -r 'all()'
```

**Notes / 注意：** 不是对象库中所有历史 commit 的枚举。等价于 ::；与已移除的 all: 修饰符无关。at_operation() 还会扩展搜索域。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L855) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-none"></a>

## none()

**返回空集合。**

**Signature / 签名**

```text
none()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 零个提交。

**Examples / 示例**

```sh
jj log -r 'none()'
```

**Notes / 注意：** 适合作为别名或回退分支。它不是 root()；root() 有一个虚拟提交。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L851) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-change_id"></a>

## change_id(prefix)

**按 change ID 前缀查找提交。**

**Signature / 签名**

```text
change_id(prefix)
```

**Arguments / 参数：** prefix：合法 change ID 的完整值或前缀，不是 glob 模式。

**Returns / 返回：** 匹配该 change 的提交；分歧状态可返回多个版本。

**Examples / 示例**

```sh
jj log -r 'change_id(CHANGE_ID)'  # 将 CHANGE_ID 换成实际 change ID
```

**Notes / 注意：** 前缀对应多个不同 change 时报歧义错误；合法但无匹配的前缀返回空集合。裸 change ID 符号与此函数不同：裸符号不能直接解析为多个分歧版本。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L881) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-commit_id"></a>

## commit_id(prefix)

**按 commit ID 前缀精确定位提交对象。**

**Signature / 签名**

```text
commit_id(prefix)
```

**Arguments / 参数：** prefix：合法十六进制 commit ID 的完整值或前缀，不是 glob 模式。

**Returns / 返回：** 唯一匹配的提交，或者空集合。

**Examples / 示例**

```sh
jj log -r 'commit_id(COMMIT_ID)'  # 将 COMMIT_ID 换成实际 commit ID
```

**Notes / 注意：** 歧义前缀报错；合法但无匹配的前缀不报“未知符号”。可避免同名标签/书签抢先解析，并可显式引入隐藏提交。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L890) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-bookmarks"></a>

## bookmarks([pattern])

**选择本地书签指向的提交。**

**Signature / 签名**

```text
bookmarks([pattern])
```

**Arguments / 参数：** pattern：可选字符串模式，默认匹配全部本地书签名。

**Returns / 返回：** 匹配书签的目标集合；冲突书签包含其所有可能目标。

**Examples / 示例**

```sh
jj log -r 'bookmarks(glob:"feature/*")'
```

**Notes / 注意：** 返回提交，不返回书签名字。多个书签指向同一提交会去重。不会自动包含其祖先；需要 ::bookmarks() 时应显式加祖先运算符。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L899) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-remote_bookmarks"></a>

## remote_bookmarks([name_pattern], [[remote=]remote_pattern])

**选择全部远端书签的目标。**

**Signature / 签名**

```text
remote_bookmarks([name_pattern], [[remote=]remote_pattern])
```

**Arguments / 参数：** name_pattern：可选书签/标签名字符串模式；remote_pattern：可选远端名字符串模式，可用 remote= 指定。两者省略时匹配默认范围。

**Returns / 返回：** 名称与远端模式均匹配、且满足全部条件的目标提交集合。

**Examples / 示例**

```sh
jj log -r 'remote_bookmarks(remote="origin")'
```

**Notes / 注意：** 默认不包含特殊 git 跟踪引用；明确 remote="git" 只选这些引用，remote="*" 才把它们也包括进来。仅查询本地已知远端状态，不会联网 fetch。 “跟踪”是引用关系状态，不等于已发布/未发布的提交分类；冲突引用可产生多个目标。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L908) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-tracked_remote_bookmarks"></a>

## tracked_remote_bookmarks([name_pattern], [[remote=]remote_pattern])

**选择已跟踪远端书签的目标。**

**Signature / 签名**

```text
tracked_remote_bookmarks([name_pattern], [[remote=]remote_pattern])
```

**Arguments / 参数：** name_pattern：可选书签/标签名字符串模式；remote_pattern：可选远端名字符串模式，可用 remote= 指定。两者省略时匹配默认范围。

**Returns / 返回：** 名称与远端模式均匹配、且满足已跟踪条件的目标提交集合。

**Examples / 示例**

```sh
jj log -r 'tracked_remote_bookmarks("feature/*", remote="origin")'
```

**Notes / 注意：** 默认不包含特殊 git 跟踪引用；明确 remote="git" 只选这些引用，remote="*" 才把它们也包括进来。仅查询本地已知远端状态，不会联网 fetch。 “跟踪”是引用关系状态，不等于已发布/未发布的提交分类；冲突引用可产生多个目标。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L913) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-untracked_remote_bookmarks"></a>

## untracked_remote_bookmarks([name_pattern], [[remote=]remote_pattern])

**选择未跟踪远端书签的目标。**

**Signature / 签名**

```text
untracked_remote_bookmarks([name_pattern], [[remote=]remote_pattern])
```

**Arguments / 参数：** name_pattern：可选书签/标签名字符串模式；remote_pattern：可选远端名字符串模式，可用 remote= 指定。两者省略时匹配默认范围。

**Returns / 返回：** 名称与远端模式均匹配、且满足未跟踪条件的目标提交集合。

**Examples / 示例**

```sh
jj log -r 'untracked_remote_bookmarks(remote="origin")'
```

**Notes / 注意：** 默认不包含特殊 git 跟踪引用；明确 remote="git" 只选这些引用，remote="*" 才把它们也包括进来。仅查询本地已知远端状态，不会联网 fetch。 “跟踪”是引用关系状态，不等于已发布/未发布的提交分类；冲突引用可产生多个目标。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L921) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-tags"></a>

## tags([pattern])

**选择本地标签指向的提交。**

**Signature / 签名**

```text
tags([pattern])
```

**Arguments / 参数：** pattern：可选标签名字符串模式；省略表示全部标签。

**Returns / 返回：** 匹配标签的目标集合；冲突标签包含其所有可能目标。

**Examples / 示例**

```sh
jj log -r 'tags(glob:"v0.45*")'
```

**Notes / 注意：** 选择的是标签目标提交而非注解标签对象。与 bookmarks() 分开查询，能避开裸符号“标签优先”的名称冲突。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L929) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-remote_tags"></a>

## remote_tags([name_pattern], [[remote=]remote_pattern])

**选择全部远端标签的目标。**

**Signature / 签名**

```text
remote_tags([name_pattern], [[remote=]remote_pattern])
```

**Arguments / 参数：** name_pattern：可选书签/标签名字符串模式；remote_pattern：可选远端名字符串模式，可用 remote= 指定。两者省略时匹配默认范围。

**Returns / 返回：** 名称与远端模式均匹配、且满足全部条件的远端标签目标集合。

**Examples / 示例**

```sh
jj log -r 'remote_tags("v*", remote="origin")'
```

**Notes / 注意：** 默认不包含特殊 git 跟踪引用；明确 remote="git" 只选这些引用，remote="*" 才把它们也包括进来。仅查询本地已知远端状态，不会联网 fetch。 参数解析与 remote_bookmarks() 共用；目标集合会去重。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L938) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-tracked_remote_tags"></a>

## tracked_remote_tags([name_pattern], [[remote=]remote_pattern])

**选择已跟踪远端标签的目标。**

**Signature / 签名**

```text
tracked_remote_tags([name_pattern], [[remote=]remote_pattern])
```

**Arguments / 参数：** name_pattern：可选书签/标签名字符串模式；remote_pattern：可选远端名字符串模式，可用 remote= 指定。两者省略时匹配默认范围。

**Returns / 返回：** 名称与远端模式均匹配、且满足已跟踪条件的远端标签目标集合。

**Examples / 示例**

```sh
jj log -r 'tracked_remote_tags(remote="origin")'
```

**Notes / 注意：** 默认不包含特殊 git 跟踪引用；明确 remote="git" 只选这些引用，remote="*" 才把它们也包括进来。仅查询本地已知远端状态，不会联网 fetch。 参数解析与 remote_bookmarks() 共用；目标集合会去重。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L943) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-untracked_remote_tags"></a>

## untracked_remote_tags([name_pattern], [[remote=]remote_pattern])

**选择未跟踪远端标签的目标。**

**Signature / 签名**

```text
untracked_remote_tags([name_pattern], [[remote=]remote_pattern])
```

**Arguments / 参数：** name_pattern：可选书签/标签名字符串模式；remote_pattern：可选远端名字符串模式，可用 remote= 指定。两者省略时匹配默认范围。

**Returns / 返回：** 名称与远端模式均匹配、且满足未跟踪条件的远端标签目标集合。

**Examples / 示例**

```sh
jj log -r 'untracked_remote_tags(remote="origin")'
```

**Notes / 注意：** 默认不包含特殊 git 跟踪引用；明确 remote="git" 只选这些引用，remote="*" 才把它们也包括进来。仅查询本地已知远端状态，不会联网 fetch。 参数解析与 remote_bookmarks() 共用；目标集合会去重。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L948) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-visible_heads"></a>

## visible_heads()

**返回当前视图的可见顶端提交。**

**Signature / 签名**

```text
visible_heads()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 可见历史的 heads。

**Examples / 示例**

```sh
jj log -r 'visible_heads()'
```

**Notes / 注意：** 没有引入隐藏提交时等价于 heads(all())；引入隐藏历史后两者不一定相等。别把它理解成所有书签目标。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L873) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-root"></a>

## root()

**选择所有提交共同的虚拟根。**

**Signature / 签名**

```text
root()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 恰好一个虚拟根提交。

**Examples / 示例**

```sh
jj log -r 'root()'
```

**Notes / 注意：** 不是某个项目第一条真实提交；root() 不应被重写。..x 会排除它，::x 会包括它。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L877) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-heads"></a>

## heads(x)

**保留集合内没有其他所选后代的提交。**

**Signature / 签名**

```text
heads(x)
```

**Arguments / 参数：** x：待筛选的 revset。

**Returns / 返回：** x 中不属于 x 内其他提交的严格祖先的元素。

**Examples / 示例**

```sh
jj log -r 'heads(mine() & mutable())'
```

**Notes / 注意：** 考察完整祖先关系，哪怕中间提交不在 x 中。不是仅检查直接子是否在 x；也不是按时间取最新。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L863) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-roots"></a>

## roots(x)

**保留集合内没有其他所选祖先的提交。**

**Signature / 签名**

```text
roots(x)
```

**Arguments / 参数：** x：待筛选的 revset。

**Returns / 返回：** x 中不属于 x 内其他提交的严格后代的元素。

**Examples / 示例**

```sh
jj log -r 'roots(trunk()..@)'
```

**Notes / 注意：** 考察完整祖先关系；roots(x) 与 root() 完全不同，前者可能有多个结果或为空。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L868) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-latest"></a>

## latest(x, [count])

**按 committer 时间取最新的若干提交。**

**Signature / 签名**

```text
latest(x, [count])
```

**Arguments / 参数：** x：候选 revset；count：可选非负整数，默认 1。

**Returns / 返回：** 最多 count 个提交；候选不足时返回实际数量。

**Examples / 示例**

```sh
jj log -r 'latest(mine(), 5)'
```

**Notes / 注意：** 不是 author 时间，也不等于拓扑 heads；重写后 committer 时间可能改变。count=0 为空；不能用它代替 exactly() 验证唯一性。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L953) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-fork_point"></a>

## fork_point(x)

**查找全部候选的最近公共祖先。**

**Signature / 签名**

```text
fork_point(x)
```

**Arguments / 参数：** x：候选提交集合。

**Returns / 返回：** 共同祖先中不再有其他共同祖先作为后代的那些提交。

**Examples / 示例**

```sh
jj log -r 'fork_point(@ | trunk())'
```

**Notes / 注意：** 复杂合并历史可能得到多个“最近”公共祖先。单个候选返回自身，空集返回空；不是按日期找分叉点。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L963) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-merge_point"></a>

## merge_point(x)

**查找全部候选的最早公共后代。**

**Signature / 签名**

```text
merge_point(x)
```

**Arguments / 参数：** x：候选提交集合。

**Returns / 返回：** 共同后代中不再有其他共同后代作为祖先的那些提交。

**Examples / 示例**

```sh
jj log -r 'merge_point(bookmarks("feature/a") | bookmarks("feature/b"))'
```

**Notes / 注意：** 单个候选返回自身；可能没有共同后代，也可能有多个最小公共后代。不是“找所有 merge commit”。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L968) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-bisect"></a>

## bisect(x)

**从候选集合中挑选大致居中的二分点。**

**Signature / 签名**

```text
bisect(x)
```

**Arguments / 参数：** x：希望缩小定位范围的候选集合。

**Returns / 返回：** 使其后代约占输入集合一半的候选提交。

**Examples / 示例**

```sh
jj log -r 'bisect(trunk()..@)'
```

**Notes / 注意：** 这是选择函数，不会运行测试、移动工作区或记录 good/bad。官方说明其对非线性历史的处理仍有局限；实际自动定位参见 jj bisect run。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L973) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-exactly"></a>

## exactly(x, count)

**断言 revset 的结果数量。**

**Signature / 签名**

```text
exactly(x, count)
```

**Arguments / 参数：** x：要验证的集合；count：必填非负整数。

**Returns / 返回：** 数量恰好为 count 时原样返回 x，否则报错。

**Examples / 示例**

```sh
jj log -r 'exactly(bookmarks(exact:"feature"), 1)'
```

**Notes / 注意：** 不是截断，也不是随机挑选。exactly(x, 1) 可保护脚本中的单目标操作；count=0 可断言没有结果。不能写 count=1 这个命名实参。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L978) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-merges"></a>

## merges()

**选择有多个父提交的合并提交。**

**Signature / 签名**

```text
merges()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 父提交数量大于 1 的提交。

**Examples / 示例**

```sh
jj log -r 'merges() & ::@'
```

**Notes / 注意：** 合并提交可以 empty()，也可以 conflicts()；结构与内容状态是不同维度。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L984) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-forks"></a>

## forks()

**选择有多个子提交的分叉点。**

**Signature / 签名**

```text
forks()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 子提交数量大于 1 的提交。

**Examples / 示例**

```sh
jj log -r 'forks() & mutable()'
```

**Notes / 注意：** 这是结构过滤器，不等于 fork_point(x)，也不等于托管平台上的 fork 仓库。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L990) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-description"></a>

## description(pattern)

**按完整提交说明筛选。**

**Signature / 签名**

```text
description(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式，默认按 glob 解释。

**Returns / 返回：** 完整 description 匹配模式的提交。

**Examples / 示例**

```sh
jj log -r 'description(substring:"validation")'
```

**Notes / 注意：** 非空说明通常以换行结尾；description(exact:"fix") 不等于只匹配标题 fix。查包含词使用 substring:"fix"；没有说明用 description("")。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L994) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-subject"></a>

## subject(pattern)

**按说明的第一行筛选。**

**Signature / 签名**

```text
subject(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式，默认 glob。

**Returns / 返回：** 说明第一行（不含换行符）匹配的提交。

**Examples / 示例**

```sh
jj log -r 'subject(glob:"fix:*")'
```

**Notes / 注意：** 适合 Conventional Commits 标题筛选；与 description() 对正文及末尾换行的行为不同。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1000) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-author"></a>

## author(pattern)

**按原作者的姓名或邮箱筛选。**

**Signature / 签名**

```text
author(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式，默认 glob。

**Returns / 返回：** author_name(pattern) | author_email(pattern)。

**Examples / 示例**

```sh
jj log -r 'author(substring-i:"alice")'
```

**Notes / 注意：** 姓名与邮箱分别匹配，不把它们先拼成 Name <email>。多个重写者不改变“按 author 过滤”的含义。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1006) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-author_name"></a>

## author_name(pattern)

**只匹配作者姓名。**

**Signature / 签名**

```text
author_name(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式。

**Returns / 返回：** author.name 匹配的提交。

**Examples / 示例**

```sh
jj log -r 'author_name(exact:"Alice Example")'
```

**Notes / 注意：** 默认 glob，不默认做子串匹配；同名作者不是可靠的身份认证。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1014) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-author_email"></a>

## author_email(pattern)

**只匹配作者邮箱。**

**Signature / 签名**

```text
author_email(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式。

**Returns / 返回：** author.email 匹配的提交。

**Examples / 示例**

```sh
jj log -r 'author_email(glob:"*@example.com")'
```

**Notes / 注意：** 可用 exact-i 做忽略大小写的完全匹配；元数据邮箱本身不证明签名可信。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1020) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-author_date"></a>

## author_date(pattern)

**按作者时间筛选。**

**Signature / 签名**

```text
author_date(pattern)
```

**Arguments / 参数：** pattern：必填日期模式，仅 after: 或 before:。

**Returns / 返回：** 作者时间满足日期边界的提交。

**Examples / 示例**

```sh
jj log -r 'author_date(after:"2026-09-01T00:00:00+08:00")'
```

**Notes / 注意：** after 为大于等于，before 为严格小于；要限定时间区间，用两个 author_date() 的交集。作者时间不等于重写时间。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1026) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-mine"></a>

## mine()

**选择作者邮箱等于当前配置邮箱的提交。**

**Signature / 签名**

```text
mine()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 等价于 author_email(exact-i:<当前 user.email>)。

**Examples / 示例**

```sh
jj log -r 'mine() & mutable()'
```

**Notes / 注意：** 不是“所有经我 rebase/提交过的内容”，不按 committer 身份判断；实际结果取决于当前 user.email 配置。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1038) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-committer"></a>

## committer(pattern)

**按提交者姓名或邮箱筛选。**

**Signature / 签名**

```text
committer(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式，默认 glob。

**Returns / 返回：** committer_name(pattern) | committer_email(pattern)。

**Examples / 示例**

```sh
jj log -r 'committer(substring-i:"alice")'
```

**Notes / 注意：** committer 记录生成当前提交对象的提交者，与最初 author 可能不同；重写会形成新的提交对象。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1047) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-committer_name"></a>

## committer_name(pattern)

**只匹配提交者姓名。**

**Signature / 签名**

```text
committer_name(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式。

**Returns / 返回：** committer.name 匹配的提交。

**Examples / 示例**

```sh
jj log -r 'committer_name(exact:"Alice Example")'
```

**Notes / 注意：** 不要与 author_name() 混用；默认 glob。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1055) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-committer_email"></a>

## committer_email(pattern)

**只匹配提交者邮箱。**

**Signature / 签名**

```text
committer_email(pattern)
```

**Arguments / 参数：** pattern：必填字符串模式。

**Returns / 返回：** committer.email 匹配的提交。

**Examples / 示例**

```sh
jj log -r 'committer_email(glob:"*@example.com")'
```

**Notes / 注意：** 适合调查由特定账号或自动化系统生成的提交对象，不保证它们的作者也是该账号。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1061) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-committer_date"></a>

## committer_date(pattern)

**按提交者时间筛选。**

**Signature / 签名**

```text
committer_date(pattern)
```

**Arguments / 参数：** pattern：必填日期模式 after: 或 before:。

**Returns / 返回：** committer 时间满足边界的提交。

**Examples / 示例**

```sh
jj log -r 'committer_date(after:"2 days ago")'
```

**Notes / 注意：** 这是 latest() 使用的时间维度。相对时间按命令执行时刻和日期上下文解析；需复现时用含时区的绝对时间。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1067) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-signed"></a>

## signed()

**选择带有密码学签名的提交。**

**Signature / 签名**

```text
signed()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 具有签名数据的提交。

**Examples / 示例**

```sh
jj log -r 'signed() & ::@'
```

**Notes / 注意：** 不等于签名已验证、密钥可信或作者身份真实。签名状态需查看签名验证结果。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1033) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-empty"></a>

## empty()

**选择没有文件改动的提交。**

**Signature / 签名**

```text
empty()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 相对父提交合并基准没有文件变化的提交。

**Examples / 示例**

```sh
jj log -r 'empty() & mutable()'
```

**Notes / 注意：** 包括虚拟 root()，以及没有用户修改的自动合并提交。不是“没有提交说明”，后者是 description("")；也不等于没有子提交。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1074) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-files"></a>

## files(expression)

**按被修改的文件路径筛选提交。**

**Signature / 签名**

```text
files(expression)
```

**Arguments / 参数：** expression：必填 fileset 表达式，不是另一个 revset。

**Returns / 返回：** 修改了至少一条匹配路径的提交。

**Examples / 示例**

```sh
jj log -r 'files(root:"src") & ::@'
```

**Notes / 注意：** 默认路径相对 jj 启动目录；目录匹配其子树。files(".") 的点要加引号。root: / root-file: 可避免依赖当前目录；这不是搜索快照中是否存在某文件。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1078) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-diff_lines"></a>

## diff_lines(text, [files])

**按 diff 的新增或删除行搜索。**

**Signature / 签名**

```text
diff_lines(text, [files])
```

**Arguments / 参数：** text：必填字符串模式，逐行匹配；files：可选 fileset 表达式，默认所有修改文件。

**Returns / 返回：** 在所选文件 diff 的新增或删除侧至少有一行满足模式的提交。

**Examples / 示例**

```sh
jj log -r 'diff_lines(substring:"TODO", root:"src")'
```

**Notes / 注意：** 查的是变更行，不是当前文件全部内容。默认字符串模式仍是 glob；用 substring: 可明确搜索词。v0.45.1 省略 files 时不会自动沿用命令行路径过滤；大仓库建议先限定 revset 和 paths。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1089) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-diff_lines_added"></a>

## diff_lines_added(text, [files])

**只在新增侧的 diff 行搜索。**

**Signature / 签名**

```text
diff_lines_added(text, [files])
```

**Arguments / 参数：** text：必填字符串模式，逐行匹配；files：可选 fileset 表达式，默认所有修改文件。

**Returns / 返回：** 在所选文件 diff 的新增侧至少有一行满足模式的提交。

**Examples / 示例**

```sh
jj log -r 'diff_lines_added(substring:"TODO", root:"src")'
```

**Notes / 注意：** 查的是变更行，不是当前文件全部内容。默认字符串模式仍是 glob；用 substring: 可明确搜索词。v0.45.1 省略 files 时不会自动沿用命令行路径过滤；大仓库建议先限定 revset 和 paths。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1107) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-diff_lines_removed"></a>

## diff_lines_removed(text, [files])

**只在删除侧的 diff 行搜索。**

**Signature / 签名**

```text
diff_lines_removed(text, [files])
```

**Arguments / 参数：** text：必填字符串模式，逐行匹配；files：可选 fileset 表达式，默认所有修改文件。

**Returns / 返回：** 在所选文件 diff 的删除侧至少有一行满足模式的提交。

**Examples / 示例**

```sh
jj log -r 'diff_lines_removed(substring:"deprecated", root:"src")'
```

**Notes / 注意：** 查的是变更行，不是当前文件全部内容。默认字符串模式仍是 glob；用 substring: 可明确搜索词。v0.45.1 省略 files 时不会自动沿用命令行路径过滤；大仓库建议先限定 revset 和 paths。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1118) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-conflicts"></a>

## conflicts()

**选择文件树中带有冲突的提交。**

**Signature / 签名**

```text
conflicts()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 存在文件冲突的提交。

**Examples / 示例**

```sh
jj log -r 'conflicts() & mutable()'
```

**Notes / 注意：** 不是书签目标冲突，也不是同一 change 的分歧版本；后者用 divergent()。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1131) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-divergent"></a>

## divergent()

**选择属于分歧 change 的可见提交。**

**Signature / 签名**

```text
divergent()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 同一 change ID 有多个可见提交版本时的相关提交。

**Examples / 示例**

```sh
jj log -r 'divergent() & mutable()'
```

**Notes / 注意：** 与文件冲突独立。裸 change ID 可能无法唯一解析；用 change_id(prefix) 取集合，用具体 commit ID 或 change offset 定位版本。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1135) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-present"></a>

## present(x)

**把缺失的提交符号转为空集合。**

**Signature / 签名**

```text
present(x)
```

**Arguments / 参数：** x：要解析的 revset。

**Returns / 返回：** 正常时返回 x；x 中出现无法找到的提交符号时整个表达式结果为空。

**Examples / 示例**

```sh
jj log -r 'present(main@origin) | present(master@origin)'
```

**Notes / 注意：** 不是通用 try/catch：语法错误、歧义等仍会失败。present(main | missing) 会整体为空，不是保留 main；分别容错应写 present(main) | present(missing)。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1139) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-coalesce"></a>

## coalesce(revsets...)

**选择第一个非空结果集合。**

**Signature / 签名**

```text
coalesce(revsets...)
```

**Arguments / 参数：** revsets...：零个或多个 revset 实参，按顺序考虑。

**Returns / 返回：** 首个非空集合；全空或没有实参时返回 none()。

**Examples / 示例**

```sh
jj log -r 'coalesce(present(main@origin), present(master@origin), root())'
```

**Notes / 注意：** 并不是未知符号错误的兜底器；各实参必须能被解析和解析引用。可能缺失的名字要各自放进 present()；也不把多个非空集合合并。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1156) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-working_copies"></a>

## working_copies()

**选择仓库所有工作区的工作副本提交。**

**Signature / 签名**

```text
working_copies()
```

**Arguments / 参数：** 无参数。

**Returns / 返回：** 当前仓库各 workspace 记录的工作副本目标集合。

**Examples / 示例**

```sh
jj log -r 'working_copies()'
```

**Notes / 注意：** 与只选当前工作区的 @ 不同。读取其他工作区记录不会替它们扫描和快照未保存到仓库视图的磁盘改动。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L859) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-at_operation"></a>

## at_operation(op, x)

**在指定操作记录的仓库视图中计算 revset。**

**Signature / 签名**

```text
at_operation(op, x)
```

**Arguments / 参数：** op：必填操作 ID 或操作选择表达式（如 @-）；x：在该操作视图中计算的 revset。

**Returns / 返回：** 旧操作视图下 x 的结果，并把该操作可见的历史引入本表达式搜索域。

**Examples / 示例**

```sh
jj --ignore-working-copy log -r 'at_operation(@-, @)'
```

**Notes / 注意：** 第一个参数中的 @- 是上一个 operation，不是工作提交的父；第二个参数中的 @ 才是该视图的工作副本提交。只查询，不等于 op restore。普通命令的自动快照可能新增操作；核对时可用 --ignore-working-copy 或固定 operation ID。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1144) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-fn-diff_contains"></a>

## diff_contains(text, [files])

**diff_lines() 的弃用兼容名称。**

> **状态：弃用兼容名；新代码使用 `diff_lines()`。**

**Signature / 签名**

```text
diff_contains(text, [files])
```

**Arguments / 参数：** text、files：与 diff_lines(text, [files]) 相同。

**Returns / 返回：** 与 diff_lines() 相同。

**Examples / 示例**

```sh
jj log -r 'diff_lines(substring:"TODO", root:"src")'  # 使用新名称
```

**Notes / 注意：** v0.45.1 源码仍注册它，并发出弃用警告；新用法改为 diff_lines()。源码的移除 TODO 不是已移除的证据。

**Source / 来源：** [Rust 定义](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1129) · [官方函数参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-string-patterns"></a>

## String patterns / 字符串模式与逻辑组合

v0.45.1 默认把 `"text"` 解释成 **glob 模式**，不是默认子串搜索。四种模式都支持追加 `-i` 忽略大小写，共八种拼写：

| 精确写法 | 忽略大小写写法 | 含义 / 例子 |
|---|---|---|
| `exact:"text"` | `exact-i:"text"` | 整个字符串相等 |
| `glob:"pattern"` | `glob-i:"pattern"` | shell 风格通配匹配，如 `"fix:*"` |
| `regex:"pattern"` | `regex-i:"pattern"` | 正则子串匹配；需要整串时自行用 `^`、`$` |
| `substring:"text"` | `substring-i:"text"` | 原样子串匹配，不把特殊字符当正则 |

glob 常用 `*` 匹配任意串、`?` 匹配单字符、`[abc]` 匹配字符组、`{foo,bar}` 匹配备选。这里匹配的是**字符串**，不是 shell 展开，也不要直接套用 fileset 中 `*`/`**` 的路径分隔规则。

```sh
# 含有 fix 的说明
jj log -r 'description(substring:"fix")'

# 以 fix: 开头的标题
jj log -r 'subject(glob:"fix:*")'

# 标题恰好等于 fix parser
jj log -r 'subject(exact:"fix parser")'

# 完整说明通常有末尾换行；这里显式匹配换行
jj log -r 'description(exact:"fix parser\n")'
```

### 字符串条件也可做逻辑组合

```sh
jj log -r 'bookmarks(glob:"feature/*" ~ glob:"feature/wip-*")'
jj log -r 'author_email(exact:"a@example.com" | exact:"b@example.com")'
```

这里函数括号里面的 `|` / `~` 合并的是“名字是否匹配”的条件；函数外面合并的才是提交集合。

一个提交可能有多个书签，所以：

```text
bookmarks(~glob:"ci/*")
```

表示“至少有一个不叫 ci/* 的书签指向它”，**不等于** `bookmarks() ~ bookmarks(glob:"ci/*")`。后者会排除任何带 ci/* 书签的目标，即使它同时还有另一个普通书签。

### 不要串用三种冒号

`glob:"fix*"` 是字符串模式；`root:"src"` 是 fileset 模式；`after:"yesterday"` 是日期模式。冒号本身不是通用的 revset 范围运算符。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#string-patterns) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1209-L1245) · [`docs/filesets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/filesets.md#file-patterns)


<a id="revset-date-patterns"></a>

## Date patterns / 日期边界、时区与可复现查询

| 模式 | 边界 |
|---|---|
| `after:"时间"` | 大于等于给定时刻，包含边界 |
| `before:"时间"` | 严格小于给定时刻，不包含边界 |

支持日期、日期时间、含时区时间和相对时间，如 `"2026-09-01"`、`"2026-09-01T09:00:00+08:00"`、`"2 days ago"`、`"yesterday 10:30"`。无时区值按日期解析上下文处理，通常是本机时区；相对时间也取决于执行时刻。

查询新加坡时间 2026 年 9 月的作者时间：

```sh
jj log -r 'author_date(after:"2026-09-01T00:00:00+08:00") & author_date(before:"2026-10-01T00:00:00+08:00")'
```

这是 `[9 月 1 日 00:00, 10 月 1 日 00:00)` 半开区间，不会在月末最后一毫秒上遗漏或重复。

查询最近两天生成或重写的提交对象：

```sh
jj log -r 'committer_date(after:"2 days ago")'
```

`author_date` 记录最初创作时间，`committer_date` 随提交对象重写而更新。`latest()` 使用后者；不要把最近 rebase 的提交误认为最近才开始编写的提交。

日期模式不是任意字符串 glob，也不要写 `author_date(after:"..." & before:"...")`。区间用两个日期函数的交集表达。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#date-patterns) · [`lib/src/time_util.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/time_util.rs#L26-L178) · [`docs/glossary.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/glossary.md#committer-date)


<a id="revset-aliases"></a>

## Aliases / 自定义符号、函数与模式别名

别名定义在 `[revset-aliases]` 中，可以是普通符号、带参数函数或 `名称:值` 的模式。

```toml
[revset-aliases]
# 符号别名：只定义在你的配置中，不是 jj 自带 HEAD
HEAD = '@-'

# 函数别名：当前所在的可变连通栈
'stack()' = 'reachable(@, mutable())'

# 同名自定义别名可按实参数量重载
'user()' = 'user("me@example.com")'
'user(x)' = 'author(x) | committer(x)'

# 模式别名
'grep:x' = 'description(regex:x)'

# 附加 doc 供补全等功能显示
'pending()' = { definition = '(trunk()..@) & ~empty()', doc = '当前主线之外、并且有文件改动的提交' }
```

以上邮箱是示例，按自己的账号替换。编辑已有配置时合并到已有 `[revset-aliases]` 表，不要在同一个 TOML 文档里重复声明该表。

```sh
jj config edit --user
jj config list revset-aliases

jj log -r 'stack()'
jj log -r 'user("alice@example.com")'
jj log -r 'grep:"(?i)fix|bug"'
jj log -r 'pending()'
```

别名函数虽可按参数数量重载，但**覆盖内置函数按名字生效**：不要指望自定义 `ancestors(x)` 后，内置 `ancestors(x, depth)` 还能与它共存。别名也不是运行 shell 命令的宏。

### Alias descriptions / 另一种附带说明的写法

```toml
[revset-aliases]
'stack()'.definition = 'reachable(@, mutable())'
'stack()'.doc = '当前工作提交所在的可变连通栈'
```

这是前面写法的替代方案，不要同时重复定义同一个键。

### 修改不可变边界的示例

假设你已有本地 `release/*` 书签，希望把它们及其祖先也保护起来：

```toml
[revset-aliases]
'immutable_heads()' = 'builtin_immutable_heads() | bookmarks(glob:"release/*")'
```

不要通过重定义 `immutable()` 或 `mutable()` 修改写保护；这两个别名主要用于查询。也不要为了消掉错误直接移除所有保护，先检查自己覆盖了哪些来源。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#aliases) · [`cli/src/config/revsets.toml`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml) · [`cli/src/revset_util.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/revset_util.rs)


<a id="revset-default-config"></a>

## Built-in Aliases / 默认定义与命令选择范围

八个默认别名逐条列在本章后面的“别名”条目。它们来自固定版本的 `cli/src/config/revsets.toml`，可以被用户级、仓库级配置覆盖；下面不是在假定你的实际配置一定仍为默认值。

默认配置还包含 **11 个 `[revsets]` 键**。这些键是“命令未显式给出选择时从哪取值”，不是新增 revset 函数：

| 配置键 | v0.45.1 默认表达式 |
|---|---|
| `revsets.arrange` | `reachable(@, mutable())` |
| `revsets.converge` | `mutable() & divergent()` |
| `revsets.fix` | `reachable(@, mutable())` |
| `revsets.run` | `reachable(@, mutable())` |
| `revsets.simplify-parents` | `reachable(@, mutable())` |
| `revsets.log` | `builtin_log()` |
| `revsets.log-graph-prioritize` | `present(@)` |
| `revsets.op-diff-changes-in` | `mutable() \| immutable_heads()` |
| `revsets.sign` | `reachable(@, mutable())` |
| `revsets.bookmark-advance-to` | `@` |
| `revsets.bookmark-advance-from` | `heads(::to & bookmarks())` |

最后一项的 `to` 是 bookmark advance 求值时提供的上下文符号，**不是任何命令里都存在的全局 revset 符号**。`log-graph-prioritize` 用来影响图的优先展示分支，不是另一份全部筛选条件。

检查自己的有效配置：

```sh
jj config list revsets
jj config list revset-aliases
jj log -r 'trunk()'
jj log -r 'immutable_heads()'
```

没有加 `-r` 的命令受自身默认表达式和配置影响；复制教程前要区分“这个函数的含义”和“这个命令默认把什么传给函数”。

**Source / 来源：** [`cli/src/config/revsets.toml`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml) · [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#built-in-aliases)


<a id="revset-alias-trunk"></a>

## trunk()

**主线目标；仓库初始化时通常会写入更具体的覆盖定义。**

**Default / 默认定义**

```text
latest(remote_bookmarks(exact:"main", exact:"origin") | remote_bookmarks(exact:"master", exact:"origin") | remote_bookmarks(exact:"trunk", exact:"origin") | remote_bookmarks(exact:"main", exact:"upstream") | remote_bookmarks(exact:"master", exact:"upstream") | remote_bookmarks(exact:"trunk", exact:"upstream") | root())
```

**Notes / 注意：** 这里只列全局兜底。它对 main/master/trunk 与 origin/upstream 的候选取 committer 时间最新者，不按名字先后决定优先级；无候选时回到 root()。自定义后应始终恰好返回一个提交。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-builtin_log"></a>

## builtin_log()

**默认日志筛选逻辑。**

**Default / 默认定义**

```text
present(@) | ancestors(immutable_heads().., 2) | trunk()
```

**Notes / 注意：** 它是 [revsets].log 的默认值来源；ancestors(..., 2) 表示集合自身加一代祖先，不是只显示两个提交。jj log 显式传 -r 或路径时不能一概假定仍套此默认。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-builtin_immutable_heads"></a>

## builtin_immutable_heads()

**上游提供的不可变边界默认集合。**

**Default / 默认定义**

```text
trunk() | tags() | untracked_remote_bookmarks() | untracked_remote_tags()
```

**Notes / 注意：** 推荐保留该基准；需要扩展保护范围时覆盖 immutable_heads()，并可引用此基准。未跟踪远端引用默认纳入保护边界。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-immutable_heads"></a>

## immutable_heads()

**确定不可变集合边界的配置入口。**

**Default / 默认定义**

```text
builtin_immutable_heads()
```

**Notes / 注意：** 表示不可变集合的边界 heads，不是“从所有不可变提交中随便挑出一部分”。jj 将其祖先和 root() 视为不可变；不存在的可选符号可用 present() 包住，防止多个命令因解析失败而无法使用。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-immutable"></a>

## immutable()

**查询按默认规则应视为不可变的集合。**

**Default / 默认定义**

```text
::(immutable_heads() | root())
```

**Notes / 注意：** 不要覆盖它来改变写保护；只改查询别名不会改变 jj 内部真正的不可变检查。要改保护策略，用 immutable_heads()。root() 不能作为普通提交重写。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-mutable"></a>

## mutable()

**查询可变提交集合。**

**Default / 默认定义**

```text
~immutable()
```

**Notes / 注意：** 在当前搜索域内取不可变集合的补集。mutable 不等于尚未 push，也不等于属于当前用户；mine() 与 remote_bookmarks() 是不同维度。不要覆盖此别名来尝试绕过写保护。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-visible"></a>

## visible()

**当前视图的可见历史。**

**Default / 默认定义**

```text
::visible_heads()
```

**Notes / 注意：** 不显式引入隐藏历史时与 all() 相同；引入后 all() 可能更大，因此 visible() 可用于明确限制当前可见提交。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-alias-hidden"></a>

## hidden()

**当前搜索域中相对于当前视图隐藏的提交。**

**Default / 默认定义**

```text
~visible()
```

**Notes / 注意：** 单独计算通常为空；它不是遍历对象库全部旧版本的函数。需要先显式引入旧 commit、change offset 或 operation 历史。

**Source / 来源：** [固定版本默认配置](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml)


<a id="revset-connectivity"></a>

## Examples / reachable、connected、heads、roots 的区别

继续使用有合并和分叉的历史：

```text
E
| D
|/|
B C
|/
A
|
root()
```

D 的父是 B、C；E 的父是 B。

| 表达式 | 结果 | 意义 |
|---|---|---|
| `reachable(E, A..)` | `{E, D, C, B}` | 可以经 B 到 D，再到 C，所有节点仍在 A.. 内 |
| `reachable(E, B..)` | `{E}` | E 唯一相邻父 B 不在域内，不能跨过去 |
| `reachable(C, B..)` | `{D, C}` | C 与 D 在限定域内连通 |
| `reachable(A, A..)` | `{}` | 起点 A 不在域里 |
| `connected(E \| A)` | `{E, B, A}` | 只填 E 与 A 之间的祖先路径 |
| `connected(D \| A)` | `{D, C, B, A}` | D 到 A 的两条路径都填上 |
| `connected(B \| C)` | `{B, C}` | 不会因为共享祖先而补入 A |
| `heads(E \| B)` | `{E}` | B 是 E 的祖先 |
| `heads(E \| C)` | `{E, C}` | 二者互不为祖先 |
| `roots(E \| B)` | `{B}` | 保留所选集合的祖先边界 |
| `fork_point(E \| D)` | `{B}` | 最近公共祖先 |
| `fork_point(E \| C)` | `{A}` | 最近公共祖先 |
| `merge_point(B \| C)` | `{D}` | 最小公共后代 |

“选择当前工作的整组相关提交”常用 `reachable(@, mutable())`。它允许沿父和子双向走，可能把兄弟分支一起选入；若只想要当前提交的祖先线，使用 `::@ & mutable()`。

本页示例同样按独立 DAG 模型做了集合结果检查，不代表实际执行过 jj。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md#functions)


<a id="revset-log-markers"></a>

## Log markers / 日志图形、引用后缀与状态标签

本节说明 **v0.45.1 默认模板**。用户可以覆盖 `templates.log_node`、日志模板或选择 ASCII 图形；显示效果不是永久不变的语法规则。

### 提交图节点

| 默认 Unicode | ASCII 模式 | 含义 |
|---|---|---|
| `@` | `@` | 当前工作副本提交 |
| `◆` | `+` | 不可变提交 |
| `×` | `x` | 带文件冲突的提交（且未先匹配前两类） |
| `○` | `o` | 其他普通提交；它也可能是 merge |
| `~` | `~` | 图中省略了中间历史的占位节点，不是一个提交 |

默认判断顺序是 **当前工作副本 → 不可变 → 文件冲突 → 普通**。因此一个有冲突的当前工作副本仍可能显示 `@`，不可变的冲突提交仍可能显示 `◆`。判断冲突应结合 `(conflict)`、`jj status` 或 `conflicts()`。

`│`、`├`、`╮`、`╯` 等连接线表达父子关系，不是 revset 运算符。图中 `~` 表示省略；表达式里的 `~x` 才是补集。

`jj op log` 中的 `@` 指**当前 operation**，不是当前 commit。两种日志属于不同的 DAG。

### 引用名后缀

| 示例 | 含义 | 不是 |
|---|---|---|
| `feature*` | 本地引用与至少一个被跟踪远端的目标不一致 | shell 通配符、文件脏状态、可直接粘贴的额外名字部分 |
| `feature??` | 该引用的目标存在冲突 | 同一 change 的 divergent 标记 |
| `feature@origin` | origin 的远端跟踪引用 | 自动 fetch 后的实时服务器状态 |
| `review@` | 名为 review 的工作区所处提交 | 远端名为空的 bookmark |

`??` 优先于 `*` 显示；不要把二者再一起附加到书签名。显示在日志里的 `feature*` 通常应以 `feature` 查询，而不是把星号也抄进去。

### 提交状态文字

| 标记 | 含义 | 常用对应查询 |
|---|---|---|
| `(empty)` | 没有文件变更 | `empty()` |
| `(no description set)` | 没有提交说明 | `description("")` |
| `(conflict)` | 文件树中有冲突 | `conflicts()` |
| `(divergent)` | 同一 change 有多个可见版本 | `divergent()` |
| `(hidden)` | 此提交不属于当前可见历史 | 显式引入历史后用 `hidden()` |
| change ID 后的 `/0`、`/1` | 版本偏移，用于区分隐藏或分歧版本 | `CHANGE_ID/0` |

`hidden` 与 `divergent` 的标签显示也有优先关系：隐藏版本不会仅因存在旧版本就造成可见 change 分歧。

### bookmark / tag list 与签名标记

引用列表中的 `(conflicted)` 和缩进的 `-` / `+` 行，表示冲突引用的移除侧/新增侧目标；不是 diff 中删除/新增的文件行，也不是 `x-` / `x+` revset 运算。

列表里的 `(deleted)` 表示本地目标已删除；`(not created yet)` 是相应跟踪远端目标尚不存在。若显示 `ahead by ...` / `behind by ...`，应按该条远端引用相对于本地跟踪目标的方向读，不能把所有列表都当成本地相对远端。

开启签名显示时，默认短签名为 `[✓︎]`（good）、`[?]`（unknown）、`[x]`（其他状态）。这是验证状态展示；`signed()` 只筛选签名存在，不能替代验证和信任策略。

**Source / 来源：** [`cli/src/config/templates.toml`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/templates.toml#L454-L595) · [`cli/src/commit_templater.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commit_templater.rs#L1515-L1678) · [`cli/src/config/templates.toml`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/templates.toml#L361-L412)


<a id="revset-migration"></a>

## Version notes / 旧教程迁移与上一版勘误

| 旧写法或常见误解 | v0.45.1 的状态 / 应如何写 |
|---|---|
| `all:表达式` | 已移除；0.38.0 起不再支持。直接传合法集合表达式，是否允许多目标由该命令参数决定 |
| `all()` | 仍是合法的全部集合函数，与上一行无关 |
| `diff_contains(text, files)` | 仍注册，但会发弃用警告；改用 `diff_lines(text, files)` |
| `git_head()` | 0.43.0 已移除，不应写进本版函数清单 |
| `git_refs()` | 0.43.0 已移除；按意图使用 bookmarks/tags/remote_* 等，不存在对所有场景都等价的机械替换 |
| `refs/heads/main` 的 Git 风格符号解析 | 0.43.0 已移除这一特殊解析；用本地 `main` 或显式 `bookmarks(exact:"main")` 等 |
| `x^` | 不是当前父提交语法；改用 `x-` |
| `x:y`、`:x`、`x:` | 不是有效 DAG 范围；按含义改成 `x::y`、`::x`、`x::` |
| `x + y` / `x - y` | 不是并集/差集；用 `x \| y` / `x ~ y` |
| `HEAD~3` | 不要套 Git 祖先语法；如想当前工作提交往前三代，用 `@---` 或 `parents(@, 3)` |
| `A...B` | 不要当成 jj 的内置对称差；用 `(A..B) \| (B..A)` |
| `description("fix")` | 默认 glob，并非“包含 fix”；明确用 `description(substring:"fix")` |
| 以 `mutable()` 判断“未推送” | 不可靠；它是不可变策略的补集，不是远端状态 |
| 以 `signed()` 判断“可信签名” | 不可靠；它仅判断签名存在 |

共置 Git 工作区里，某些旧 `git_head()` 用途可以通过 `first_parent(@)` 表达，但不要把它当成适用于所有仓库状态的一对一替换。`HEAD` 也不是本参考承诺始终存在的内置别名；官方别名示例中的 HEAD 是用户自己配置的。

### 此次纠正上一份手册的内容

原 Revset 速查曾建议部分多修订操作可使用 `all:`。该建议不适用于固定的 v0.45.1，已从更新版 Markdown 和 HTML 中删除；TXT 也已追加相应版本警告。

函数注册表里的 `diff_contains` 仍映射到 `diff_lines`，尽管注释有 “Remove in jj 0.44+” 的 TODO。清单按**实际注册代码**而不是 TODO 的计划日期判断。

不是看到解析器里有一个 token 就说明语法可用：`^`、单冒号旧范围、二元 `+`/`-` 等在源码中可能只是为了给出更友好的迁移错误。

**Source / 来源：** [`CHANGELOG.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/CHANGELOG.md) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs#L1088-L1129) · [`lib/src/revset.pest`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.pest) · [`lib/src/revset_parser.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset_parser.rs)


<a id="revset-recipes-intro"></a>

## Examples / 20 个可组合的查询场景

以下场景大部分只演示查询，避免把复杂集合直接交给 destructive 命令。第 14 个包含 `git fetch`，会联网并更新仓库状态，已单独标注。

示例中的 main、feature、origin、src 等名称不保证你的仓库存在；函数筛选到空集合可能是正常结果，不一定是命令失败。引用名、路径、邮箱和固定 ID 都应按仓库实际情况替换。

对即将用于修改操作的表达式，建议先记录并预览：

```sh
REVS='mine() & mutable()'
jj log -r "$REVS"
```

之后再按原工作流手册选择 `rebase`、`squash`、`abandon` 等具体操作。**revset 选中几个提交，不等于操作最终只会创建或重写几个提交对象**；后代重写、书签更新和不可变限制仍由命令决定。两次命令间 `@`、远端引用或仓库视图变化时，动态表达式的结果也可能变化。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md) · [`docs/glossary.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/glossary.md#rewrite)


<a id="revset-recipe-01"></a>

## R01 · 查看当前所在的可变提交栈

**场景：** 包含当前工作相关的祖先、后代和域内兄弟分支。

```sh
jj log -r 'reachable(@, mutable())'
```

**注意：** 这是限定域内的双向连通集合；需要只看祖先时改为 ::@ & mutable()。修改命令采用这个集合前先确认没有不想动的兄弟分支。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-02"></a>

## R02 · 查看当前主线之外的非空改动

**场景：** 只看 @ 已包含而 trunk 尚未包含、且有文件修改的提交。

```sh
jj log -r '(trunk()..@) & ~empty()'
```

**注意：** 主线由 trunk() 的有效配置决定；@ 如果是非空工作提交也会被包括。不是所有仓库里的未发布提交。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-03"></a>

## R03 · 查我的可变工作

**场景：** 按 author 邮箱筛出自己的可变提交。

```sh
jj log -r 'mine() & mutable()'
```

**注意：** 先核对 user.email。这里只组合作者身份与不可变策略，不包含“是否已经 push”的判断。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-04"></a>

## R04 · 按代数查看历史，而不是按条数

**场景：** 对比所有父路径与第一父链。

```sh
jj log -r 'ancestors(@, 5)'
jj log -r 'first_ancestors(@, 5)'
```

**注意：** 都包括 @，最多再向前四代。合并图第一条可能远多于五个提交；若只要 committer 时间最新五个，用 latest(::@, 5)。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-05"></a>

## R05 · 按标题约定查找修复

**场景：** 筛选以 fix: 开头，或以 fix(scope): 开头的标题。

```sh
jj log -r 'subject(regex:"^fix([(][^)]*[)])?:")'
```

**注意：** 使用字符组 [(]、[)] 表示字面括号，避免 shell 与 revset 双层转义。更简单但宽松的选择是 subject(glob:"fix*")。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-06"></a>

## R06 · 限定一个明确的作者时间区间

**场景：** 查询 +08:00 时区 2026 年 9 月的作者时间。

```sh
jj log -r 'author_date(after:"2026-09-01T00:00:00+08:00") & author_date(before:"2026-10-01T00:00:00+08:00")'
```

**注意：** after 包含下界，before 排除上界。复现报告时优先使用这种绝对边界，不用随执行时间变化的 yesterday。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-07"></a>

## R07 · 调查最近发生过重写的候选

**场景：** 按 committer 时间看近期提交对象。

```sh
jj log -r 'committer_date(after:"2 days ago") & mutable()'
```

**注意：** 它筛选最近生成的对象，不独立证明每条都经历过重写；新提交也会匹配。与 author_date 对照更有意义。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-08"></a>

## R08 · 查看某个 Rust 模块的变更历史

**场景：** 把路径锚定到工作区根，不受当前所在子目录影响。

```sh
jj log -r '::@ & files(root-file:"src/http.rs")'
```

**注意：** src/http.rs 是示例路径。只查询该路径上的变更，不能据此断言已跨所有重命名自动追溯旧名字。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-09"></a>

## R09 · 找出 TODO 是什么时候加进来的

**场景：** 只搜索 src 下 diff 的新增侧。

```sh
jj log -r '::@ & diff_lines_added(substring:"TODO", root:"src")'
```

**注意：** 已有文件中的未变动 TODO 不会匹配。需要同时看添加与删除，改用 diff_lines()。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-10"></a>

## R10 · 查找某个旧 API 的删除

**场景：** 搜索删除侧，避免被相同文本的新增误导。

```sh
jj log -r '::@ & diff_lines_removed(substring:"old_api", root:"src")'
```

**注意：** old_api 是示例文本，src 是示例目录。匹配的是单行变更文本，不做语义级 Rust 符号解析。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-11"></a>

## R11 · 只查看当前可变历史里的文件冲突

**场景：** 排除不相关的不可变历史。

```sh
jj log -r 'conflicts() & mutable()'
```

**注意：** 结果反映文件树冲突，不反映书签目标冲突；后者查看 jj bookmark list。可变范围内有冲突的后代也可能被选入。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-12"></a>

## R12 · 定位 change 分歧

**场景：** 先查看所有分歧版本，再用 ID 或 offset 指定目标。

```sh
jj log -r 'divergent() & mutable()'
```

**注意：** 之后可用 change_id(实际ID) 查看某个分歧集合；用实际ID/0、实际ID/1 或完整 commit ID 精确定位。不要仅凭新旧顺序自动删除某一版本。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-13"></a>

## R13 · 预览空白草稿候选

**场景：** 找出自己没有说明也没有文件修改、且不是任何工作区当前目标的可变提交。

```sh
jj log -r '(mine() & mutable() & empty() & description("")) ~ working_copies()'
```

**注意：** 这只是审查候选，不等于可安全 abandon。空 merge、被书签引用的提交也可能有用途，清理前仍需核对图关系。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-14"></a>

## R14 · 看当前历史相对 origin 已知书签的差集

**场景：** 先更新 origin 的本地记录，再比较祖先闭包。

```sh
jj git fetch --remote origin
jj log -r 'remote_bookmarks(remote="origin")..@'
```

**注意：** fetch 会联网并更新仓库视图；本例不是纯只读查询。差集只依据 origin 书签，不代表远端所有对象或标签完全没有这些提交。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-15"></a>

## R15 · 总览本地引用与工作区边界

**场景：** 集中查看书签、标签和所有工作副本。

```sh
jj log -r 'bookmarks() | tags() | working_copies()'
```

**注意：** 这里仅选引用目标而不是它们全部祖先；日志可能用 ~ 表示被省略的中间历史。需要祖先闭包时写 ::(bookmarks() | tags() | working_copies())。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-16"></a>

## R16 · 找当前工作与主线的共同基点

**场景：** 找最近公共祖先，而不是凭时间猜分叉点。

```sh
jj log -r 'fork_point(@ | trunk())'
```

**注意：** 复杂交叉合并历史可能有多个最近公共祖先；要交给单目标命令时先检查，不能直接假定唯一。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-17"></a>

## R17 · 找两个 feature 最早共同进入哪里的历史

**场景：** 寻找共同后代的边界。

```sh
jj log -r 'merge_point(bookmarks(exact:"feature/a") | bookmarks(exact:"feature/b"))'
```

**注意：** 两个书签名是示例，先确认均存在。某个名称不匹配时 bookmarks() 返回空，可能只剩另一个输入；正式脚本应分别加 exactly(..., 1) 断言。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-18"></a>

## R18 · 兼容 main/master，但不吞掉歧义

**场景：** 按顺序选择存在的远端目标。

```sh
jj log -r 'coalesce(present(main@origin), present(master@origin), root())'
```

**注意：** present() 仅处理缺失，coalesce() 选第一个非空；不是按最新时间选择。main 的冲突或歧义不会被当成无结果自动忽略。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-19"></a>

## R19 · 从旧 operation 查看当前已经隐藏的提交

**场景：** 查看上一个操作的历史与当前可见历史的差别。

```sh
jj op log
jj --ignore-working-copy log -r 'hidden() & at_operation(@-, all())'
```

**注意：** 第一个参数 @- 是 operation 的父。并发操作历史可能分叉，@- 也可能无法唯一选择；需要稳定复查时用实际 operation ID 替换。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-recipe-20"></a>

## R20 · 给脚本的单目标加数量断言

**场景：** 不让一个本应单目标的查询悄悄变成多个目标或空。

```sh
jj log -r 'exactly(bookmarks(exact:"feature"), 1)'
```

**注意：** 示例要求本地 feature 书签存在且只有一个目标；否则故意报错。这比 latest(..., 1) 安全，因为后者会掩盖多目标事实。

**Source / 语法依据：** [官方 revset 参考](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md)；本例由本手册组合整理。


<a id="revset-sources"></a>

## Sources / 固定版本源码、覆盖口径与验证限制

**函数清单口径：** `docs/revsets.md` 的 Functions 部分列出 54 个正式文档名称；`lib/src/revset.rs` 的 `BUILTIN_FUNCTION_MAP` 另外保留 `diff_contains`，因此记录 55 个注册名称。弃用别名不是一种新的功能。默认配置中的 8 个 revset 别名单独列出，没有混进 55 的计数。

**交叉校对：** 函数签名与可选参数对照 Rust 注册代码；运算符对照解析器/grammar；日期边界对照 time_util；别名对照固定版本 TOML；显示符号对照模板与 CommitRef formatter；已移除语法对照 CHANGELOG。覆盖清单保存在 `revsets-functions.json`、`revsets-aliases.json` 和 `revsets-validation.json`。

| 源码文件 | 主要用途 |
|---|---|
| `docs/revsets.md` | 官方语言参考、函数签名、符号、示例 |
| `lib/src/revset.rs` | 55 个注册名称、默认值、参数解析和求值 |
| `lib/src/revset_parser.rs` / `lib/src/revset.pest` | 优先级、语法、兼容错误诊断 |
| `lib/src/dsl_util.rs` | 位置实参与命名实参检查 |
| `cli/src/config/revsets.toml` | 8 个默认别名、11 个 revsets 配置键 |
| `cli/src/revset_util.rs` | CLI revset 求值、真正的不可变策略 |
| `lib/src/time_util.rs` | 日期边界、时区解析及测试 |
| `docs/filesets.md` | files()/diff_lines() 的 fileset 实参 |
| `docs/glossary.md` | change offset、可见性、author/committer |
| `cli/src/config/templates.toml` | 日志节点、状态、签名与引用列表显示 |
| `cli/src/commit_templater.rs` | 引用后缀 * / ?? 的具体格式化 |
| `CHANGELOG.md` | all:、git_head()/git_refs() 等移除记录 |

**未做的验证：** 没有在本环境安装或编译 jj，没有在实际仓库执行这些命令，没有保存一个经校验的上游完整源码快照。源码通过在线固定 tag 查阅；不把网页阅读说成本地 AST 全量审计。JSON 覆盖检查比较的是由源码逐项抄录的名称清单，DAG 示例测试使用独立集合模型。

HTML 的搜索、分类、锚点、移动端布局及无外部资源加载检查，属于文档本身的验证，不是 jj 命令行为测试。具体结果查看附带验证记录。

本补篇为非官方中文整理。上游项目归 The Jujutsu Authors 所有，采用 Apache-2.0；此处保留源码链接和来源说明。中文解释与工作示例为本次重述整理，不把可配置默认值宣传成永久不变的规范。

**Source / 来源：** [`docs/revsets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/revsets.md) · [`lib/src/revset.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.rs) · [`lib/src/revset_parser.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset_parser.rs) · [`lib/src/revset.pest`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/revset.pest) · [`lib/src/dsl_util.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/dsl_util.rs) · [`cli/src/config/revsets.toml`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/revsets.toml) · [`cli/src/revset_util.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/revset_util.rs) · [`lib/src/time_util.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/lib/src/time_util.rs) · [`docs/filesets.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/filesets.md) · [`docs/glossary.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/docs/glossary.md) · [`cli/src/config/templates.toml`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/config/templates.toml) · [`cli/src/commit_templater.rs`](https://github.com/jj-vcs/jj/blob/v0.45.1/cli/src/commit_templater.rs) · [`CHANGELOG.md`](https://github.com/jj-vcs/jj/blob/v0.45.1/CHANGELOG.md)


